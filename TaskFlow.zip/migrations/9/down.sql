
ALTER TABLE task_categories DROP COLUMN sort_order;
