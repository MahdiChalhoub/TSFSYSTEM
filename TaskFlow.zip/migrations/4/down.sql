
ALTER TABLE time_entries DROP COLUMN organization_id;
ALTER TABLE tasks DROP COLUMN organization_id;
