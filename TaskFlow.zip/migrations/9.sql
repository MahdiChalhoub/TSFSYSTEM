
ALTER TABLE task_categories ADD COLUMN sort_order INTEGER DEFAULT 0;
