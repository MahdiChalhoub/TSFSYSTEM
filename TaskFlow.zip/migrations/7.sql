
CREATE TABLE task_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  organization_id INTEGER NOT NULL,
  leader_user_id TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_task_categories_organization ON task_categories(organization_id);

ALTER TABLE tasks ADD COLUMN category_id INTEGER;
