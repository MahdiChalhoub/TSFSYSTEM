
DROP INDEX idx_messages_created;
DROP INDEX idx_messages_org;
DROP TABLE messages;
