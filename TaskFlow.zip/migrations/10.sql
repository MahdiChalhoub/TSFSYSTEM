
-- Day time tracking (clock in/out for the day)
CREATE TABLE day_time_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id TEXT NOT NULL,
  organization_id INTEGER NOT NULL,
  clock_in_time DATETIME NOT NULL,
  clock_out_time DATETIME,
  total_hours REAL,
  status TEXT NOT NULL DEFAULT 'pending',
  notes TEXT,
  approved_by_user_id TEXT,
  approved_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_day_time_user_org ON day_time_entries(user_id, organization_id);
CREATE INDEX idx_day_time_status ON day_time_entries(status);

-- Task time tracking (start/stop timer for tasks)
CREATE TABLE task_time_entries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  task_id INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  organization_id INTEGER NOT NULL,
  start_time DATETIME NOT NULL,
  end_time DATETIME,
  duration_hours REAL,
  description TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  approved_by_user_id TEXT,
  approved_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_task_time_task ON task_time_entries(task_id);
CREATE INDEX idx_task_time_user_org ON task_time_entries(user_id, organization_id);
CREATE INDEX idx_task_time_status ON task_time_entries(status);

-- Update existing time_entries table to include approval status
ALTER TABLE time_entries ADD COLUMN status TEXT DEFAULT 'pending';
ALTER TABLE time_entries ADD COLUMN approved_by_user_id TEXT;
ALTER TABLE time_entries ADD COLUMN approved_at DATETIME;
