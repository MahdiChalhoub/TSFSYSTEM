
CREATE TABLE report_form_assignments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  form_id INTEGER NOT NULL,
  user_id TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_form_assignments_form ON report_form_assignments(form_id);
CREATE INDEX idx_form_assignments_user ON report_form_assignments(user_id);
