
DROP INDEX idx_user_group_members_user;
DROP INDEX idx_user_group_members_group;
DROP INDEX idx_user_groups_org;
DROP TABLE user_group_members;
DROP TABLE user_groups;
