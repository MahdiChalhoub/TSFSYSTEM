
ALTER TABLE organization_members DROP COLUMN email;
ALTER TABLE organization_members DROP COLUMN name;
