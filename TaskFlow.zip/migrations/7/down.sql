
ALTER TABLE tasks DROP COLUMN category_id;
DROP INDEX idx_task_categories_organization;
DROP TABLE task_categories;
