
DROP INDEX idx_question_choices_question_id;
DROP TABLE report_form_question_choices;
