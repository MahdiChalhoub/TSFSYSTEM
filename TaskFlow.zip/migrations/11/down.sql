
DROP INDEX idx_role_permissions_org_role;
DROP TABLE role_permissions;
