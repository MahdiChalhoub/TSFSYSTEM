
DROP INDEX idx_organizations_join_code;
ALTER TABLE organizations DROP COLUMN join_code;
