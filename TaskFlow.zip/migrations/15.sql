
ALTER TABLE tasks ADD COLUMN is_recurring BOOLEAN DEFAULT 0;
ALTER TABLE tasks ADD COLUMN recurrence_days INTEGER;
ALTER TABLE tasks ADD COLUMN parent_recurring_task_id INTEGER;
