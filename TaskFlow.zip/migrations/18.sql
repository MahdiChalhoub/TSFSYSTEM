
ALTER TABLE report_submissions ADD COLUMN is_holiday BOOLEAN DEFAULT 0;
