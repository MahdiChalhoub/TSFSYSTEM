
DROP TABLE report_additional_tasks;
DROP TABLE report_answers;
DROP TABLE report_submissions;
DROP TABLE report_form_questions;
DROP TABLE report_forms;
