
DROP INDEX idx_tasks_due_date;
DROP INDEX idx_tasks_status;
DROP INDEX idx_tasks_assigned_to;
DROP INDEX idx_tasks_created_by;
DROP TABLE tasks;
