
DROP INDEX idx_form_assignments_user;
DROP INDEX idx_form_assignments_form;
DROP TABLE report_form_assignments;
