
DROP INDEX idx_invitations_email;
DROP INDEX idx_invitations_token;
DROP TABLE invitations;
DROP INDEX idx_org_members_user;
DROP INDEX idx_org_members_org;
DROP TABLE organization_members;
DROP TABLE organizations;
