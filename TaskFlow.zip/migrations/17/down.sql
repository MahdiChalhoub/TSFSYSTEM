
ALTER TABLE report_form_assignments DROP COLUMN group_id;
