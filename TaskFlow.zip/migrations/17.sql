
ALTER TABLE report_form_assignments ADD COLUMN group_id INTEGER;
