
ALTER TABLE tasks DROP COLUMN parent_recurring_task_id;
ALTER TABLE tasks DROP COLUMN recurrence_days;
ALTER TABLE tasks DROP COLUMN is_recurring;
