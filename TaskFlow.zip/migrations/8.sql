
ALTER TABLE organization_members ADD COLUMN name TEXT;
ALTER TABLE organization_members ADD COLUMN email TEXT;
