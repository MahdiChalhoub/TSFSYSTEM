
DROP INDEX idx_time_entries_date;
DROP INDEX idx_time_entries_user_id;
DROP INDEX idx_time_entries_task_id;
DROP TABLE time_entries;
