
ALTER TABLE time_entries DROP COLUMN approved_at;
ALTER TABLE time_entries DROP COLUMN approved_by_user_id;
ALTER TABLE time_entries DROP COLUMN status;

DROP INDEX idx_task_time_status;
DROP INDEX idx_task_time_user_org;
DROP INDEX idx_task_time_task;
DROP TABLE task_time_entries;

DROP INDEX idx_day_time_status;
DROP INDEX idx_day_time_user_org;
DROP TABLE day_time_entries;
