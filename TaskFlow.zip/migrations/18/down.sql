
ALTER TABLE report_submissions DROP COLUMN is_holiday;
