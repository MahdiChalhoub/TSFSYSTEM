
ALTER TABLE organizations ADD COLUMN join_code TEXT;
CREATE UNIQUE INDEX idx_organizations_join_code ON organizations(join_code);
