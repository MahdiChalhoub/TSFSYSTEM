
ALTER TABLE tasks ADD COLUMN organization_id INTEGER;
ALTER TABLE time_entries ADD COLUMN organization_id INTEGER;
