import z from "zod";

// Task schemas
export const TaskSchema = z.object({
  id: z.number(),
  title: z.string(),
  description: z.string().nullable(),
  status: z.enum(['pending', 'in_progress', 'completed', 'cancelled']),
  priority: z.enum(['low', 'medium', 'high', 'urgent']),
  due_date: z.string().nullable(),
  created_by_user_id: z.string(),
  assigned_to_user_id: z.string().nullable(),
  category_id: z.number().nullable(),
  is_recurring: z.boolean().nullable(),
  recurrence_days: z.number().nullable(),
  parent_recurring_task_id: z.number().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateTaskSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  status: z.enum(['pending', 'in_progress', 'completed', 'cancelled']).default('pending'),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).default('medium'),
  due_date: z.string().optional(),
  assigned_to_user_id: z.string().optional(),
  category_id: z.number().optional(),
  is_recurring: z.boolean().optional(),
  recurrence_days: z.number().optional(),
});

export const UpdateTaskSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  status: z.enum(['pending', 'in_progress', 'completed', 'cancelled']).optional(),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).optional(),
  due_date: z.string().optional(),
  assigned_to_user_id: z.string().optional(),
  category_id: z.number().optional(),
  is_recurring: z.boolean().optional(),
  recurrence_days: z.number().optional(),
});

export type Task = z.infer<typeof TaskSchema>;
export type CreateTaskInput = z.infer<typeof CreateTaskSchema>;
export type UpdateTaskInput = z.infer<typeof UpdateTaskSchema>;

// Time entry schemas (manual entries)
export const TimeEntrySchema = z.object({
  id: z.number(),
  task_id: z.number(),
  user_id: z.string(),
  description: z.string().nullable(),
  hours: z.number(),
  entry_date: z.string(),
  status: z.enum(['pending', 'approved', 'rejected']).nullable(),
  approved_by_user_id: z.string().nullable(),
  approved_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateTimeEntrySchema = z.object({
  task_id: z.number(),
  description: z.string().optional(),
  hours: z.number().positive(),
  entry_date: z.string(),
});

export const UpdateTimeEntrySchema = z.object({
  description: z.string().optional(),
  hours: z.number().positive().optional(),
  entry_date: z.string().optional(),
});

export type TimeEntry = z.infer<typeof TimeEntrySchema>;
export type CreateTimeEntryInput = z.infer<typeof CreateTimeEntrySchema>;
export type UpdateTimeEntryInput = z.infer<typeof UpdateTimeEntrySchema>;

// Task category schemas
export const TaskCategorySchema = z.object({
  id: z.number(),
  name: z.string(),
  organization_id: z.number(),
  leader_user_id: z.string().nullable(),
  sort_order: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateTaskCategorySchema = z.object({
  name: z.string().min(1),
  leader_user_id: z.string().optional(),
});

export const UpdateTaskCategorySchema = z.object({
  name: z.string().min(1).optional(),
  leader_user_id: z.string().optional(),
});

export type TaskCategory = z.infer<typeof TaskCategorySchema>;
export type CreateTaskCategoryInput = z.infer<typeof CreateTaskCategorySchema>;
export type UpdateTaskCategoryInput = z.infer<typeof UpdateTaskCategorySchema>;

// Day time entry schemas (clock in/out for the day)
export const DayTimeEntrySchema = z.object({
  id: z.number(),
  user_id: z.string(),
  organization_id: z.number(),
  clock_in_time: z.string(),
  clock_out_time: z.string().nullable(),
  total_hours: z.number().nullable(),
  status: z.enum(['pending', 'approved', 'rejected']),
  notes: z.string().nullable(),
  approved_by_user_id: z.string().nullable(),
  approved_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type DayTimeEntry = z.infer<typeof DayTimeEntrySchema>;

// Task time entry schemas (start/stop timer for tasks)
export const TaskTimeEntrySchema = z.object({
  id: z.number(),
  task_id: z.number(),
  user_id: z.string(),
  organization_id: z.number(),
  start_time: z.string(),
  end_time: z.string().nullable(),
  duration_hours: z.number().nullable(),
  description: z.string().nullable(),
  status: z.enum(['pending', 'approved', 'rejected']),
  approved_by_user_id: z.string().nullable(),
  approved_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type TaskTimeEntry = z.infer<typeof TaskTimeEntrySchema>;
