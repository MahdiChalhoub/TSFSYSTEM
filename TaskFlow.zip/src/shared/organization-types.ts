import z from "zod";

// Organization schemas
export const OrganizationSchema = z.object({
  id: z.number(),
  name: z.string(),
  created_by_user_id: z.string(),
  join_code: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateOrganizationSchema = z.object({
  name: z.string().min(1),
});

export type Organization = z.infer<typeof OrganizationSchema>;
export type CreateOrganizationInput = z.infer<typeof CreateOrganizationSchema>;

// Organization member schemas
export const OrganizationMemberSchema = z.object({
  id: z.number(),
  organization_id: z.number(),
  user_id: z.string(),
  role: z.enum(['owner', 'admin', 'leader', 'member']),
  name: z.string().nullable(),
  email: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export type OrganizationMember = z.infer<typeof OrganizationMemberSchema>;

// Invitation schemas
export const InvitationSchema = z.object({
  id: z.number(),
  organization_id: z.number(),
  email: z.string(),
  invited_by_user_id: z.string(),
  token: z.string(),
  status: z.enum(['pending', 'accepted', 'declined']),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateInvitationSchema = z.object({
  email: z.string().email(),
});

export type Invitation = z.infer<typeof InvitationSchema>;
export type CreateInvitationInput = z.infer<typeof CreateInvitationSchema>;

// Message schemas
export const MessageSchema = z.object({
  id: z.number(),
  organization_id: z.number(),
  user_id: z.string(),
  content: z.string(),
  is_system_message: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateMessageSchema = z.object({
  content: z.string().min(1),
});

export type Message = z.infer<typeof MessageSchema>;
export type CreateMessageInput = z.infer<typeof CreateMessageSchema>;
