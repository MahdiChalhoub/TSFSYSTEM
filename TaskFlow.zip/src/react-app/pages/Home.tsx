import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '@getmocha/users-service/react';
import { CheckCircle2, Clock, Users, TrendingUp } from 'lucide-react';

export default function Home() {
  const { user, isPending, redirectToLogin } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isPending && user) {
      navigate('/dashboard');
    }
  }, [user, isPending, navigate]);

  if (isPending) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
        <div className="animate-pulse">
          <div className="w-16 h-16 bg-indigo-600 rounded-2xl"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Navigation */}
      <nav className="border-b border-indigo-100 bg-white/80 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/30">
                <CheckCircle2 className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                TaskFlow
              </span>
            </div>
            <button
              onClick={redirectToLogin}
              className="px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-xl hover:shadow-lg hover:shadow-indigo-500/30 transition-all duration-200 hover:scale-105"
            >
              Sign In
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-6 py-20">
        <div className="text-center mb-16">
          <h1 className="text-6xl font-bold mb-6 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent leading-tight">
            Manage Tasks & Track Time
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            The all-in-one platform for task management and time tracking. Assign work, monitor progress, and generate reports effortlessly.
          </p>
          <button
            onClick={redirectToLogin}
            className="px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white text-lg font-semibold rounded-2xl hover:shadow-2xl hover:shadow-indigo-500/40 transition-all duration-200 hover:scale-105"
          >
            Get Started Free
          </button>
        </div>

        {/* Features */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mt-20">
          <div className="bg-white rounded-2xl p-8 shadow-lg shadow-indigo-100 border border-indigo-50 hover:shadow-xl transition-shadow duration-200">
            <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-indigo-500/30">
              <CheckCircle2 className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">Task Management</h3>
            <p className="text-gray-600">Create, assign, and track tasks with multiple status levels and priorities.</p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg shadow-purple-100 border border-purple-50 hover:shadow-xl transition-shadow duration-200">
            <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-purple-500/30">
              <Clock className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">Time Tracking</h3>
            <p className="text-gray-600">Log hours against tasks and view detailed time breakdowns by day.</p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg shadow-pink-100 border border-pink-50 hover:shadow-xl transition-shadow duration-200">
            <div className="w-14 h-14 bg-gradient-to-br from-pink-500 to-pink-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-pink-500/30">
              <Users className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">Team Collaboration</h3>
            <p className="text-gray-600">Multiple users can sign in, create tasks, and assign work to teammates.</p>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-lg shadow-indigo-100 border border-indigo-50 hover:shadow-xl transition-shadow duration-200">
            <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-indigo-500/30">
              <TrendingUp className="w-7 h-7 text-white" />
            </div>
            <h3 className="text-xl font-semibold mb-2 text-gray-900">Daily Reports</h3>
            <p className="text-gray-600">Generate comprehensive reports showing tasks completed and hours logged.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
