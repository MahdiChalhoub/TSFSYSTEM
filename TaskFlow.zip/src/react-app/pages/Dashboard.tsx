import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '@getmocha/users-service/react';
import { Loader2, CheckCircle2, LogOut, Plus, Users, MessageSquare, Menu, X } from 'lucide-react';
import CategoryTaskView from '@/react-app/components/CategoryTaskView';
import TeamChat from '@/react-app/components/TeamChat';
import OrganizationSettings from '@/react-app/components/OrganizationSettings';
import TimeManagement from '@/react-app/components/TimeManagement';
import MyDailyReport from '@/react-app/components/MyDailyReport';
import ApprovalDashboard from '@/react-app/components/ApprovalDashboard';
import EmployeeTimeDashboard from '@/react-app/components/EmployeeTimeDashboard';
import EmployeeReportsDashboard from '@/react-app/components/EmployeeReportsDashboard';
import ReportFormsManagement from '@/react-app/components/ReportFormsManagement';
import UserGroupsManagement from '@/react-app/components/UserGroupsManagement';
import CreateTaskModal from '@/react-app/components/CreateTaskModal';
import CreateTimeEntryModal from '@/react-app/components/CreateTimeEntryModal';
import CreateOrganizationModal from '@/react-app/components/CreateOrganizationModal';
import JoinOrganizationModal from '@/react-app/components/JoinOrganizationModal';
import InviteTeamModal from '@/react-app/components/InviteTeamModal';
import CategoryManagementModal from '@/react-app/components/CategoryManagementModal';
import { Task, TimeEntry } from '@/shared/types';
import { Organization, OrganizationMember } from '@/shared/organization-types';

type View = 'tasks' | 'time' | 'reports' | 'approvals' | 'team' | 'settings' | 'time-dashboard' | 'reports-dashboard' | 'report-forms';

export default function Dashboard() {
  const { user, isPending, logout } = useAuth();
  const navigate = useNavigate();
  const [activeView, setActiveView] = useState<View>('tasks');
  const [organization, setOrganization] = useState<Organization | null>(null);
  const [userMembership, setUserMembership] = useState<OrganizationMember | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showCreateTask, setShowCreateTask] = useState(false);
  const [showCreateTimeEntry, setShowCreateTimeEntry] = useState(false);
  const [showCreateOrganization, setShowCreateOrganization] = useState(false);
  const [showJoinOrganization, setShowJoinOrganization] = useState(false);
  const [showInviteTeam, setShowInviteTeam] = useState(false);
  const [showCategoryManagement, setShowCategoryManagement] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);

  useEffect(() => {
    if (!isPending && !user) {
      navigate('/');
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      loadInitialData();
    }
  }, [user]);

  const loadInitialData = async () => {
    setIsLoading(true);
    try {
      const orgRes = await fetch('/api/organizations/current');
      if (orgRes.ok) {
        const orgData = await orgRes.json();
        setOrganization(orgData);
        
        if (!orgData) {
          setShowCreateOrganization(true);
          setIsLoading(false);
          return;
        }
        
        await loadData(orgData);
      }
    } catch (error) {
      console.error('Failed to load initial data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadData = async (org?: Organization) => {
    try {
      const currentOrg = org || organization;
      
      const [tasksRes, timeRes] = await Promise.all([
        fetch('/api/tasks'),
        fetch('/api/time-entries'),
      ]);
      
      if (tasksRes.ok) {
        const tasksData = await tasksRes.json();
        setTasks(tasksData);
      }
      
      if (timeRes.ok) {
        const timeData = await timeRes.json();
        setTimeEntries(timeData);
      }

      // Load user membership to check role
      if (currentOrg) {
        const membersRes = await fetch(`/api/organizations/${currentOrg.id}/members`);
        if (membersRes.ok) {
          const members = await membersRes.json();
          const myMembership = members.find((m: OrganizationMember) => m.user_id === user?.id);
          setUserMembership(myMembership);
        }
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    }
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const handleOrganizationCreated = async () => {
    setShowCreateOrganization(false);
    await loadInitialData();
  };

  if (isPending || !user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
        <div className="animate-spin">
          <Loader2 className="w-12 h-12 text-indigo-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <nav className="border-b border-indigo-100 bg-white/80 backdrop-blur-sm sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 sm:space-x-4">
              <div className="flex items-center space-x-2 sm:space-x-3">
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/30">
                  <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
                <span className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                  TaskFlow
                </span>
              </div>
              {organization && (
                <div className="hidden sm:flex items-center space-x-2 px-3 py-1.5 bg-indigo-50 rounded-lg border border-indigo-100">
                  <Users className="w-4 h-4 text-indigo-600" />
                  <span className="text-sm font-medium text-indigo-700">{organization.name}</span>
                </div>
              )}
            </div>
            
            <div className="flex items-center space-x-2 sm:space-x-4">
              {organization && (
                <button
                  onClick={() => setShowInviteTeam(true)}
                  className="hidden sm:flex items-center space-x-2 px-4 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                >
                  <Users className="w-4 h-4" />
                  <span>Invite</span>
                </button>
              )}
              <div className="hidden sm:flex items-center space-x-3">
                {userMembership && (
                  <span className={`px-2 py-1 rounded-lg text-xs font-medium ${
                    userMembership.role === 'owner' ? 'bg-purple-100 text-purple-700' :
                    userMembership.role === 'admin' ? 'bg-blue-100 text-blue-700' :
                    userMembership.role === 'leader' ? 'bg-green-100 text-green-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {userMembership.role === 'owner' ? 'Owner' :
                     userMembership.role === 'admin' ? 'Admin' :
                     userMembership.role === 'leader' ? 'Leader' : 'Employee'}
                  </span>
                )}
                {user.google_user_data.picture && (
                  <img 
                    src={user.google_user_data.picture} 
                    alt={user.google_user_data.name || user.email}
                    className="w-8 h-8 rounded-full border-2 border-indigo-200"
                  />
                )}
                <span className="hidden md:block text-sm font-medium text-gray-700 max-w-[120px] truncate">
                  {user.google_user_data.name || user.email}
                </span>
              </div>
              <button
                onClick={handleLogout}
                className="hidden sm:block p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                title="Sign out"
              >
                <LogOut className="w-5 h-5" />
              </button>
              
              {/* Mobile menu button */}
              <button
                onClick={() => setShowMobileMenu(!showMobileMenu)}
                className="sm:hidden p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
              >
                {showMobileMenu ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>

          {/* Mobile menu dropdown */}
          {showMobileMenu && (
            <div className="sm:hidden mt-4 pb-4 border-t border-gray-100 pt-4 space-y-2">
              {organization && (
                <div className="px-3 py-2 bg-indigo-50 rounded-lg border border-indigo-100 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-indigo-600" />
                    <span className="text-sm font-medium text-indigo-700">{organization.name}</span>
                  </div>
                </div>
              )}
              <div className="flex items-center space-x-3 px-3 py-2">
                {user.google_user_data.picture && (
                  <img 
                    src={user.google_user_data.picture} 
                    alt={user.google_user_data.name || user.email}
                    className="w-8 h-8 rounded-full border-2 border-indigo-200"
                  />
                )}
                <div className="flex-1">
                  <span className="text-sm font-medium text-gray-700 block truncate">
                    {user.google_user_data.name || user.email}
                  </span>
                  {userMembership && (
                    <span className={`inline-block mt-1 px-2 py-0.5 rounded text-xs font-medium ${
                      userMembership.role === 'owner' ? 'bg-purple-100 text-purple-700' :
                      userMembership.role === 'admin' ? 'bg-blue-100 text-blue-700' :
                      userMembership.role === 'leader' ? 'bg-green-100 text-green-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {userMembership.role === 'owner' ? 'Owner' :
                       userMembership.role === 'admin' ? 'Admin' :
                       userMembership.role === 'leader' ? 'Leader' : 'Employee'}
                    </span>
                  )}
                </div>
              </div>
              {organization && (
                <button
                  onClick={() => {
                    setShowInviteTeam(true);
                    setShowMobileMenu(false);
                  }}
                  className="w-full flex items-center space-x-2 px-3 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                >
                  <Users className="w-4 h-4" />
                  <span>Invite Team</span>
                </button>
              )}
              <button
                onClick={handleLogout}
                className="w-full flex items-center space-x-2 px-3 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            </div>
          )}
        </div>
      </nav>

      {/* Main Content */}
      {!organization && !isLoading ? (
        <div className="flex items-center justify-center min-h-[80vh] px-4">
          <div className="text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-indigo-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Create Your Workspace</h2>
            <p className="text-gray-600 mb-6">Get started by creating a workspace for your team</p>
          </div>
        </div>
      ) : (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 sm:py-8">
          {/* View Tabs */}
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 sm:mb-8 space-y-4 sm:space-y-0">
            <div className="flex space-x-1 bg-white rounded-xl p-1 shadow-sm border border-indigo-100 overflow-x-auto scrollbar-hide">
              <button
                onClick={() => setActiveView('tasks')}
                className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium transition-all duration-200 whitespace-nowrap text-sm sm:text-base ${
                  activeView === 'tasks'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                Tasks
              </button>
              <button
                onClick={() => setActiveView('time')}
                className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium transition-all duration-200 whitespace-nowrap text-sm sm:text-base ${
                  activeView === 'time'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                Time
              </button>
              <button
                onClick={() => setActiveView('reports')}
                className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium transition-all duration-200 whitespace-nowrap text-sm sm:text-base ${
                  activeView === 'reports'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                Reports
              </button>
              {userMembership && (userMembership.role === 'owner' || userMembership.role === 'admin' || userMembership.role === 'leader') && (
                <>
                  <button
                    onClick={() => setActiveView('time-dashboard')}
                    className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium transition-all duration-200 whitespace-nowrap text-sm sm:text-base ${
                      activeView === 'time-dashboard'
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    Time Dashboard
                  </button>
                  <button
                    onClick={() => setActiveView('reports-dashboard')}
                    className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium transition-all duration-200 whitespace-nowrap text-sm sm:text-base ${
                      activeView === 'reports-dashboard'
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    Reports Dashboard
                  </button>
                </>
              )}
              {userMembership && (userMembership.role === 'owner' || userMembership.role === 'admin') && (
                <>
                  <button
                    onClick={() => setActiveView('report-forms')}
                    className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium transition-all duration-200 whitespace-nowrap text-sm sm:text-base ${
                      activeView === 'report-forms'
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    Report Forms
                  </button>
                  <button
                    onClick={() => setActiveView('approvals')}
                    className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium transition-all duration-200 whitespace-nowrap text-sm sm:text-base ${
                      activeView === 'approvals'
                        ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    Approvals
                  </button>
                </>
              )}
              <button
                onClick={() => setActiveView('team')}
                className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium transition-all duration-200 whitespace-nowrap flex items-center space-x-2 text-sm sm:text-base ${
                  activeView === 'team'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <MessageSquare className="w-4 h-4" />
                <span>Team</span>
              </button>
              <button
                onClick={() => setActiveView('settings')}
                className={`px-4 sm:px-6 py-2 sm:py-2.5 rounded-lg font-medium transition-all duration-200 whitespace-nowrap text-sm sm:text-base ${
                  activeView === 'settings'
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                Settings
              </button>
            </div>

            

            {activeView === 'team' && (
              <button
                onClick={() => setShowInviteTeam(true)}
                className="flex items-center justify-center space-x-2 px-4 sm:px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-xl hover:shadow-lg hover:shadow-indigo-500/30 transition-all duration-200 hover:scale-105"
              >
                <Users className="w-5 h-5" />
                <span>Invite</span>
              </button>
            )}
          </div>

          {/* Content */}
          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin">
                <Loader2 className="w-10 h-10 text-indigo-600" />
              </div>
            </div>
          ) : (
            <>
              {activeView === 'tasks' && (
                <CategoryTaskView tasks={tasks} onUpdate={loadData} />
              )}
              {activeView === 'time' && (
                <TimeManagement 
                  tasks={tasks}
                  timeEntries={timeEntries}
                  onUpdate={loadData} 
                />
              )}
              {activeView === 'reports' && (
                <MyDailyReport />
              )}
              {activeView === 'approvals' && (
                <ApprovalDashboard onUpdate={loadData} />
              )}
              {activeView === 'time-dashboard' && (
                <EmployeeTimeDashboard />
              )}
              {activeView === 'reports-dashboard' && (
                <EmployeeReportsDashboard />
              )}
              {activeView === 'report-forms' && (
                <ReportFormsManagement />
              )}
              {activeView === 'team' && (
                <div className="h-[calc(100vh-14rem)] sm:h-[calc(100vh-16rem)]">
                  <TeamChat />
                </div>
              )}
              {activeView === 'settings' && organization && (
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <button
                      onClick={() => setShowCategoryManagement(true)}
                      className="w-full sm:w-auto flex items-center justify-center space-x-2 px-4 sm:px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-xl hover:shadow-lg hover:shadow-indigo-500/30 transition-all duration-200 hover:scale-105"
                    >
                      <Plus className="w-5 h-5" />
                      <span>Manage Categories</span>
                    </button>
                  </div>
                  
                  {userMembership && (userMembership.role === 'owner' || userMembership.role === 'admin') && (
                    <UserGroupsManagement />
                  )}
                  
                  <OrganizationSettings organization={organization} />
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* Modals */}
      {showCreateOrganization && (
        <CreateOrganizationModal
          onClose={() => {}}
          onSuccess={handleOrganizationCreated}
          onSwitchToJoin={() => {
            setShowCreateOrganization(false);
            setShowJoinOrganization(true);
          }}
        />
      )}
      {showJoinOrganization && (
        <JoinOrganizationModal
          onClose={() => setShowJoinOrganization(false)}
          onSuccess={handleOrganizationCreated}
        />
      )}
      {showCreateTask && (
        <CreateTaskModal
          onClose={() => setShowCreateTask(false)}
          onSuccess={() => {
            setShowCreateTask(false);
            loadData();
          }}
        />
      )}
      {showCreateTimeEntry && (
        <CreateTimeEntryModal
          tasks={tasks}
          onClose={() => setShowCreateTimeEntry(false)}
          onSuccess={() => {
            setShowCreateTimeEntry(false);
            loadData();
          }}
        />
      )}
      {showInviteTeam && (
        <InviteTeamModal
          onClose={() => setShowInviteTeam(false)}
          onSuccess={() => {
            setShowInviteTeam(false);
          }}
        />
      )}
      {showCategoryManagement && (
        <CategoryManagementModal
          onClose={() => setShowCategoryManagement(false)}
          onUpdate={loadData}
        />
      )}
    </div>
  );
}
