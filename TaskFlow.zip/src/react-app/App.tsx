import { BrowserRouter as Router, Routes, Route } from "react-router";
import { AuthProvider } from "@getmocha/users-service/react";
import HomePage from "@/react-app/pages/Home";
import AuthCallbackPage from "@/react-app/pages/AuthCallback";
import DashboardPage from "@/react-app/pages/Dashboard";
import InviteAcceptPage from "@/react-app/pages/InviteAccept";
import MyDailyReportPage from "@/react-app/pages/MyDailyReport";
import DailyReportPage from "@/react-app/pages/DailyReport";

export default function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/auth/callback" element={<AuthCallbackPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/invite/:token" element={<InviteAcceptPage />} />
          <Route path="/my-daily-report" element={<MyDailyReportPage />} />
          <Route path="/daily-report" element={<DailyReportPage />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
