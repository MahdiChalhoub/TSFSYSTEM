import { useState, useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { User, Shield } from 'lucide-react';
import { OrganizationMember } from '@/shared/organization-types';

export default function UserProfile() {
  const { user } = useAuth();
  const [membership, setMembership] = useState<OrganizationMember | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadMembership();
  }, []);

  const loadMembership = async () => {
    try {
      const orgRes = await fetch('/api/organizations/current');
      if (orgRes.ok) {
        const org = await orgRes.json();
        if (org) {
          const membersRes = await fetch(`/api/organizations/${org.id}/members`);
          if (membersRes.ok) {
            const members = await membersRes.json();
            const myMembership = members.find((m: OrganizationMember) => m.user_id === user?.id);
            setMembership(myMembership);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load membership:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const getRoleBadge = (role: string) => {
    const badges: Record<string, { bg: string; text: string; label: string }> = {
      owner: { bg: 'bg-purple-100', text: 'text-purple-700', label: 'Owner' },
      admin: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'Admin' },
      leader: { bg: 'bg-green-100', text: 'text-green-700', label: 'Leader' },
      member: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'Employee' },
    };
    const badge = badges[role] || badges.member;
    return (
      <span className={`inline-flex items-center space-x-1 px-3 py-1 ${badge.bg} ${badge.text} rounded-full text-sm font-medium`}>
        <Shield className="w-4 h-4" />
        <span>{badge.label}</span>
      </span>
    );
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-32 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-48"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
          <User className="w-5 h-5 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">My Profile</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
          <div className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-gray-700">
            {membership?.name || user?.google_user_data?.name || user?.email || 'Unknown'}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
          <div className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-gray-700">
            {user?.email || 'Unknown'}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
          <div>
            {membership ? getRoleBadge(membership.role) : (
              <span className="text-gray-400">No role assigned</span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
