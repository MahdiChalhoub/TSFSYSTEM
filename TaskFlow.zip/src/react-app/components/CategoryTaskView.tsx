import { useState, useEffect } from 'react';
import { Task, TaskCategory } from '@/shared/types';
import { OrganizationMember } from '@/shared/organization-types';
import { GripVertical, FolderKanban, Plus, User, ChevronDown, ChevronRight, Menu, X, Filter, Calendar } from 'lucide-react';
import EditTaskModal from './EditTaskModal';
import CreateTaskModal from './CreateTaskModal';
import TaskCard from './TaskCard';

interface CategoryTaskViewProps {
  tasks: Task[];
  onUpdate: () => void;
}

type CategorySelection = 'all' | null | number;
type UserSelection = string | null;

export default function CategoryTaskView({ tasks, onUpdate }: CategoryTaskViewProps) {
  const [categories, setCategories] = useState<TaskCategory[]>([]);
  const [members, setMembers] = useState<OrganizationMember[]>([]);
  const [selectedCategoryId, setSelectedCategoryId] = useState<CategorySelection>('all');
  const [selectedUserId, setSelectedUserId] = useState<UserSelection>(null);
  const [expandedCategories, setExpandedCategories] = useState<Set<number>>(new Set());
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [showCreateTask, setShowCreateTask] = useState(false);
  const [draggedCategoryId, setDraggedCategoryId] = useState<number | null>(null);
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [showCompletedTasks, setShowCompletedTasks] = useState(false);
  
  // Filter states
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterStartDate, setFilterStartDate] = useState<string>('');
  const [filterEndDate, setFilterEndDate] = useState<string>('');
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [categoriesRes, orgRes] = await Promise.all([
        fetch('/api/task-categories'),
        fetch('/api/organizations/current')
      ]);

      if (categoriesRes.ok) {
        const categoriesData = await categoriesRes.json();
        setCategories(categoriesData);
      }

      if (orgRes.ok) {
        const orgData = await orgRes.json();
        if (orgData) {
          const membersRes = await fetch(`/api/organizations/${orgData.id}/members`);
          if (membersRes.ok) {
            const membersData = await membersRes.json();
            setMembers(membersData);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    }
  };

  const handleDragStart = (categoryId: number) => {
    setDraggedCategoryId(categoryId);
  };

  const handleDragOver = (e: React.DragEvent, targetCategoryId: number) => {
    e.preventDefault();
    if (draggedCategoryId === null || draggedCategoryId === targetCategoryId) return;

    const draggedIndex = categories.findIndex(c => c.id === draggedCategoryId);
    const targetIndex = categories.findIndex(c => c.id === targetCategoryId);

    if (draggedIndex === -1 || targetIndex === -1) return;

    const newCategories = [...categories];
    const [draggedCategory] = newCategories.splice(draggedIndex, 1);
    newCategories.splice(targetIndex, 0, draggedCategory);

    setCategories(newCategories);
  };

  const handleDragEnd = async () => {
    if (draggedCategoryId === null) return;

    try {
      await fetch('/api/task-categories/reorder', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          category_ids: categories.map(c => c.id),
        }),
      });
    } catch (error) {
      console.error('Failed to reorder categories:', error);
      loadData();
    }

    setDraggedCategoryId(null);
  };

  const toggleCategoryExpanded = (categoryId: number) => {
    const newExpanded = new Set(expandedCategories);
    if (newExpanded.has(categoryId)) {
      newExpanded.delete(categoryId);
    } else {
      newExpanded.add(categoryId);
    }
    setExpandedCategories(newExpanded);
  };

  const handleCategoryClick = (categoryId: CategorySelection) => {
    setSelectedCategoryId(categoryId);
    setSelectedUserId(null);
    setShowMobileSidebar(false);
  };

  const handleUserClick = (categoryId: number, userId: string) => {
    setSelectedCategoryId(categoryId);
    setSelectedUserId(userId);
    setShowMobileSidebar(false);
  };

  const handleQuickComplete = async (taskId: number, currentStatus: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newStatus = currentStatus === 'completed' ? 'pending' : 'completed';
    
    try {
      const response = await fetch(`/api/tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (response.ok) {
        onUpdate();
      }
    } catch (error) {
      console.error('Failed to update task status:', error);
    }
  };

  const getFilteredTasks = () => {
    let filtered = tasks;

    // Category filter
    if (selectedCategoryId === 'all') {
      // Show all tasks
    } else if (selectedCategoryId === null) {
      filtered = filtered.filter(t => !t.category_id);
    } else {
      filtered = filtered.filter(t => t.category_id === selectedCategoryId);
    }

    // User filter
    if (selectedUserId) {
      filtered = filtered.filter(t => t.assigned_to_user_id === selectedUserId);
    }

    // Status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(t => t.status === filterStatus);
    }

    // Priority filter
    if (filterPriority !== 'all') {
      filtered = filtered.filter(t => t.priority === filterPriority);
    }

    // Date filter
    if (filterStartDate) {
      filtered = filtered.filter(t => {
        if (!t.due_date) return false;
        return t.due_date >= filterStartDate;
      });
    }
    if (filterEndDate) {
      filtered = filtered.filter(t => {
        if (!t.due_date) return false;
        return t.due_date <= filterEndDate;
      });
    }

    return filtered;
  };

  const filteredTasks = getFilteredTasks();
  const activeTasks = filteredTasks.filter(t => t.status !== 'completed');
  const completedTasks = filteredTasks.filter(t => t.status === 'completed');

  const getTaskCountForCategory = (categoryId: number | null) => {
    if (categoryId === null) {
      return tasks.filter(t => !t.category_id).length;
    }
    return tasks.filter(t => t.category_id === categoryId).length;
  };

  const getTaskCountForUser = (categoryId: number, userId: string) => {
    return tasks.filter(t => t.category_id === categoryId && t.assigned_to_user_id === userId).length;
  };

  const getUsersForCategory = (categoryId: number) => {
    const userIds = new Set(
      tasks
        .filter(t => t.category_id === categoryId && t.assigned_to_user_id)
        .map(t => t.assigned_to_user_id as string)
    );
    return members.filter(m => userIds.has(m.user_id));
  };

  const getMemberName = (userId: string) => {
    const member = members.find(m => m.user_id === userId);
    return member ? (member.name || member.email || 'Unknown') : 'Unknown';
  };

  const getDisplayTitle = () => {
    if (selectedCategoryId === 'all') {
      return 'All Tasks';
    }
    if (selectedCategoryId === null) {
      return 'Uncategorized Tasks';
    }
    const category = categories.find(c => c.id === selectedCategoryId);
    if (selectedUserId) {
      return `${category?.name || 'Tasks'} - ${getMemberName(selectedUserId)}`;
    }
    return category?.name || 'Tasks';
  };

  const clearFilters = () => {
    setFilterStatus('all');
    setFilterPriority('all');
    setFilterStartDate('');
    setFilterEndDate('');
  };

  const hasActiveFilters = filterStatus !== 'all' || filterPriority !== 'all' || filterStartDate || filterEndDate;

  const SidebarContent = () => (
    <div className="bg-white rounded-xl shadow-sm border border-indigo-50 overflow-hidden">
      <div className="bg-gradient-to-r from-indigo-50 to-purple-50 px-4 py-3 border-b border-indigo-100">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold text-gray-900 flex items-center space-x-2">
            <FolderKanban className="w-5 h-5 text-indigo-600" />
            <span>Categories</span>
          </h3>
          <button
            onClick={() => setShowMobileSidebar(false)}
            className="lg:hidden p-1 hover:bg-indigo-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>
      </div>
      
      <div className="max-h-[calc(100vh-12rem)] overflow-y-auto">
        {/* All Tasks */}
        <button
          onClick={() => handleCategoryClick('all')}
          className={`w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-100 ${
            selectedCategoryId === 'all' && !selectedUserId ? 'bg-indigo-50 border-l-4 border-l-indigo-600' : ''
          }`}
        >
          <span className="font-medium text-gray-900">All Tasks</span>
          <span className="text-sm font-semibold text-gray-600 bg-gray-100 px-2 py-0.5 rounded-full">
            {tasks.length}
          </span>
        </button>

        {/* Uncategorized */}
        {getTaskCountForCategory(null) > 0 && (
          <button
            onClick={() => handleCategoryClick(null)}
            className={`w-full px-4 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors border-b border-gray-100 ${
              selectedCategoryId === null && !selectedUserId ? 'bg-indigo-50 border-l-4 border-l-indigo-600' : ''
            }`}
          >
            <span className="font-medium text-gray-600">Uncategorized</span>
            <span className="text-sm font-semibold text-gray-600 bg-gray-100 px-2 py-0.5 rounded-full">
              {getTaskCountForCategory(null)}
            </span>
          </button>
        )}

        {/* Categories */}
        {categories.map((category) => {
          const categoryUsers = getUsersForCategory(category.id);
          const isExpanded = expandedCategories.has(category.id);
          const hasUsers = categoryUsers.length > 0;

          return (
            <div
              key={category.id}
              draggable
              onDragStart={() => handleDragStart(category.id)}
              onDragOver={(e) => handleDragOver(e, category.id)}
              onDragEnd={handleDragEnd}
              className={`border-b border-gray-100 ${
                draggedCategoryId === category.id ? 'opacity-50' : ''
              }`}
            >
              {/* Category Header */}
              <div
                className={`flex items-center ${
                  selectedCategoryId === category.id && !selectedUserId ? 'bg-indigo-50 border-l-4 border-l-indigo-600' : ''
                }`}
              >
                {hasUsers && (
                  <button
                    onClick={() => toggleCategoryExpanded(category.id)}
                    className="px-2 py-3 hover:bg-gray-100 transition-colors"
                  >
                    {isExpanded ? (
                      <ChevronDown className="w-4 h-4 text-gray-500" />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-gray-500" />
                    )}
                  </button>
                )}
                <button
                  onClick={() => handleCategoryClick(category.id)}
                  className={`flex-1 py-3 flex items-center justify-between hover:bg-gray-50 transition-colors ${
                    hasUsers ? 'pl-0' : 'pl-4'
                  } pr-4`}
                >
                  <div className="flex items-center space-x-2 flex-1 min-w-0">
                    <GripVertical className="w-4 h-4 text-gray-400 flex-shrink-0 cursor-grab active:cursor-grabbing" />
                    <span className="font-medium text-gray-900 truncate">{category.name}</span>
                  </div>
                  <span className="text-sm font-semibold text-gray-600 bg-gray-100 px-2 py-0.5 rounded-full ml-2">
                    {getTaskCountForCategory(category.id)}
                  </span>
                </button>
              </div>

              {/* User Sub-items */}
              {isExpanded && categoryUsers.length > 0 && (
                <div className="bg-gray-50">
                  {categoryUsers.map((user) => (
                    <button
                      key={user.user_id}
                      onClick={() => handleUserClick(category.id, user.user_id)}
                      className={`w-full pl-12 pr-4 py-2.5 flex items-center justify-between hover:bg-gray-100 transition-colors ${
                        selectedCategoryId === category.id && selectedUserId === user.user_id
                          ? 'bg-indigo-100 border-l-4 border-l-indigo-600'
                          : ''
                      }`}
                    >
                      <div className="flex items-center space-x-2 flex-1 min-w-0">
                        <User className="w-4 h-4 text-gray-500 flex-shrink-0" />
                        <span className="text-sm text-gray-700 truncate">
                          {user.name || user.email || 'Unknown'}
                        </span>
                      </div>
                      <span className="text-xs font-semibold text-gray-600 bg-gray-200 px-2 py-0.5 rounded-full ml-2">
                        {getTaskCountForUser(category.id, user.user_id)}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          );
        })}

        {categories.length === 0 && (
          <div className="px-4 py-8 text-center text-gray-500 text-sm">
            <p>No categories yet.</p>
            <p className="mt-1">Create categories in Settings.</p>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">
      {/* Mobile Category Toggle Button */}
      <button
        onClick={() => setShowMobileSidebar(!showMobileSidebar)}
        className="lg:hidden flex items-center justify-center space-x-2 px-4 py-3 bg-white border border-indigo-100 rounded-xl shadow-sm"
      >
        <Menu className="w-5 h-5 text-indigo-600" />
        <span className="font-medium text-gray-900">Categories</span>
      </button>

      {/* Mobile Sidebar Overlay */}
      {showMobileSidebar && (
        <div className="lg:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-30" onClick={() => setShowMobileSidebar(false)}>
          <div className="absolute left-0 top-0 bottom-0 w-80 max-w-[85vw]" onClick={(e) => e.stopPropagation()}>
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Desktop Category Sidebar */}
      <div className="hidden lg:block w-80 flex-shrink-0">
        <div className="sticky top-24">
          <SidebarContent />
        </div>
      </div>

      {/* Tasks Area */}
      <div className="flex-1 min-w-0">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 sm:mb-6 space-y-3 sm:space-y-0">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-900">
              {getDisplayTitle()}
            </h2>
            <p className="text-sm text-gray-600 mt-1">
              {activeTasks.length} active, {completedTasks.length} completed
            </p>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center space-x-2 px-3 sm:px-4 py-2 border rounded-lg font-medium transition-all ${
                hasActiveFilters 
                  ? 'bg-indigo-50 border-indigo-300 text-indigo-700' 
                  : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
              }`}
            >
              <Filter className="w-4 h-4" />
              <span className="hidden sm:inline">Filter</span>
              {hasActiveFilters && <span className="bg-indigo-600 text-white text-xs px-1.5 py-0.5 rounded-full">•</span>}
            </button>
            <button
              onClick={() => setShowCreateTask(true)}
              className="flex items-center justify-center space-x-2 px-4 sm:px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-xl hover:shadow-lg hover:shadow-indigo-500/30 transition-all duration-200 hover:scale-105"
            >
              <Plus className="w-5 h-5" />
              <span className="hidden sm:inline">New Task</span>
            </button>
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="bg-white rounded-xl p-4 shadow-sm border border-indigo-100 mb-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                >
                  <option value="all">All Status</option>
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Priority</label>
                <select
                  value={filterPriority}
                  onChange={(e) => setFilterPriority(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                >
                  <option value="all">All Priorities</option>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center space-x-1">
                  <Calendar className="w-3 h-3" />
                  <span>Start Date</span>
                </label>
                <input
                  type="date"
                  value={filterStartDate}
                  onChange={(e) => setFilterStartDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center space-x-1">
                  <Calendar className="w-3 h-3" />
                  <span>End Date</span>
                </label>
                <input
                  type="date"
                  value={filterEndDate}
                  onChange={(e) => setFilterEndDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                />
              </div>
            </div>

            {hasActiveFilters && (
              <div className="mt-3 flex justify-end">
                <button
                  onClick={clearFilters}
                  className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
                >
                  Clear all filters
                </button>
              </div>
            )}
          </div>
        )}

        {/* Active Tasks */}
        {activeTasks.length === 0 && completedTasks.length === 0 ? (
          <div className="text-center py-12 sm:py-20">
            <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <FolderKanban className="w-8 h-8 text-indigo-600" />
            </div>
            <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2">No tasks found</h3>
            <p className="text-gray-600">Create a task to get started</p>
          </div>
        ) : (
          <>
            {activeTasks.length > 0 && (
              <div className="grid gap-3 sm:gap-4 mb-6">
                {activeTasks.map((task) => (
                  <TaskCard 
                    key={task.id} 
                    task={task} 
                    categories={categories}
                    members={members}
                    onClick={() => setEditingTask(task)}
                    onQuickComplete={(e) => handleQuickComplete(task.id, task.status, e)}
                  />
                ))}
              </div>
            )}

            {/* Completed Tasks Section */}
            {completedTasks.length > 0 && (
              <div className="mt-8">
                <button
                  onClick={() => setShowCompletedTasks(!showCompletedTasks)}
                  className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 rounded-xl border border-gray-200 hover:bg-gray-100 transition-colors mb-4"
                >
                  <div className="flex items-center space-x-2">
                    <ChevronRight className={`w-5 h-5 text-gray-500 transition-transform ${showCompletedTasks ? 'rotate-90' : ''}`} />
                    <span className="font-semibold text-gray-700">Completed Tasks</span>
                    <span className="text-sm text-gray-500 bg-gray-200 px-2 py-0.5 rounded-full">
                      {completedTasks.length}
                    </span>
                  </div>
                </button>

                {showCompletedTasks && (
                  <div className="grid gap-3 sm:gap-4">
                    {completedTasks.map((task) => (
                      <TaskCard 
                        key={task.id} 
                        task={task} 
                        categories={categories}
                        members={members}
                        onClick={() => setEditingTask(task)}
                        onQuickComplete={(e) => handleQuickComplete(task.id, task.status, e)}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* Modals */}
      {editingTask && (
        <EditTaskModal
          task={editingTask}
          onClose={() => setEditingTask(null)}
          onSuccess={() => {
            setEditingTask(null);
            onUpdate();
            loadData();
          }}
        />
      )}
      {showCreateTask && (
        <CreateTaskModal
          onClose={() => setShowCreateTask(false)}
          onSuccess={() => {
            setShowCreateTask(false);
            onUpdate();
          }}
          defaultCategoryId={typeof selectedCategoryId === 'number' ? selectedCategoryId : undefined}
          defaultAssignedUserId={selectedUserId || undefined}
        />
      )}
    </div>
  );
}
