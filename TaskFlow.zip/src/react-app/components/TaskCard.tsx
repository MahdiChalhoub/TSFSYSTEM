import { Task, TaskCategory } from '@/shared/types';
import { OrganizationMember } from '@/shared/organization-types';
import { Clock, User, Calendar, CheckCircle2, Circle, XCircle, FolderKanban } from 'lucide-react';

interface TaskCardProps {
  task: Task;
  categories: TaskCategory[];
  members?: OrganizationMember[];
  onClick: () => void;
  onQuickComplete: (e: React.MouseEvent) => void;
}

export default function TaskCard({ task, categories, members, onClick, onQuickComplete }: TaskCardProps) {
  const getCategoryName = (categoryId: number | null) => {
    if (!categoryId) return null;
    const category = categories.find(c => c.id === categoryId);
    return category?.name;
  };

  const getAssignedUserName = (userId: string | null) => {
    if (!userId || !members) return null;
    const member = members.find(m => m.user_id === userId);
    return member ? (member.name || member.email || 'Unknown') : 'Unknown';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'in_progress':
        return <Clock className="w-5 h-5 text-blue-600" />;
      case 'cancelled':
        return <XCircle className="w-5 h-5 text-gray-400" />;
      default:
        return <Circle className="w-5 h-5 text-gray-400" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'in_progress':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'cancelled':
        return 'bg-gray-100 text-gray-500 border-gray-200';
      default:
        return 'bg-purple-100 text-purple-700 border-purple-200';
    }
  };

  const isCompleted = task.status === 'completed';

  return (
    <div
      onClick={onClick}
      className={`bg-white rounded-xl p-6 shadow-sm border border-indigo-50 hover:shadow-lg hover:border-indigo-200 transition-all duration-200 cursor-pointer ${
        isCompleted ? 'opacity-60' : ''
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-start space-x-3 flex-1">
          <div className="mt-0.5">
            {getStatusIcon(task.status)}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className={`text-lg font-semibold mb-1 ${
              isCompleted ? 'line-through text-gray-500' : 'text-gray-900'
            }`}>
              {task.title}
            </h3>
            {task.description && (
              <p className="text-gray-600 text-sm line-clamp-2">
                {task.description}
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center space-x-2 ml-4">
          <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getPriorityColor(task.priority)}`}>
            {task.priority}
          </span>
          <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getStatusColor(task.status)}`}>
            {task.status.replace('_', ' ')}
          </span>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4 text-sm text-gray-500">
          {getCategoryName(task.category_id) && (
            <div className="flex items-center space-x-1.5">
              <FolderKanban className="w-4 h-4" />
              <span>{getCategoryName(task.category_id)}</span>
            </div>
          )}
          {task.due_date && (
            <div className="flex items-center space-x-1.5">
              <Calendar className="w-4 h-4" />
              <span>Due {new Date(task.due_date).toLocaleDateString()}</span>
            </div>
          )}
          {task.assigned_to_user_id && (
            <div className="flex items-center space-x-1.5">
              <User className="w-4 h-4" />
              <span>{getAssignedUserName(task.assigned_to_user_id)}</span>
            </div>
          )}
        </div>

        <button
          onClick={onQuickComplete}
          className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 ${
            isCompleted ? 'bg-green-600' : 'bg-gray-300'
          }`}
          title={isCompleted ? 'Mark as incomplete' : 'Mark as complete'}
        >
          <span
            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
              isCompleted ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>
      </div>
    </div>
  );
}
