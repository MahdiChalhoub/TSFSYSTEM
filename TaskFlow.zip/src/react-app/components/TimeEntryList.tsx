import { useState } from 'react';
import { TimeEntry, Task } from '@/shared/types';
import { Clock, Calendar, FileText } from 'lucide-react';
import EditTimeEntryModal from './EditTimeEntryModal';

interface TimeEntryListProps {
  timeEntries: TimeEntry[];
  tasks: Task[];
  onUpdate: () => void;
}

export default function TimeEntryList({ timeEntries, tasks, onUpdate }: TimeEntryListProps) {
  const [editingEntry, setEditingEntry] = useState<TimeEntry | null>(null);

  const getTaskTitle = (taskId: number) => {
    const task = tasks.find(t => t.id === taskId);
    return task?.title || 'Unknown Task';
  };

  const groupedEntries = timeEntries.reduce((acc, entry) => {
    const date = entry.entry_date;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(entry);
    return acc;
  }, {} as Record<string, TimeEntry[]>);

  const sortedDates = Object.keys(groupedEntries).sort((a, b) => b.localeCompare(a));

  if (timeEntries.length === 0) {
    return (
      <div className="text-center py-12 sm:py-20">
        <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Clock className="w-8 h-8 text-indigo-600" />
        </div>
        <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2">No time entries yet</h3>
        <p className="text-gray-600">Start logging time to track your work</p>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-4 sm:space-y-6">
        {sortedDates.map((date) => {
          const entries = groupedEntries[date];
          const totalHours = entries.reduce((sum, e) => sum + e.hours, 0);

          return (
            <div key={date} className="bg-white rounded-xl shadow-sm border border-indigo-50 overflow-hidden">
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 px-4 sm:px-6 py-3 sm:py-4 border-b border-indigo-100">
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
                  <div className="flex items-center space-x-2 sm:space-x-3">
                    <Calendar className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-600 flex-shrink-0" />
                    <h3 className="text-base sm:text-lg font-semibold text-gray-900">
                      {new Date(date).toLocaleDateString('en-US', { 
                        weekday: 'long', 
                        year: 'numeric', 
                        month: 'long', 
                        day: 'numeric' 
                      })}
                    </h3>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-600 flex-shrink-0" />
                    <span className="text-base sm:text-lg font-bold text-indigo-600">
                      {totalHours.toFixed(1)}h
                    </span>
                  </div>
                </div>
              </div>

              <div className="divide-y divide-gray-100">
                {entries.map((entry) => (
                  <div
                    key={entry.id}
                    onClick={() => setEditingEntry(entry)}
                    className="px-4 sm:px-6 py-3 sm:py-4 hover:bg-gray-50 transition-colors cursor-pointer"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between space-y-2 sm:space-y-0">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-gray-900 mb-1 break-words">
                          {getTaskTitle(entry.task_id)}
                        </h4>
                        {entry.description && (
                          <div className="flex items-start space-x-2 text-sm text-gray-600">
                            <FileText className="w-4 h-4 mt-0.5 flex-shrink-0" />
                            <p className="line-clamp-2 break-words">{entry.description}</p>
                          </div>
                        )}
                      </div>
                      <div className="flex items-center space-x-2 text-indigo-600 font-semibold flex-shrink-0">
                        <Clock className="w-4 h-4" />
                        <span>{entry.hours}h</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {editingEntry && (
        <EditTimeEntryModal
          entry={editingEntry}
          tasks={tasks}
          onClose={() => setEditingEntry(null)}
          onSuccess={() => {
            setEditingEntry(null);
            onUpdate();
          }}
        />
      )}
    </>
  );
}
