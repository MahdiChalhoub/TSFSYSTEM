import { useState, useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { FileText, Save, Plus, Trash2, Clock } from 'lucide-react';
import { Task } from '@/shared/types';

interface ReportForm {
  id: number;
  title: string;
  description: string | null;
  is_active: boolean;
}

interface ReportQuestion {
  id: number;
  question_text: string;
  question_type: string;
  is_required: boolean;
}

interface QuestionChoice {
  id: number;
  question_id: number;
  choice_text: string;
  sort_order: number;
}

interface ReportSubmission {
  id: number;
  report_date: string;
  status: string;
  submitted_at: string | null;
}

interface AdditionalTask {
  id?: number;
  task_description: string;
  hours_spent: number;
}

export default function MyReportForm() {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [forms, setForms] = useState<ReportForm[]>([]);
  const [questions, setQuestions] = useState<ReportQuestion[]>([]);
  const [questionChoices, setQuestionChoices] = useState<Record<number, QuestionChoice[]>>({});
  const [submission, setSubmission] = useState<ReportSubmission | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [additionalTasks, setAdditionalTasks] = useState<AdditionalTask[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadData();
  }, [selectedDate]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [formsRes, tasksRes, submissionRes] = await Promise.all([
        fetch('/api/my-assigned-forms'),
        fetch('/api/tasks'),
        fetch(`/api/my-report-submission?date=${selectedDate}`)
      ]);

      if (formsRes.ok) {
        const formsData = await formsRes.json();
        setForms(formsData.filter((f: ReportForm) => f.is_active));
        
        if (formsData.length > 0) {
          const questionsRes = await fetch(`/api/report-forms/${formsData[0].id}/questions`);
          if (questionsRes.ok) {
            const questionsData = await questionsRes.json();
            setQuestions(questionsData);
            
            // Load choices for single/multiple choice questions
            for (const question of questionsData) {
              if (question.question_type === 'single_choice' || question.question_type === 'multiple_choice') {
                const choicesRes = await fetch(`/api/questions/${question.id}/choices`);
                if (choicesRes.ok) {
                  const choicesData = await choicesRes.json();
                  setQuestionChoices(prev => ({ ...prev, [question.id]: choicesData }));
                }
              }
            }
          }
        }
      }

      if (tasksRes.ok) {
        const tasksData = await tasksRes.json();
        setTasks(tasksData.filter((t: Task) => t.assigned_to_user_id === user?.id));
      }

      if (submissionRes.ok) {
        const subData = await submissionRes.json();
        if (subData) {
          setSubmission(subData);
          
          // Load answers
          const answersRes = await fetch(`/api/report-submissions/${subData.id}/answers`);
          if (answersRes.ok) {
            const answersData = await answersRes.json();
            const answersMap: Record<number, string> = {};
            answersData.forEach((a: any) => {
              answersMap[a.question_id] = a.answer_text || '';
            });
            setAnswers(answersMap);
          }

          // Load additional tasks
          const additionalRes = await fetch(`/api/report-submissions/${subData.id}/additional-tasks`);
          if (additionalRes.ok) {
            const additionalData = await additionalRes.json();
            setAdditionalTasks(additionalData);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveDraft = async () => {
    setIsSaving(true);
    try {
      let submissionId = submission?.id;

      if (!submissionId) {
        // Create submission
        const response = await fetch('/api/my-report-submission', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            report_date: selectedDate,
            form_id: forms[0]?.id || null,
            status: 'draft'
          })
        });

        if (response.ok) {
          const newSub = await response.json();
          submissionId = newSub.id;
          setSubmission(newSub);
        }
      }

      if (submissionId) {
        // Save answers
        await fetch(`/api/report-submissions/${submissionId}/answers`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ answers: Object.entries(answers).map(([qId, text]) => ({
            question_id: parseInt(qId),
            answer_text: text
          }))})
        });

        // Save additional tasks
        await fetch(`/api/report-submissions/${submissionId}/additional-tasks`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tasks: additionalTasks })
        });
      }

      await loadData();
    } catch (error) {
      console.error('Failed to save:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSubmit = async () => {
    await handleSaveDraft();
    
    if (submission?.id) {
      try {
        await fetch(`/api/report-submissions/${submission.id}/submit`, {
          method: 'POST'
        });
        await loadData();
      } catch (error) {
        console.error('Failed to submit:', error);
      }
    }
  };

  const addAdditionalTask = () => {
    setAdditionalTasks([...additionalTasks, { task_description: '', hours_spent: 0 }]);
  };

  const removeAdditionalTask = (index: number) => {
    setAdditionalTasks(additionalTasks.filter((_, i) => i !== index));
  };

  const updateAdditionalTask = (index: number, field: keyof AdditionalTask, value: any) => {
    const updated = [...additionalTasks];
    updated[index] = { ...updated[index], [field]: value };
    setAdditionalTasks(updated);
  };

  const handleSingleChoiceChange = (questionId: number, value: string) => {
    setAnswers({ ...answers, [questionId]: value });
  };

  const handleMultipleChoiceChange = (questionId: number, choiceText: string, checked: boolean) => {
    const currentAnswers = answers[questionId] ? answers[questionId].split(',').filter(a => a.trim()) : [];
    let newAnswers: string[];
    
    if (checked) {
      newAnswers = [...currentAnswers, choiceText];
    } else {
      newAnswers = currentAnswers.filter(a => a !== choiceText);
    }
    
    setAnswers({ ...answers, [questionId]: newAnswers.join(',') });
  };

  const isChoiceSelected = (questionId: number, choiceText: string) => {
    const currentAnswers = answers[questionId] ? answers[questionId].split(',').filter(a => a.trim()) : [];
    return currentAnswers.includes(choiceText);
  };

  const completedTasks = tasks.filter(t => t.status === 'completed' && t.updated_at?.startsWith(selectedDate));
  const failedTasks = tasks.filter(t => t.status === 'cancelled' && t.updated_at?.startsWith(selectedDate));
  const pendingTasks = tasks.filter(t => t.status === 'pending' || t.status === 'in_progress');

  const isSubmitted = submission?.status === 'submitted';

  if (isLoading) {
    return <div className="text-center py-8">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Date Selector */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">My Daily Report</h2>
        <input
          type="date"
          value={selectedDate}
          onChange={(e) => setSelectedDate(e.target.value)}
          disabled={isSubmitted}
          className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-100"
        />
      </div>

      {/* Task Summary */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Task Summary</h3>
        <div className="grid grid-cols-3 gap-4">
          <div className="text-center p-4 bg-green-50 rounded-lg">
            <div className="text-2xl font-bold text-green-700">{completedTasks.length}</div>
            <div className="text-sm text-green-600">Completed</div>
          </div>
          <div className="text-center p-4 bg-red-50 rounded-lg">
            <div className="text-2xl font-bold text-red-700">{failedTasks.length}</div>
            <div className="text-sm text-red-600">Failed</div>
          </div>
          <div className="text-center p-4 bg-yellow-50 rounded-lg">
            <div className="text-2xl font-bold text-yellow-700">{pendingTasks.length}</div>
            <div className="text-sm text-yellow-600">Pending</div>
          </div>
        </div>
      </div>

      {/* Report Form Questions */}
      {questions.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
            <FileText className="w-5 h-5 text-indigo-600" />
            <span>Report Questions</span>
          </h3>
          <div className="space-y-6">
            {questions.map((question) => {
              const choices = questionChoices[question.id] || [];
              
              return (
                <div key={question.id}>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {question.question_text}
                    {question.is_required && <span className="text-red-500 ml-1">*</span>}
                  </label>
                  
                  {question.question_type === 'text' && (
                    <textarea
                      value={answers[question.id] || ''}
                      onChange={(e) => setAnswers({ ...answers, [question.id]: e.target.value })}
                      disabled={isSubmitted}
                      rows={3}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-100"
                      placeholder="Enter your answer..."
                    />
                  )}
                  
                  {question.question_type === 'single_choice' && (
                    <div className="space-y-2">
                      {choices.map((choice) => (
                        <label key={choice.id} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                          <input
                            type="radio"
                            name={`question_${question.id}`}
                            value={choice.choice_text}
                            checked={answers[question.id] === choice.choice_text}
                            onChange={(e) => handleSingleChoiceChange(question.id, e.target.value)}
                            disabled={isSubmitted}
                            className="text-indigo-600 focus:ring-indigo-500"
                          />
                          <span className="text-gray-700">{choice.choice_text}</span>
                        </label>
                      ))}
                      {choices.length === 0 && (
                        <p className="text-sm text-gray-400 italic">No choices available</p>
                      )}
                    </div>
                  )}
                  
                  {question.question_type === 'multiple_choice' && (
                    <div className="space-y-2">
                      {choices.map((choice) => (
                        <label key={choice.id} className="flex items-center space-x-3 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                          <input
                            type="checkbox"
                            checked={isChoiceSelected(question.id, choice.choice_text)}
                            onChange={(e) => handleMultipleChoiceChange(question.id, choice.choice_text, e.target.checked)}
                            disabled={isSubmitted}
                            className="rounded text-indigo-600 focus:ring-indigo-500"
                          />
                          <span className="text-gray-700">{choice.choice_text}</span>
                        </label>
                      ))}
                      {choices.length === 0 && (
                        <p className="text-sm text-gray-400 italic">No choices available</p>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Additional Tasks */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Additional Tasks (Not in System)</h3>
          {!isSubmitted && (
            <button
              onClick={addAdditionalTask}
              className="flex items-center space-x-2 px-3 py-2 text-sm bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add Task</span>
            </button>
          )}
        </div>
        <div className="space-y-3">
          {additionalTasks.map((task, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <div className="flex-1">
                <input
                  type="text"
                  value={task.task_description}
                  onChange={(e) => updateAdditionalTask(index, 'task_description', e.target.value)}
                  disabled={isSubmitted}
                  placeholder="Task description"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-100"
                />
              </div>
              <div className="w-32">
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4 text-gray-500" />
                  <input
                    type="number"
                    value={task.hours_spent}
                    onChange={(e) => updateAdditionalTask(index, 'hours_spent', parseFloat(e.target.value))}
                    disabled={isSubmitted}
                    step="0.25"
                    min="0"
                    placeholder="Hours"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 disabled:bg-gray-100"
                  />
                </div>
              </div>
              {!isSubmitted && (
                <button
                  onClick={() => removeAdditionalTask(index)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          ))}
          {additionalTasks.length === 0 && (
            <p className="text-sm text-gray-500 text-center py-4">No additional tasks added</p>
          )}
        </div>
      </div>

      {/* Actions */}
      {!isSubmitted && (
        <div className="flex space-x-3">
          <button
            onClick={handleSaveDraft}
            disabled={isSaving}
            className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 border border-indigo-300 text-indigo-700 font-medium rounded-lg hover:bg-indigo-50 transition-colors disabled:opacity-50"
          >
            <Save className="w-5 h-5" />
            <span>{isSaving ? 'Saving...' : 'Save Draft'}</span>
          </button>
          <button
            onClick={handleSubmit}
            disabled={isSaving}
            className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-indigo-500/30 transition-all disabled:opacity-50"
          >
            <FileText className="w-5 h-5" />
            <span>Submit Report</span>
          </button>
        </div>
      )}

      {isSubmitted && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
          <p className="text-green-700 font-medium">Report submitted on {new Date(submission.submitted_at!).toLocaleString()}</p>
        </div>
      )}
    </div>
  );
}
