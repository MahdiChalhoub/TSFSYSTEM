import { useState, useEffect } from 'react';
import { X, Plus, Trash2, Edit2, FolderKanban, User } from 'lucide-react';
import { TaskCategory } from '@/shared/types';
import { OrganizationMember } from '@/shared/organization-types';

interface CategoryManagementModalProps {
  onClose: () => void;
  onUpdate: () => void;
}

export default function CategoryManagementModal({ onClose, onUpdate }: CategoryManagementModalProps) {
  const [categories, setCategories] = useState<TaskCategory[]>([]);
  const [members, setMembers] = useState<OrganizationMember[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryLeader, setNewCategoryLeader] = useState('');
  const [editName, setEditName] = useState('');
  const [editLeader, setEditLeader] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [categoriesRes, orgRes] = await Promise.all([
        fetch('/api/task-categories'),
        fetch('/api/organizations/current')
      ]);

      if (categoriesRes.ok) {
        const categoriesData = await categoriesRes.json();
        setCategories(categoriesData);
      }

      if (orgRes.ok) {
        const orgData = await orgRes.json();
        if (orgData) {
          const membersRes = await fetch(`/api/organizations/${orgData.id}/members`);
          if (membersRes.ok) {
            const membersData = await membersRes.json();
            setMembers(membersData);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleCreateCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!newCategoryName.trim()) {
      setError('Category name is required');
      return;
    }

    try {
      const response = await fetch('/api/task-categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newCategoryName.trim(),
          leader_user_id: newCategoryLeader || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to create category');
      }

      setNewCategoryName('');
      setNewCategoryLeader('');
      await loadData();
      onUpdate();
    } catch (err) {
      setError('Failed to create category. Please try again.');
    }
  };

  const handleUpdateCategory = async (id: number) => {
    setError('');

    if (!editName.trim()) {
      setError('Category name is required');
      return;
    }

    try {
      const response = await fetch(`/api/task-categories/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editName.trim(),
          leader_user_id: editLeader || undefined,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to update category');
      }

      setEditingId(null);
      await loadData();
      onUpdate();
    } catch (err) {
      setError('Failed to update category. Please try again.');
    }
  };

  const handleDeleteCategory = async (id: number) => {
    if (!confirm('Are you sure you want to delete this category? Tasks in this category will be uncategorized.')) {
      return;
    }

    try {
      const response = await fetch(`/api/task-categories/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) {
        throw new Error('Failed to delete category');
      }

      await loadData();
      onUpdate();
    } catch (err) {
      setError('Failed to delete category. Please try again.');
    }
  };

  const startEditing = (category: TaskCategory) => {
    setEditingId(category.id);
    setEditName(category.name);
    setEditLeader(category.leader_user_id || '');
  };

  const getLeaderName = (leaderId: string | null) => {
    if (!leaderId) return 'None';
    const member = members.find(m => m.user_id === leaderId);
    return member ? (member.name || member.email || 'Unknown') : 'Unknown';
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-100 px-4 sm:px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2 sm:space-x-3 flex-1 min-w-0">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center flex-shrink-0">
              <FolderKanban className="w-4 h-4 sm:w-5 sm:h-5 text-white" />
            </div>
            <h2 className="text-lg sm:text-2xl font-bold text-gray-900 truncate">Manage Categories</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors flex-shrink-0"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-4 sm:space-y-6">
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}

          {/* Create New Category */}
          <form onSubmit={handleCreateCategory} className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-5 border border-indigo-100">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Create New Category</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category Name *
                </label>
                <input
                  type="text"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="e.g., Development, Design, Marketing"
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Category Leader
                </label>
                <select
                  value={newCategoryLeader}
                  onChange={(e) => setNewCategoryLeader(e.target.value)}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                >
                  <option value="">No leader</option>
                  {members.map((member) => (
                    <option key={member.user_id} value={member.user_id}>
                      {member.name || member.email || 'Unknown'} ({member.role})
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <button
              type="submit"
              className="mt-4 flex items-center space-x-2 px-6 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-indigo-500/30 transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Create Category</span>
            </button>
          </form>

          {/* Categories List */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Existing Categories</h3>
            {isLoading ? (
              <div className="text-center py-12 text-gray-500">Loading...</div>
            ) : categories.length === 0 ? (
              <div className="text-center py-12 bg-gray-50 rounded-xl border border-gray-200">
                <FolderKanban className="w-12 h-12 text-gray-400 mx-auto mb-3" />
                <p className="text-gray-600">No categories yet. Create one above.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {categories.map((category) => (
                  <div
                    key={category.id}
                    className="bg-white rounded-xl p-4 border border-gray-200 hover:border-indigo-300 transition-colors"
                  >
                    {editingId === category.id ? (
                      <div className="space-y-3">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          <input
                            type="text"
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          />
                          <select
                            value={editLeader}
                            onChange={(e) => setEditLeader(e.target.value)}
                            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                          >
                            <option value="">No leader</option>
                            {members.map((member) => (
                              <option key={member.user_id} value={member.user_id}>
                                {member.name || member.email || 'Unknown'} ({member.role})
                              </option>
                            ))}
                          </select>
                        </div>
                        <div className="flex space-x-2">
                          <button
                            onClick={() => handleUpdateCategory(category.id)}
                            className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors text-sm font-medium"
                          >
                            Save
                          </button>
                          <button
                            onClick={() => setEditingId(null)}
                            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors text-sm font-medium"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900 mb-1">{category.name}</h4>
                          <div className="flex items-center space-x-2 text-sm text-gray-600">
                            <User className="w-4 h-4" />
                            <span>Leader: {getLeaderName(category.leader_user_id)}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => startEditing(category)}
                            className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                            title="Edit"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteCategory(category.id)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Delete"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
