import { useState, useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { Task } from '@/shared/types';
import { Clock, Calendar, FileText } from 'lucide-react';

interface TimeHistoryProps {
  tasks: Task[];
}

interface TimeEntryDisplay {
  id: string;
  type: 'manual' | 'day' | 'task';
  date: string;
  hours: number;
  taskTitle?: string;
  description?: string;
  status: string;
  startTime?: string;
  endTime?: string;
}

export default function TimeHistory({ tasks }: TimeHistoryProps) {
  const { user } = useAuth();
  const [entries, setEntries] = useState<TimeEntryDisplay[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadAllEntries();
  }, []);

  const loadAllEntries = async () => {
    setIsLoading(true);
    try {
      const [manualRes, dayRes, taskRes] = await Promise.all([
        fetch('/api/time-entries'),
        fetch('/api/day-time-entries'),
        fetch('/api/task-time-entries')
      ]);

      const allEntries: TimeEntryDisplay[] = [];

      // Manual entries
      if (manualRes.ok) {
        const manual = await manualRes.json();
        manual
          .filter((e: any) => e.user_id === user?.id)
          .forEach((e: any) => {
            const task = tasks.find(t => t.id === e.task_id);
            allEntries.push({
              id: `manual-${e.id}`,
              type: 'manual',
              date: e.entry_date,
              hours: e.hours,
              taskTitle: task?.title || 'Unknown Task',
              description: e.description,
              status: e.status || 'pending'
            });
          });
      }

      // Day entries (clock in/out)
      if (dayRes.ok) {
        const day = await dayRes.json();
        day
          .filter((e: any) => e.user_id === user?.id && e.clock_out_time)
          .forEach((e: any) => {
            allEntries.push({
              id: `day-${e.id}`,
              type: 'day',
              date: new Date(e.clock_in_time).toISOString().split('T')[0],
              hours: e.total_hours || 0,
              description: e.notes,
              status: e.status || 'pending',
              startTime: e.clock_in_time,
              endTime: e.clock_out_time
            });
          });
      }

      // Task timer entries
      if (taskRes.ok) {
        const taskEntries = await taskRes.json();
        taskEntries
          .filter((e: any) => e.user_id === user?.id && e.end_time)
          .forEach((e: any) => {
            const task = tasks.find(t => t.id === e.task_id);
            allEntries.push({
              id: `task-${e.id}`,
              type: 'task',
              date: new Date(e.start_time).toISOString().split('T')[0],
              hours: e.duration_hours || 0,
              taskTitle: task?.title || 'Unknown Task',
              description: e.description,
              status: e.status || 'pending',
              startTime: e.start_time,
              endTime: e.end_time
            });
          });
      }

      // Sort by date descending
      allEntries.sort((a, b) => b.date.localeCompare(a.date));
      setEntries(allEntries);
    } catch (error) {
      console.error('Failed to load time entries:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const groupedEntries = entries.reduce((acc, entry) => {
    const date = entry.date;
    if (!acc[date]) {
      acc[date] = [];
    }
    acc[date].push(entry);
    return acc;
  }, {} as Record<string, TimeEntryDisplay[]>);

  const sortedDates = Object.keys(groupedEntries).sort((a, b) => b.localeCompare(a));

  const getStatusBadge = (status: string) => {
    const colors = {
      approved: 'bg-green-100 text-green-700 border-green-200',
      pending: 'bg-yellow-100 text-yellow-700 border-yellow-200',
      rejected: 'bg-red-100 text-red-700 border-red-200'
    };
    return colors[status as keyof typeof colors] || colors.pending;
  };

  const getTypeLabel = (type: string) => {
    const labels = {
      manual: 'Manual Entry',
      day: 'Daily Clock',
      task: 'Task Timer'
    };
    return labels[type as keyof typeof labels] || type;
  };

  if (isLoading) {
    return (
      <div className="text-center py-12">
        <div className="animate-spin w-8 h-8 border-4 border-indigo-600 border-t-transparent rounded-full mx-auto"></div>
      </div>
    );
  }

  if (entries.length === 0) {
    return (
      <div className="text-center py-12 sm:py-20">
        <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Clock className="w-8 h-8 text-indigo-600" />
        </div>
        <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2">No time logged yet</h3>
        <p className="text-gray-600">Use the time tracker or quick log to start tracking your work</p>
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      {sortedDates.map((date) => {
        const dayEntries = groupedEntries[date];
        const totalHours = dayEntries.reduce((sum, e) => sum + e.hours, 0);

        return (
          <div key={date} className="bg-white rounded-xl shadow-sm border border-indigo-50 overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-50 to-purple-50 px-4 sm:px-6 py-3 sm:py-4 border-b border-indigo-100">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-2 sm:space-y-0">
                <div className="flex items-center space-x-2 sm:space-x-3">
                  <Calendar className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-600 flex-shrink-0" />
                  <h3 className="text-base sm:text-lg font-semibold text-gray-900">
                    {new Date(date).toLocaleDateString('en-US', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </h3>
                </div>
                <div className="flex items-center space-x-2">
                  <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-indigo-600 flex-shrink-0" />
                  <span className="text-base sm:text-lg font-bold text-indigo-600">
                    {totalHours.toFixed(1)}h
                  </span>
                </div>
              </div>
            </div>

            <div className="divide-y divide-gray-100">
              {dayEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="px-4 sm:px-6 py-3 sm:py-4 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex flex-col space-y-2">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        {entry.taskTitle && (
                          <h4 className="font-medium text-gray-900 mb-1 break-words">
                            {entry.taskTitle}
                          </h4>
                        )}
                        {entry.type === 'day' && (
                          <h4 className="font-medium text-gray-900 mb-1">
                            Daily Work Session
                          </h4>
                        )}
                        {entry.description && (
                          <div className="flex items-start space-x-2 text-sm text-gray-600 mb-2">
                            <FileText className="w-4 h-4 mt-0.5 flex-shrink-0" />
                            <p className="line-clamp-2 break-words">{entry.description}</p>
                          </div>
                        )}
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="inline-flex items-center px-2 py-1 rounded-lg text-xs font-medium bg-indigo-50 text-indigo-700 border border-indigo-100">
                            {getTypeLabel(entry.type)}
                          </span>
                          <span className={`inline-flex items-center px-2 py-1 rounded-lg text-xs font-medium border ${getStatusBadge(entry.status)}`}>
                            {entry.status.charAt(0).toUpperCase() + entry.status.slice(1)}
                          </span>
                          {entry.startTime && entry.endTime && (
                            <span className="text-xs text-gray-500">
                              {new Date(entry.startTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })} - {new Date(entry.endTime).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 text-indigo-600 font-semibold flex-shrink-0 ml-4">
                        <Clock className="w-4 h-4" />
                        <span>{entry.hours.toFixed(2)}h</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
