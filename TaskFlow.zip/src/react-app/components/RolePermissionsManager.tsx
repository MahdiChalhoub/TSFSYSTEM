import { useState, useEffect } from 'react';
import { Shield, Check, Lock } from 'lucide-react';

interface Permission {
  key: string;
  label: string;
  description: string;
}

const AVAILABLE_PERMISSIONS: Permission[] = [
  { key: 'manage_tasks', label: 'Manage Tasks', description: 'Create, edit, and delete tasks' },
  { key: 'assign_tasks', label: 'Assign Tasks', description: 'Assign tasks to team members' },
  { key: 'manage_categories', label: 'Manage Categories', description: 'Create, edit, and delete task categories' },
  { key: 'approve_time', label: 'Approve Time Entries', description: 'Approve or reject time entries' },
  { key: 'view_all_time', label: 'View All Time Entries', description: 'View time entries from all team members' },
  { key: 'manage_members', label: 'Manage Team Members', description: 'Add, remove, and edit team member roles' },
  { key: 'view_reports', label: 'View Reports', description: 'Access detailed team reports' },
  { key: 'manage_settings', label: 'Manage Settings', description: 'Edit organization settings' },
  { key: 'send_invitations', label: 'Send Invitations', description: 'Invite new team members' },
];

interface RolePermission {
  role: string;
  permission_key: string;
  is_enabled: boolean;
}

export default function RolePermissionsManager() {
  const [permissions, setPermissions] = useState<RolePermission[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [activeRole, setActiveRole] = useState<string>('admin');

  const roles = [
    { key: 'admin', label: 'Admin', color: 'blue' },
    { key: 'leader', label: 'Leader', color: 'green' },
    { key: 'member', label: 'Employee', color: 'gray' },
  ];

  useEffect(() => {
    loadPermissions();
  }, []);

  const loadPermissions = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/role-permissions');
      if (response.ok) {
        const data = await response.json();
        setPermissions(data);
      }
    } catch (error) {
      console.error('Failed to load permissions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const hasPermission = (role: string, permissionKey: string): boolean => {
    if (role === 'owner') return true; // Owner always has all permissions
    
    const perm = permissions.find(
      p => p.role === role && p.permission_key === permissionKey
    );
    return perm?.is_enabled ?? getDefaultPermission(role, permissionKey);
  };

  const getDefaultPermission = (role: string, permissionKey: string): boolean => {
    // Default permissions for each role
    const defaults: Record<string, string[]> = {
      admin: ['manage_tasks', 'assign_tasks', 'manage_categories', 'approve_time', 'view_all_time', 'view_reports', 'send_invitations'],
      leader: ['manage_tasks', 'assign_tasks', 'view_reports'],
      member: ['manage_tasks'],
    };
    return defaults[role]?.includes(permissionKey) ?? false;
  };

  const togglePermission = async (role: string, permissionKey: string) => {
    if (role === 'owner') return; // Cannot edit owner permissions

    setIsSaving(true);
    try {
      const currentValue = hasPermission(role, permissionKey);
      const response = await fetch('/api/role-permissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          role,
          permission_key: permissionKey,
          is_enabled: !currentValue,
        }),
      });

      if (response.ok) {
        await loadPermissions();
      }
    } catch (error) {
      console.error('Failed to update permission:', error);
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-48 mb-4"></div>
          <div className="space-y-3">
            <div className="h-12 bg-gray-100 rounded"></div>
            <div className="h-12 bg-gray-100 rounded"></div>
            <div className="h-12 bg-gray-100 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
          <Shield className="w-5 h-5 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Role Permissions</h2>
          <p className="text-sm text-gray-500">Configure what each role can do</p>
        </div>
      </div>

      {/* Owner Notice */}
      <div className="mb-6 p-4 bg-purple-50 border border-purple-200 rounded-lg flex items-start space-x-3">
        <Lock className="w-5 h-5 text-purple-600 mt-0.5 flex-shrink-0" />
        <div>
          <p className="text-sm font-medium text-purple-900">Owner Role</p>
          <p className="text-sm text-purple-700">The Owner role always has full access to all features and cannot be edited.</p>
        </div>
      </div>

      {/* Role Tabs */}
      <div className="flex space-x-1 bg-gray-100 rounded-lg p-1 mb-6">
        {roles.map((role) => (
          <button
            key={role.key}
            onClick={() => setActiveRole(role.key)}
            className={`flex-1 px-4 py-2.5 rounded-lg font-medium transition-all duration-200 ${
              activeRole === role.key
                ? 'bg-white text-gray-900 shadow-sm'
                : 'text-gray-600 hover:text-gray-900'
            }`}
          >
            {role.label}
          </button>
        ))}
      </div>

      {/* Permissions List */}
      <div className="space-y-3">
        {AVAILABLE_PERMISSIONS.map((permission) => {
          const isEnabled = hasPermission(activeRole, permission.key);
          
          return (
            <div
              key={permission.key}
              className="border border-gray-200 rounded-lg p-4 hover:border-indigo-200 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="font-medium text-gray-900 mb-1">{permission.label}</h3>
                  <p className="text-sm text-gray-600">{permission.description}</p>
                </div>
                <button
                  onClick={() => togglePermission(activeRole, permission.key)}
                  disabled={isSaving}
                  className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 ml-4 ${
                    isEnabled ? 'bg-indigo-600' : 'bg-gray-300'
                  } ${isSaving ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <span
                    className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                      isEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="text-sm font-semibold text-blue-900 mb-2">Permission Summary</h3>
        <div className="flex flex-wrap gap-2">
          {AVAILABLE_PERMISSIONS.filter(p => hasPermission(activeRole, p.key)).map((permission) => (
            <span
              key={permission.key}
              className="inline-flex items-center space-x-1 px-2 py-1 bg-blue-100 text-blue-700 rounded-lg text-xs font-medium"
            >
              <Check className="w-3 h-3" />
              <span>{permission.label}</span>
            </span>
          ))}
        </div>
        {AVAILABLE_PERMISSIONS.filter(p => hasPermission(activeRole, p.key)).length === 0 && (
          <p className="text-sm text-blue-700">No permissions enabled for this role</p>
        )}
      </div>
    </div>
  );
}
