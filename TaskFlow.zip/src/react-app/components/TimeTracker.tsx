import { useState, useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { Clock, PlayCircle, StopCircle, History, Zap } from 'lucide-react';
import { Task, DayTimeEntry, TaskTimeEntry } from '@/shared/types';
import StopTimerModal from './StopTimerModal';

interface TimeTrackerProps {
  tasks: Task[];
  onUpdate: () => void;
}

interface TaskTimerWithTitle extends TaskTimeEntry {
  task_title?: string;
}

export default function TimeTracker({ tasks, onUpdate }: TimeTrackerProps) {
  const { user } = useAuth();
  const [currentDayEntry, setCurrentDayEntry] = useState<DayTimeEntry | null>(null);
  const [runningTaskTimers, setRunningTaskTimers] = useState<TaskTimerWithTitle[]>([]);
  const [completedTaskTimers, setCompletedTaskTimers] = useState<TaskTimerWithTitle[]>([]);
  const [selectedTask, setSelectedTask] = useState<number | ''>('');
  const [notes, setNotes] = useState('');
  const [taskDescriptions, setTaskDescriptions] = useState<Record<number, string>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [showHistory, setShowHistory] = useState(false);
  const [error, setError] = useState('');
  const [stopTimerModalData, setStopTimerModalData] = useState<{
    timerId: number;
    taskId: number;
    taskTitle: string;
    description: string;
  } | null>(null);
  
  // Quick log state
  const [quickLogTask, setQuickLogTask] = useState<number | ''>('');
  const [quickLogHours, setQuickLogHours] = useState('');
  const [quickLogDescription, setQuickLogDescription] = useState('');
  const [isQuickLogging, setIsQuickLogging] = useState(false);

  useEffect(() => {
    loadTimeTracking();
    const interval = setInterval(loadTimeTracking, 10000);
    return () => clearInterval(interval);
  }, []);

  const loadTimeTracking = async () => {
    try {
      const [dayRes, taskRes] = await Promise.all([
        fetch('/api/day-time-entries'),
        fetch('/api/task-time-entries')
      ]);

      if (dayRes.ok) {
        const dayEntries = await dayRes.json();
        const todayEntry = dayEntries.find((e: DayTimeEntry) => 
          e.user_id === user?.id && !e.clock_out_time
        );
        setCurrentDayEntry(todayEntry || null);
      }

      if (taskRes.ok) {
        const taskEntries = await taskRes.json();
        
        const running = taskEntries.filter((e: TaskTimeEntry) => 
          e.user_id === user?.id && !e.end_time
        ).map((entry: TaskTimeEntry) => ({
          ...entry,
          task_title: tasks.find(t => t.id === entry.task_id)?.title || 'Unknown Task'
        }));
        
        const completed = taskEntries.filter((e: TaskTimeEntry) => 
          e.user_id === user?.id && e.end_time
        ).map((entry: TaskTimeEntry) => ({
          ...entry,
          task_title: tasks.find(t => t.id === entry.task_id)?.title || 'Unknown Task'
        }));
        
        setRunningTaskTimers(running);
        setCompletedTaskTimers(completed);
      }
    } catch (error) {
      console.error('Failed to load time tracking:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleClockIn = async () => {
    setError('');
    try {
      const response = await fetch('/api/day-time-entries/clock-in', {
        method: 'POST',
      });

      if (response.ok) {
        await loadTimeTracking();
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to clock in');
      }
    } catch (error) {
      console.error('Failed to clock in:', error);
      setError('Failed to clock in');
    }
  };

  const handleClockOut = async () => {
    if (!currentDayEntry) return;
    setError('');

    // Stop all running task timers first
    if (runningTaskTimers.length > 0) {
      if (!confirm('Clocking out will stop all running task timers. Continue?')) {
        return;
      }
      
      for (const timer of runningTaskTimers) {
        await fetch(`/api/task-time-entries/${timer.id}/stop`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ description: taskDescriptions[timer.id] || '' }),
        });
      }
    }

    try {
      const response = await fetch(`/api/day-time-entries/${currentDayEntry.id}/clock-out`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes }),
      });

      if (response.ok) {
        setNotes('');
        setTaskDescriptions({});
        await loadTimeTracking();
        onUpdate();
      }
    } catch (error) {
      console.error('Failed to clock out:', error);
      setError('Failed to clock out');
    }
  };

  const handleStartTaskTimer = async () => {
    if (!selectedTask) return;
    setError('');

    try {
      const response = await fetch('/api/task-time-entries/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task_id: selectedTask }),
      });

      if (response.ok) {
        setSelectedTask('');
        await loadTimeTracking();
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to start timer');
      }
    } catch (error) {
      console.error('Failed to start timer:', error);
      setError('Failed to start timer');
    }
  };

  const handleStopTaskTimer = async (timerId: number, taskId: number, taskTitle: string) => {
    setStopTimerModalData({
      timerId,
      taskId,
      taskTitle,
      description: taskDescriptions[timerId] || ''
    });
  };

  const handleStopTimerComplete = async () => {
    if (stopTimerModalData) {
      setTaskDescriptions(prev => {
        const updated = { ...prev };
        delete updated[stopTimerModalData.timerId];
        return updated;
      });
      setStopTimerModalData(null);
      await loadTimeTracking();
      onUpdate();
    }
  };

  const handleQuickLog = async () => {
    if (!quickLogTask || !quickLogHours || parseFloat(quickLogHours) <= 0) {
      setError('Please select a task and enter valid hours');
      return;
    }

    setError('');
    setIsQuickLogging(true);

    try {
      const response = await fetch('/api/time-entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task_id: quickLogTask,
          description: quickLogDescription || undefined,
          hours: parseFloat(quickLogHours),
          entry_date: new Date().toISOString().split('T')[0],
        }),
      });

      if (response.ok) {
        setQuickLogTask('');
        setQuickLogHours('');
        setQuickLogDescription('');
        await loadTimeTracking();
        onUpdate();
      } else {
        const data = await response.json();
        setError(data.error || 'Failed to log time');
      }
    } catch (error) {
      console.error('Failed to log time:', error);
      setError('Failed to log time');
    } finally {
      setIsQuickLogging(false);
    }
  };

  const formatElapsedTime = (startTime: string) => {
    const start = new Date(startTime);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    const hours = Math.floor(diffMs / (1000 * 60 * 60));
    const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // Filter to only show tasks assigned to current user
  const assignedTasks = tasks.filter(t => 
    t.assigned_to_user_id === user?.id && 
    t.status !== 'completed' && 
    t.status !== 'cancelled'
  );

  if (isLoading) {
    return <div className="text-center py-4">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      {stopTimerModalData && (
        <StopTimerModal
          taskTitle={stopTimerModalData.taskTitle}
          timerId={stopTimerModalData.timerId}
          taskId={stopTimerModalData.taskId}
          description={stopTimerModalData.description}
          onClose={() => setStopTimerModalData(null)}
          onComplete={handleStopTimerComplete}
        />
      )}

      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
          {error}
        </div>
      )}

      {/* Day Clock In/Out */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Clock className="w-6 h-6 text-indigo-600" />
            <h3 className="text-xl font-bold text-gray-900">Daily Time Clock</h3>
          </div>
          {currentDayEntry && (
            <div className="text-2xl font-mono font-bold text-indigo-600">
              {formatElapsedTime(currentDayEntry.clock_in_time)}
            </div>
          )}
        </div>

        {!currentDayEntry ? (
          <div>
            <p className="text-sm text-gray-600 mb-4">
              Clock in to start tracking your day and enable task timers
            </p>
            <button
              onClick={handleClockIn}
              className="w-full flex items-center justify-center space-x-2 px-6 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-green-500/30 transition-all duration-200"
            >
              <PlayCircle className="w-6 h-6" />
              <span>Clock In</span>
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-gray-600 mb-1">Clocked in at</p>
              <p className="text-lg font-semibold text-gray-900">
                {new Date(currentDayEntry.clock_in_time).toLocaleTimeString()}
              </p>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notes (optional)
              </label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                rows={2}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent resize-none"
                placeholder="Add any notes about your day..."
              />
            </div>

            <button
              onClick={handleClockOut}
              className="w-full flex items-center justify-center space-x-2 px-6 py-4 bg-gradient-to-r from-red-600 to-rose-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-red-500/30 transition-all duration-200"
            >
              <StopCircle className="w-6 h-6" />
              <span>Clock Out{runningTaskTimers.length > 0 ? ` (stops ${runningTaskTimers.length} task timer${runningTaskTimers.length > 1 ? 's' : ''})` : ''}</span>
            </button>
          </div>
        )}
      </div>

      {/* Quick Log Time */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="flex items-center space-x-3 mb-4">
          <Zap className="w-6 h-6 text-amber-600" />
          <h3 className="text-xl font-bold text-gray-900">Quick Log Time</h3>
        </div>

        <p className="text-sm text-gray-600 mb-4">
          Log completed time directly without using a timer
        </p>

        {assignedTasks.length === 0 ? (
          <p className="text-sm text-gray-500 italic">No tasks assigned to you</p>
        ) : (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Task *
              </label>
              <select
                value={quickLogTask}
                onChange={(e) => setQuickLogTask(e.target.value ? parseInt(e.target.value) : '')}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
              >
                <option value="">Select a task</option>
                {assignedTasks.map((task) => (
                  <option key={task.id} value={task.id}>
                    {task.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Hours Worked *
              </label>
              <input
                type="number"
                value={quickLogHours}
                onChange={(e) => setQuickLogHours(e.target.value)}
                step="0.25"
                min="0.25"
                max="24"
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent"
                placeholder="e.g., 2.5"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Description
              </label>
              <textarea
                value={quickLogDescription}
                onChange={(e) => setQuickLogDescription(e.target.value)}
                rows={2}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:border-transparent resize-none"
                placeholder="What did you work on?"
              />
            </div>

            <button
              onClick={handleQuickLog}
              disabled={!quickLogTask || !quickLogHours || isQuickLogging}
              className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-amber-600 to-orange-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-amber-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Zap className="w-5 h-5" />
              <span>{isQuickLogging ? 'Logging...' : 'Log Time'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Task Timers */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <PlayCircle className="w-6 h-6 text-indigo-600" />
            <h3 className="text-xl font-bold text-gray-900">Task Timers</h3>
          </div>
          {completedTaskTimers.length > 0 && (
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center space-x-2 px-4 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
            >
              <History className="w-4 h-4" />
              <span>{showHistory ? 'Hide' : 'Show'} History ({completedTaskTimers.length})</span>
            </button>
          )}
        </div>

        {!currentDayEntry && (
          <div className="p-4 bg-blue-100 border-2 border-blue-400 rounded-xl mb-4 shadow-sm">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0 mt-0.5">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <p className="font-semibold text-blue-900 mb-1">Clock In Required</p>
                <p className="text-sm text-blue-800">
                  You must use the <strong>Daily Time Clock</strong> above to clock in before you can start task timers.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Running Timers */}
        {runningTaskTimers.length > 0 && (
          <div className="space-y-3 mb-4">
            {runningTaskTimers.map((timer) => (
              <div key={timer.id} className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">{timer.task_title}</p>
                    <p className="text-sm text-gray-600">
                      Started at {new Date(timer.start_time).toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="text-xl font-mono font-bold text-blue-600">
                    {formatElapsedTime(timer.start_time)}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <textarea
                    value={taskDescriptions[timer.id] || ''}
                    onChange={(e) => setTaskDescriptions(prev => ({ ...prev, [timer.id]: e.target.value }))}
                    rows={2}
                    className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                    placeholder="What did you work on?"
                  />
                  
                  <button
                    onClick={() => handleStopTaskTimer(timer.id, timer.task_id, timer.task_title || 'Unknown Task')}
                    className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-gradient-to-r from-red-600 to-rose-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-red-500/30 transition-all"
                  >
                    <StopCircle className="w-5 h-5" />
                    <span>Stop Timer</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* History */}
        {showHistory && completedTaskTimers.length > 0 && (
          <div className="space-y-3 mb-4">
            <h4 className="text-sm font-semibold text-gray-700 uppercase tracking-wide">Recent History</h4>
            {completedTaskTimers.slice(0, 10).map((timer) => (
              <div key={timer.id} className="p-3 bg-gray-50 border border-gray-200 rounded-lg">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{timer.task_title}</p>
                    {timer.description && (
                      <p className="text-sm text-gray-600 mt-1">{timer.description}</p>
                    )}
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(timer.start_time).toLocaleString()} - {timer.end_time ? new Date(timer.end_time).toLocaleString() : 'N/A'}
                    </p>
                  </div>
                  <div className="text-sm font-semibold text-indigo-600 ml-4">
                    {timer.duration_hours?.toFixed(2)}h
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Start New Timer */}
        <div className="space-y-3">
          <label className="block text-sm font-medium text-gray-700">
            Start timer for assigned task
          </label>
          {assignedTasks.length === 0 ? (
            <p className="text-sm text-gray-500 italic">No tasks assigned to you</p>
          ) : (
            <div className="flex space-x-2">
              <select
                value={selectedTask}
                onChange={(e) => setSelectedTask(e.target.value ? parseInt(e.target.value) : '')}
                disabled={!currentDayEntry}
                className="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <option value="">{!currentDayEntry ? 'Please clock in first...' : 'Select a task'}</option>
                {assignedTasks.map((task) => (
                  <option key={task.id} value={task.id}>
                    {task.title}
                  </option>
                ))}
              </select>
              <button
                onClick={handleStartTaskTimer}
                disabled={!selectedTask || !currentDayEntry}
                className="px-6 py-2.5 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-green-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
              >
                <PlayCircle className="w-5 h-5" />
                <span>Start</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
