import { useState, useEffect } from 'react';
import { Copy, Check, Building2 } from 'lucide-react';
import { Organization } from '@/shared/organization-types';
import UserProfile from './UserProfile';
import UserManagement from './UserManagement';
import RolePermissionsManager from './RolePermissionsManager';

interface OrganizationSettingsProps {
  organization: Organization;
}

export default function OrganizationSettings({ organization }: OrganizationSettingsProps) {
  const [copied, setCopied] = useState(false);
  const [joinCode, setJoinCode] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadJoinCode();
  }, []);

  const loadJoinCode = async () => {
    try {
      const response = await fetch('/api/organizations/join-code');
      if (response.ok) {
        const data = await response.json();
        setJoinCode(data.join_code);
      }
    } catch (error) {
      console.error('Failed to load join code:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const copyJoinCode = () => {
    if (joinCode) {
      navigator.clipboard.writeText(joinCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* User Profile */}
      <UserProfile />

      {/* User Management (Owner only) */}
      <UserManagement />

      {/* Role Permissions (Owner only) */}
      <RolePermissionsManager />

      {/* Workspace Settings */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="flex items-center space-x-3 mb-6">
          <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Workspace Settings</h2>
        </div>

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Workspace Name
          </label>
          <div className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-gray-700">
            {organization.name}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Company Join Code
          </label>
          {isLoading ? (
            <div className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-gray-400">
              Loading...
            </div>
          ) : joinCode ? (
            <div className="flex items-center space-x-2">
              <div className="flex-1 px-4 py-2.5 bg-indigo-50 border border-indigo-200 rounded-lg text-indigo-700 font-mono text-lg tracking-wider">
                {joinCode}
              </div>
              <button
                onClick={copyJoinCode}
                className="px-4 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:shadow-lg hover:shadow-indigo-500/30 transition-all flex items-center space-x-2"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-lg text-gray-400">
              No join code available
            </div>
          )}
          <p className="mt-2 text-sm text-gray-500">
            Share this code with employees so they can join your workspace during signup.
          </p>
        </div>
      </div>
    </div>
    </div>
  );
}
