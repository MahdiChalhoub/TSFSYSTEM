import { useState, useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { X, FileText, Save, Send, Plus, Trash2, Clock, AlertCircle } from 'lucide-react';
import { Task } from '@/shared/types';

interface ReportForm {
  id: number;
  title: string;
  description: string | null;
  is_active: boolean;
}

interface ReportQuestion {
  id: number;
  question_text: string;
  question_type: string;
  is_required: boolean;
}

interface QuestionChoice {
  id: number;
  question_id: number;
  choice_text: string;
  sort_order: number;
}

interface ReportSubmission {
  id: number;
  report_date: string;
  status: string;
  submitted_at: string | null;
}

interface AdditionalTask {
  id?: number;
  task_description: string;
  hours_spent: number;
}

interface SubmitReportModalProps {
  selectedDate: string;
  onClose: () => void;
  onSuccess: () => void;
}

export default function SubmitReportModal({ selectedDate, onClose, onSuccess }: SubmitReportModalProps) {
  const { user } = useAuth();
  const [forms, setForms] = useState<ReportForm[]>([]);
  const [questions, setQuestions] = useState<ReportQuestion[]>([]);
  const [questionChoices, setQuestionChoices] = useState<Record<number, QuestionChoice[]>>({});
  const [submission, setSubmission] = useState<ReportSubmission | null>(null);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [additionalTasks, setAdditionalTasks] = useState<AdditionalTask[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadData();
  }, [selectedDate]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [formsRes, tasksRes, submissionRes] = await Promise.all([
        fetch('/api/my-assigned-forms'),
        fetch('/api/tasks'),
        fetch(`/api/my-report-submission?date=${selectedDate}`)
      ]);

      if (formsRes.ok) {
        const formsData = await formsRes.json();
        const activeForms = formsData.filter((f: ReportForm) => f.is_active);
        setForms(activeForms);
        
        if (activeForms.length > 0) {
          const questionsRes = await fetch(`/api/report-forms/${activeForms[0].id}/questions`);
          if (questionsRes.ok) {
            const questionsData = await questionsRes.json();
            setQuestions(questionsData);
            
            for (const question of questionsData) {
              if (question.question_type === 'single_choice' || question.question_type === 'multiple_choice') {
                const choicesRes = await fetch(`/api/questions/${question.id}/choices`);
                if (choicesRes.ok) {
                  const choicesData = await choicesRes.json();
                  setQuestionChoices(prev => ({ ...prev, [question.id]: choicesData }));
                }
              }
            }
          }
        }
      }

      if (tasksRes.ok) {
        const tasksData = await tasksRes.json();
        setTasks(tasksData.filter((t: Task) => t.assigned_to_user_id === user?.id));
      }

      if (submissionRes.ok) {
        const subData = await submissionRes.json();
        if (subData) {
          setSubmission(subData);
          
          const answersRes = await fetch(`/api/report-submissions/${subData.id}/answers`);
          if (answersRes.ok) {
            const answersData = await answersRes.json();
            const answersMap: Record<number, string> = {};
            answersData.forEach((a: any) => {
              answersMap[a.question_id] = a.answer_text || '';
            });
            setAnswers(answersMap);
          }

          const additionalRes = await fetch(`/api/report-submissions/${subData.id}/additional-tasks`);
          if (additionalRes.ok) {
            const additionalData = await additionalRes.json();
            setAdditionalTasks(additionalData);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveDraft = async () => {
    setIsSaving(true);
    try {
      let submissionId = submission?.id;

      if (!submissionId) {
        const response = await fetch('/api/my-report-submission', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            report_date: selectedDate,
            form_id: forms[0]?.id || null,
            status: 'draft'
          })
        });

        if (response.ok) {
          const newSub = await response.json();
          submissionId = newSub.id;
          setSubmission(newSub);
        }
      }

      if (submissionId) {
        await fetch(`/api/report-submissions/${submissionId}/answers`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ answers: Object.entries(answers).map(([qId, text]) => ({
            question_id: parseInt(qId),
            answer_text: text
          }))})
        });

        await fetch(`/api/report-submissions/${submissionId}/additional-tasks`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tasks: additionalTasks })
        });
      }

      await loadData();
    } catch (error) {
      console.error('Failed to save:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const validateForm = (): { valid: boolean; errors: string[] } => {
    const errors: string[] = [];
    
    questions.forEach((question) => {
      if (question.is_required) {
        const answer = answers[question.id];
        if (!answer || answer.trim() === '') {
          errors.push(question.question_text);
        }
      }
    });
    
    return { valid: errors.length === 0, errors };
  };

  const handleSubmit = async () => {
    const validation = validateForm();
    if (!validation.valid) {
      alert(`Please answer all required questions:\n\n${validation.errors.map(q => `• ${q}`).join('\n')}`);
      return;
    }
    
    await handleSaveDraft();
    
    if (submission?.id) {
      try {
        await fetch(`/api/report-submissions/${submission.id}/submit`, {
          method: 'POST'
        });
        onSuccess();
        onClose();
      } catch (error) {
        console.error('Failed to submit:', error);
      }
    }
  };

  const addAdditionalTask = () => {
    setAdditionalTasks([...additionalTasks, { task_description: '', hours_spent: 0 }]);
  };

  const removeAdditionalTask = (index: number) => {
    setAdditionalTasks(additionalTasks.filter((_, i) => i !== index));
  };

  const updateAdditionalTask = (index: number, field: keyof AdditionalTask, value: any) => {
    const updated = [...additionalTasks];
    updated[index] = { ...updated[index], [field]: value };
    setAdditionalTasks(updated);
  };

  const handleSingleChoiceChange = (questionId: number, value: string) => {
    setAnswers({ ...answers, [questionId]: value });
  };

  const handleMultipleChoiceChange = (questionId: number, choiceText: string, checked: boolean) => {
    const currentAnswers = answers[questionId] ? answers[questionId].split(',').filter(a => a.trim()) : [];
    let newAnswers: string[];
    
    if (checked) {
      newAnswers = [...currentAnswers, choiceText];
    } else {
      newAnswers = currentAnswers.filter(a => a !== choiceText);
    }
    
    setAnswers({ ...answers, [questionId]: newAnswers.join(',') });
  };

  const isChoiceSelected = (questionId: number, choiceText: string) => {
    const currentAnswers = answers[questionId] ? answers[questionId].split(',').filter(a => a.trim()) : [];
    return currentAnswers.includes(choiceText);
  };

  const isSubmitted = submission?.status === 'submitted';
  const completedTasks = tasks.filter(t => t.status === 'completed' && t.updated_at?.startsWith(selectedDate));
  const failedTasks = tasks.filter(t => t.status === 'cancelled' && t.updated_at?.startsWith(selectedDate));
  const pendingTasks = tasks.filter(t => t.status === 'pending' || t.status === 'in_progress');

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-5 rounded-t-2xl flex items-center justify-between flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">Daily Report Submission</h2>
              <p className="text-purple-100 text-sm">{new Date(selectedDate).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin">
                <Clock className="w-10 h-10 text-indigo-600" />
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Task Summary */}
              <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
                <h3 className="text-lg font-bold text-gray-900 mb-4">Today's Summary</h3>
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                    <div className="text-2xl font-bold text-green-600">{completedTasks.length}</div>
                    <div className="text-sm text-gray-600 mt-1">Completed</div>
                  </div>
                  <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                    <div className="text-2xl font-bold text-red-600">{failedTasks.length}</div>
                    <div className="text-sm text-gray-600 mt-1">Cancelled</div>
                  </div>
                  <div className="bg-white rounded-lg p-4 text-center shadow-sm">
                    <div className="text-2xl font-bold text-yellow-600">{pendingTasks.length}</div>
                    <div className="text-sm text-gray-600 mt-1">In Progress</div>
                  </div>
                </div>
              </div>

              {forms.length === 0 ? (
                <div className="bg-white rounded-xl p-8 border border-gray-200 text-center">
                  <AlertCircle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-gray-900 mb-2">No Report Form Assigned</h3>
                  <p className="text-gray-600">Contact your administrator to get a report form assigned.</p>
                </div>
              ) : isSubmitted ? (
                <div className="bg-white rounded-xl p-8 border-2 border-green-200 text-center">
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Send className="w-8 h-8 text-green-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">Report Already Submitted</h3>
                  <p className="text-gray-600">Submitted on {new Date(submission.submitted_at!).toLocaleString()}</p>
                </div>
              ) : (
                <>
                  {/* Report Form Questions */}
                  {questions.length > 0 && (
                    <div className="bg-white rounded-xl p-6 space-y-6 border border-gray-200">
                      <h3 className="text-lg font-bold text-gray-900 flex items-center space-x-2">
                        <FileText className="w-5 h-5 text-purple-600" />
                        <span>Report Questions</span>
                      </h3>
                      {questions.map((question) => {
                        const choices = questionChoices[question.id] || [];
                        
                        return (
                          <div key={question.id}>
                            <label className="block text-sm font-semibold text-gray-900 mb-3">
                              {question.question_text}
                              {question.is_required && (
                                <span className="text-red-500 ml-1" title="This question is required">*</span>
                              )}
                            </label>
                            
                            {question.question_type === 'text' && (
                              <textarea
                                value={answers[question.id] || ''}
                                onChange={(e) => setAnswers({ ...answers, [question.id]: e.target.value })}
                                rows={3}
                                className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all ${
                                  question.is_required && (!answers[question.id] || answers[question.id].trim() === '')
                                    ? 'border-red-300 bg-red-50/30'
                                    : 'border-gray-300'
                                }`}
                                placeholder={question.is_required ? "This field is required..." : "Type your answer..."}
                              />
                            )}
                            
                            {question.question_type === 'single_choice' && (
                              <div className="space-y-2">
                                {choices.map((choice) => (
                                  <label key={choice.id} className="flex items-center space-x-3 p-4 border-2 border-gray-200 rounded-xl hover:bg-purple-50 hover:border-purple-300 cursor-pointer transition-all">
                                    <input
                                      type="radio"
                                      name={`question_${question.id}`}
                                      value={choice.choice_text}
                                      checked={answers[question.id] === choice.choice_text}
                                      onChange={(e) => handleSingleChoiceChange(question.id, e.target.value)}
                                      className="text-purple-600 focus:ring-purple-500 w-5 h-5"
                                    />
                                    <span className="text-gray-700 font-medium">{choice.choice_text}</span>
                                  </label>
                                ))}
                              </div>
                            )}
                            
                            {question.question_type === 'multiple_choice' && (
                              <div className="space-y-2">
                                {choices.map((choice) => (
                                  <label key={choice.id} className="flex items-center space-x-3 p-4 border-2 border-gray-200 rounded-xl hover:bg-purple-50 hover:border-purple-300 cursor-pointer transition-all">
                                    <input
                                      type="checkbox"
                                      checked={isChoiceSelected(question.id, choice.choice_text)}
                                      onChange={(e) => handleMultipleChoiceChange(question.id, choice.choice_text, e.target.checked)}
                                      className="rounded text-purple-600 focus:ring-purple-500 w-5 h-5"
                                    />
                                    <span className="text-gray-700 font-medium">{choice.choice_text}</span>
                                  </label>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {/* Additional Tasks */}
                  <div className="bg-white rounded-xl p-6 border border-gray-200">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-gray-900">Additional Tasks</h3>
                      <button
                        onClick={addAdditionalTask}
                        className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg hover:shadow-lg hover:shadow-purple-500/30 transition-all"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Add Task</span>
                      </button>
                    </div>
                    <div className="space-y-3">
                      {additionalTasks.map((task, index) => (
                        <div key={index} className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl border border-gray-200">
                          <div className="flex-1">
                            <input
                              type="text"
                              value={task.task_description}
                              onChange={(e) => updateAdditionalTask(index, 'task_description', e.target.value)}
                              placeholder="Task description"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                            />
                          </div>
                          <div className="w-32">
                            <input
                              type="number"
                              value={task.hours_spent}
                              onChange={(e) => updateAdditionalTask(index, 'hours_spent', parseFloat(e.target.value))}
                              step="0.25"
                              min="0"
                              placeholder="Hours"
                              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                            />
                          </div>
                          <button
                            onClick={() => removeAdditionalTask(index)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </div>
                      ))}
                      {additionalTasks.length === 0 && (
                        <p className="text-sm text-gray-500 text-center py-8">No additional tasks added yet</p>
                      )}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        {!isLoading && forms.length > 0 && !isSubmitted && (
          <div className="sticky bottom-0 bg-white border-t border-gray-200 px-6 py-4 rounded-b-2xl flex-shrink-0">
            <div className="flex space-x-3">
              <button
                onClick={handleSaveDraft}
                disabled={isSaving}
                className="flex-1 flex items-center justify-center space-x-2 px-6 py-4 border-2 border-purple-300 text-purple-700 font-semibold rounded-xl hover:bg-purple-50 transition-all disabled:opacity-50"
              >
                <Save className="w-5 h-5" />
                <span>{isSaving ? 'Saving...' : 'Save Draft'}</span>
              </button>
              <button
                onClick={handleSubmit}
                disabled={isSaving}
                className="flex-1 flex items-center justify-center space-x-2 px-6 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:shadow-xl hover:shadow-purple-500/30 transition-all disabled:opacity-50"
              >
                <Send className="w-5 h-5" />
                <span>Submit Report</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
