import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Save, X, Users, UserPlus } from 'lucide-react';
import { OrganizationMember } from '@/shared/organization-types';

interface UserGroup {
  id: number;
  organization_id: number;
  name: string;
  description: string | null;
  created_at: string;
  updated_at: string;
}

interface GroupMember {
  id: number;
  group_id: number;
  user_id: string;
  user_name: string;
  user_email: string;
  created_at: string;
  updated_at: string;
}

export default function UserGroupsManagement() {
  const [groups, setGroups] = useState<UserGroup[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<UserGroup | null>(null);
  const [members, setMembers] = useState<GroupMember[]>([]);
  const [orgMembers, setOrgMembers] = useState<OrganizationMember[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editingGroup, setEditingGroup] = useState<Partial<UserGroup> | null>(null);
  const [selectedUserId, setSelectedUserId] = useState<string>('');

  useEffect(() => {
    loadGroups();
    loadOrgMembers();
  }, []);

  useEffect(() => {
    if (selectedGroup) {
      loadGroupMembers(selectedGroup.id);
    }
  }, [selectedGroup]);

  const loadGroups = async () => {
    try {
      const response = await fetch('/api/user-groups');
      if (response.ok) {
        const data = await response.json();
        setGroups(data);
        if (data.length > 0 && !selectedGroup) {
          setSelectedGroup(data[0]);
        }
      }
    } catch (error) {
      console.error('Failed to load groups:', error);
    }
  };

  const loadOrgMembers = async () => {
    try {
      const orgRes = await fetch('/api/organizations/current');
      if (orgRes.ok) {
        const org = await orgRes.json();
        if (org) {
          const membersRes = await fetch(`/api/organizations/${org.id}/members`);
          if (membersRes.ok) {
            const data = await membersRes.json();
            setOrgMembers(data);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load members:', error);
    }
  };

  const loadGroupMembers = async (groupId: number) => {
    try {
      const response = await fetch(`/api/user-groups/${groupId}/members`);
      if (response.ok) {
        const data = await response.json();
        setMembers(data);
      }
    } catch (error) {
      console.error('Failed to load group members:', error);
    }
  };

  const handleCreateGroup = async () => {
    setEditingGroup({ name: '', description: '' });
    setIsEditing(true);
  };

  const handleSaveGroup = async () => {
    if (!editingGroup || !editingGroup.name) return;

    try {
      const url = editingGroup.id 
        ? `/api/user-groups/${editingGroup.id}`
        : '/api/user-groups';
      
      const method = editingGroup.id ? 'PATCH' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: editingGroup.name,
          description: editingGroup.description || null
        })
      });

      if (response.ok) {
        setEditingGroup(null);
        setIsEditing(false);
        await loadGroups();
      }
    } catch (error) {
      console.error('Failed to save group:', error);
    }
  };

  const handleDeleteGroup = async (groupId: number) => {
    if (!confirm('Delete this group? This will remove all members from the group.')) return;

    try {
      const response = await fetch(`/api/user-groups/${groupId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        await loadGroups();
        if (selectedGroup?.id === groupId) {
          setSelectedGroup(groups.length > 1 ? groups[0] : null);
        }
      }
    } catch (error) {
      console.error('Failed to delete group:', error);
    }
  };

  const handleAddMember = async () => {
    if (!selectedGroup || !selectedUserId) return;

    try {
      const response = await fetch(`/api/user-groups/${selectedGroup.id}/members`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: selectedUserId })
      });

      if (response.ok) {
        setSelectedUserId('');
        await loadGroupMembers(selectedGroup.id);
      }
    } catch (error) {
      console.error('Failed to add member:', error);
    }
  };

  const handleRemoveMember = async (memberId: number) => {
    if (!selectedGroup || !confirm('Remove this member from the group?')) return;

    try {
      const response = await fetch(`/api/user-groups/${selectedGroup.id}/members/${memberId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        await loadGroupMembers(selectedGroup.id);
      }
    } catch (error) {
      console.error('Failed to remove member:', error);
    }
  };

  const getUnassignedMembers = () => {
    const assignedUserIds = members.map(m => m.user_id);
    return orgMembers.filter(m => !assignedUserIds.includes(m.user_id));
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-gray-900">User Groups</h2>
          <button
            onClick={handleCreateGroup}
            className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-indigo-500/30 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>New Group</span>
          </button>
        </div>

        {isEditing && editingGroup && (
          <div className="mb-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Group Name</label>
                <input
                  type="text"
                  value={editingGroup.name}
                  onChange={(e) => setEditingGroup({ ...editingGroup, name: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="Enter group name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  value={editingGroup.description || ''}
                  onChange={(e) => setEditingGroup({ ...editingGroup, description: e.target.value })}
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                  placeholder="Enter description (optional)"
                  rows={3}
                />
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={handleSaveGroup}
                  className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                >
                  <Save className="w-4 h-4" />
                  <span>Save</span>
                </button>
                <button
                  onClick={() => {
                    setEditingGroup(null);
                    setIsEditing(false);
                  }}
                  className="flex items-center space-x-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <X className="w-4 h-4" />
                  <span>Cancel</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {groups.length > 0 && (
          <div className="mb-4">
            <select
              value={selectedGroup?.id || ''}
              onChange={(e) => {
                const group = groups.find(g => g.id === parseInt(e.target.value));
                setSelectedGroup(group || null);
              }}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
            >
              {groups.map(group => (
                <option key={group.id} value={group.id}>
                  {group.name}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {selectedGroup && (
        <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">{selectedGroup.name}</h3>
              {selectedGroup.description && (
                <p className="text-sm text-gray-600 mt-1">{selectedGroup.description}</p>
              )}
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => {
                  setEditingGroup(selectedGroup);
                  setIsEditing(true);
                }}
                className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleDeleteGroup(selectedGroup.id)}
                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Add Member Form */}
          {getUnassignedMembers().length > 0 && (
            <div className="mb-6 p-4 bg-indigo-50 rounded-lg border border-indigo-200">
              <label className="block text-sm font-medium text-indigo-900 mb-2">Add member to group</label>
              <div className="flex space-x-2">
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="flex-1 px-4 py-2.5 border border-indigo-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  <option value="">Select a member...</option>
                  {getUnassignedMembers().map(member => (
                    <option key={member.user_id} value={member.user_id}>
                      {member.name || member.email}
                    </option>
                  ))}
                </select>
                <button
                  onClick={handleAddMember}
                  disabled={!selectedUserId}
                  className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>Add</span>
                </button>
              </div>
            </div>
          )}

          {/* Members List */}
          <div className="space-y-2">
            {members.length === 0 ? (
              <div className="text-center py-8">
                <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-sm text-gray-500">No members in this group yet</p>
                <p className="text-xs text-gray-400 mt-1">Add members to create a group for report assignments</p>
              </div>
            ) : (
              members.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center">
                      <Users className="w-5 h-5 text-indigo-600" />
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{member.user_name}</p>
                      <p className="text-sm text-gray-500">{member.user_email}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleRemoveMember(member.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>

          {members.length > 0 && (
            <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
              <p className="text-sm text-blue-800">
                <strong>{members.length}</strong> member{members.length !== 1 ? 's' : ''} in this group
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
