import { useState, useEffect } from 'react';
import { Clock, Calendar, User, Download, Shield } from 'lucide-react';
import { OrganizationMember } from '@/shared/organization-types';

interface EmployeeTimeEntry {
  user_id: string;
  user_name: string;
  total_manual_hours: number;
  total_day_hours: number;
  total_task_hours: number;
  total_hours: number;
  entries_count: number;
}

interface TimeDetail {
  id: number;
  user_id: string;
  user_name: string;
  type: 'manual' | 'day' | 'task';
  hours: number;
  date: string;
  task_title?: string;
  description?: string;
  status: string;
}

type RoleFilter = 'all' | 'admin' | 'leader' | 'member';

export default function EmployeeTimeDashboard() {
  const [startDate, setStartDate] = useState(() => {
    const date = new Date();
    date.setDate(1);
    return date.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [employees, setEmployees] = useState<EmployeeTimeEntry[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<string | null>(null);
  const [timeDetails, setTimeDetails] = useState<TimeDetail[]>([]);
  const [members, setMembers] = useState<OrganizationMember[]>([]);
  const [roleFilter, setRoleFilter] = useState<RoleFilter>('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, [startDate, endDate]);

  useEffect(() => {
    if (selectedEmployee) {
      loadTimeDetails(selectedEmployee);
    }
  }, [selectedEmployee, startDate, endDate]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [statsRes, orgRes] = await Promise.all([
        fetch(`/api/reports/employee-time?start_date=${startDate}&end_date=${endDate}`),
        fetch('/api/organizations/current')
      ]);

      if (statsRes.ok) {
        const data = await statsRes.json();
        setEmployees(data);
      }

      if (orgRes.ok) {
        const orgData = await orgRes.json();
        if (orgData) {
          const membersRes = await fetch(`/api/organizations/${orgData.id}/members`);
          if (membersRes.ok) {
            const membersData = await membersRes.json();
            setMembers(membersData);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadTimeDetails = async (userId: string) => {
    try {
      const response = await fetch(
        `/api/reports/employee-time-details?user_id=${userId}&start_date=${startDate}&end_date=${endDate}`
      );

      if (response.ok) {
        const data = await response.json();
        setTimeDetails(data);
      }
    } catch (error) {
      console.error('Failed to load time details:', error);
    }
  };

  const getMemberRole = (userId: string) => {
    const member = members.find(m => m.user_id === userId);
    return member?.role || 'member';
  };

  const getMemberName = (userId: string) => {
    const member = members.find(m => m.user_id === userId);
    return member?.name || member?.email || 'Unknown';
  };

  const getFilteredEmployees = () => {
    if (roleFilter === 'all') return employees;
    return employees.filter(e => getMemberRole(e.user_id) === roleFilter);
  };

  const getRoleBadgeStyle = (role: string) => {
    const styles: Record<string, { bg: string; text: string; label: string }> = {
      owner: { bg: 'bg-purple-100', text: 'text-purple-700', label: 'Owner' },
      admin: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'Admin' },
      leader: { bg: 'bg-green-100', text: 'text-green-700', label: 'Leader' },
      member: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'Employee' },
    };
    return styles[role] || styles.member;
  };

  const exportToCSV = () => {
    const filteredEmployees = getFilteredEmployees();
    const headers = ['Employee', 'Role', 'Manual Hours', 'Day Hours', 'Task Hours', 'Total Hours', 'Entries'];
    const rows = filteredEmployees.map(e => [
      getMemberName(e.user_id),
      getRoleBadgeStyle(getMemberRole(e.user_id)).label,
      e.total_manual_hours.toFixed(2),
      e.total_day_hours.toFixed(2),
      e.total_task_hours.toFixed(2),
      e.total_hours.toFixed(2),
      e.entries_count.toString()
    ]);

    const csv = [headers, ...rows].map(row => row.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `employee-time-${startDate}-to-${endDate}.csv`;
    a.click();
  };

  const filteredEmployees = getFilteredEmployees();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-pulse text-gray-400">Loading employee time data...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header & Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 space-y-4 sm:space-y-0">
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-1">Employee Time Dashboard</h2>
            <p className="text-gray-600">Track time across all employees</p>
          </div>
          <button
            onClick={exportToCSV}
            className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-indigo-500/30 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>

        {/* Role Filter */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4" />
              <span>Filter by Role</span>
            </div>
          </label>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setRoleFilter('all')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                roleFilter === 'all'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All Employees
            </button>
            <button
              onClick={() => setRoleFilter('admin')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                roleFilter === 'admin'
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30'
                  : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
              }`}
            >
              Admins
            </button>
            <button
              onClick={() => setRoleFilter('leader')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                roleFilter === 'leader'
                  ? 'bg-green-600 text-white shadow-lg shadow-green-500/30'
                  : 'bg-green-100 text-green-700 hover:bg-green-200'
              }`}
            >
              Leaders
            </button>
            <button
              onClick={() => setRoleFilter('member')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                roleFilter === 'member'
                  ? 'bg-gray-600 text-white shadow-lg shadow-gray-500/30'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Employees
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>Start Date</span>
              </div>
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>End Date</span>
              </div>
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      {filteredEmployees.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-12 text-center">
          <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No time entries found for this period</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredEmployees.map((employee) => {
            const role = getMemberRole(employee.user_id);
            const roleStyle = getRoleBadgeStyle(role);
            
            return (
              <div
                key={employee.user_id}
                onClick={() => setSelectedEmployee(selectedEmployee === employee.user_id ? null : employee.user_id)}
                className={`bg-white rounded-xl shadow-sm border cursor-pointer transition-all ${
                  selectedEmployee === employee.user_id
                    ? 'border-indigo-300 shadow-lg shadow-indigo-500/20'
                    : 'border-indigo-50 hover:border-indigo-200'
                }`}
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center">
                        <User className="w-5 h-5 text-indigo-600" />
                      </div>
                      <div>
                        <div className="flex items-center space-x-2">
                          <h3 className="font-semibold text-gray-900">{getMemberName(employee.user_id)}</h3>
                          <span className={`px-2 py-0.5 ${roleStyle.bg} ${roleStyle.text} rounded text-xs font-medium`}>
                            {roleStyle.label}
                          </span>
                        </div>
                        <p className="text-sm text-gray-500">{employee.entries_count} entries</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-indigo-600">{employee.total_hours.toFixed(1)}h</div>
                      <p className="text-xs text-gray-500">Total Hours</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-lg font-semibold text-purple-700">{employee.total_manual_hours.toFixed(1)}h</div>
                      <div className="text-xs text-purple-600">Manual</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-lg font-semibold text-green-700">{employee.total_day_hours.toFixed(1)}h</div>
                      <div className="text-xs text-green-600">Daily Clock</div>
                    </div>
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-lg font-semibold text-blue-700">{employee.total_task_hours.toFixed(1)}h</div>
                      <div className="text-xs text-blue-600">Task Timers</div>
                    </div>
                  </div>
                </div>

                {/* Expanded Details */}
                {selectedEmployee === employee.user_id && timeDetails.length > 0 && (
                  <div className="border-t border-gray-100 p-6 bg-gray-50">
                    <h4 className="font-semibold text-gray-900 mb-4">Time Entry Details</h4>
                    <div className="space-y-2 max-h-96 overflow-y-auto">
                      {timeDetails.map((detail) => (
                        <div key={`${detail.type}-${detail.id}`} className="bg-white rounded-lg p-3 border border-gray-200">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                                  detail.type === 'manual' ? 'bg-purple-100 text-purple-700' :
                                  detail.type === 'day' ? 'bg-green-100 text-green-700' :
                                  'bg-blue-100 text-blue-700'
                                }`}>
                                  {detail.type === 'manual' ? 'Manual' : detail.type === 'day' ? 'Daily' : 'Task Timer'}
                                </span>
                                <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                                  detail.status === 'approved' ? 'bg-green-100 text-green-700' :
                                  detail.status === 'rejected' ? 'bg-red-100 text-red-700' :
                                  'bg-yellow-100 text-yellow-700'
                                }`}>
                                  {detail.status}
                                </span>
                              </div>
                              {detail.task_title && (
                                <div className="text-sm font-medium text-gray-900 mb-1">{detail.task_title}</div>
                              )}
                              {detail.description && (
                                <div className="text-sm text-gray-600">{detail.description}</div>
                              )}
                              <div className="text-xs text-gray-500 mt-1">
                                {new Date(detail.date).toLocaleDateString()}
                              </div>
                            </div>
                            <div className="text-right ml-4">
                              <div className="text-lg font-semibold text-indigo-600">{detail.hours.toFixed(2)}h</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
