import { useState, useEffect } from 'react';
import { Calendar, CheckCircle, XCircle, Clock, FileText, User, Shield } from 'lucide-react';
import { OrganizationMember } from '@/shared/organization-types';

interface EmployeeReport {
  user_id: string;
  user_name: string;
  report_date: string;
  tasks_completed: number;
  tasks_failed: number;
  tasks_pending: number;
  total_hours: number;
  form_submitted: boolean;
  additional_tasks_count: number;
}

type RoleFilter = 'all' | 'admin' | 'leader' | 'member';

export default function EmployeeReportsDashboard() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [reports, setReports] = useState<EmployeeReport[]>([]);
  const [members, setMembers] = useState<OrganizationMember[]>([]);
  const [roleFilter, setRoleFilter] = useState<RoleFilter>('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadReports();
  }, [selectedDate]);

  const loadReports = async () => {
    setIsLoading(true);
    try {
      const [reportsRes, orgRes] = await Promise.all([
        fetch(`/api/reports/employee-reports?date=${selectedDate}`),
        fetch('/api/organizations/current')
      ]);
      
      if (reportsRes.ok) {
        const data = await reportsRes.json();
        setReports(data);
      }

      if (orgRes.ok) {
        const orgData = await orgRes.json();
        if (orgData) {
          const membersRes = await fetch(`/api/organizations/${orgData.id}/members`);
          if (membersRes.ok) {
            const membersData = await membersRes.json();
            setMembers(membersData);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load reports:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const changeDate = (days: number) => {
    const date = new Date(selectedDate);
    date.setDate(date.getDate() + days);
    setSelectedDate(date.toISOString().split('T')[0]);
  };

  const getMemberRole = (userId: string) => {
    const member = members.find(m => m.user_id === userId);
    return member?.role || 'member';
  };

  const getRoleBadgeStyle = (role: string) => {
    const styles: Record<string, { bg: string; text: string; label: string }> = {
      owner: { bg: 'bg-purple-100', text: 'text-purple-700', label: 'Owner' },
      admin: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'Admin' },
      leader: { bg: 'bg-green-100', text: 'text-green-700', label: 'Leader' },
      member: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'Employee' },
    };
    return styles[role] || styles.member;
  };

  const getFilteredReports = () => {
    if (roleFilter === 'all') return reports;
    return reports.filter(r => getMemberRole(r.user_id) === roleFilter);
  };

  const filteredReports = getFilteredReports();

  const getTotalCompleted = () => filteredReports.reduce((sum, r) => sum + r.tasks_completed, 0);
  const getTotalFailed = () => filteredReports.reduce((sum, r) => sum + r.tasks_failed, 0);
  const getTotalPending = () => filteredReports.reduce((sum, r) => sum + r.tasks_pending, 0);
  const getTotalHours = () => filteredReports.reduce((sum, r) => sum + r.total_hours, 0);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-pulse text-gray-400">Loading reports...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Date Selector */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Employee Reports Dashboard</h2>
        <div className="flex items-center justify-between mb-4">
          <button
            onClick={() => changeDate(-1)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <svg className="w-5 h-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>

          <div className="flex items-center space-x-3">
            <Calendar className="w-6 h-6 text-indigo-600" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="text-xl font-semibold text-gray-900 border-none focus:ring-0 cursor-pointer"
            />
          </div>

          <button
            onClick={() => changeDate(1)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <svg className="w-5 h-5 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>

        {/* Role Filter */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <div className="flex items-center space-x-2">
              <Shield className="w-4 h-4" />
              <span>Filter by Role</span>
            </div>
          </label>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setRoleFilter('all')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                roleFilter === 'all'
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All Employees
            </button>
            <button
              onClick={() => setRoleFilter('admin')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                roleFilter === 'admin'
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/30'
                  : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
              }`}
            >
              Admins
            </button>
            <button
              onClick={() => setRoleFilter('leader')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                roleFilter === 'leader'
                  ? 'bg-green-600 text-white shadow-lg shadow-green-500/30'
                  : 'bg-green-100 text-green-700 hover:bg-green-200'
              }`}
            >
              Leaders
            </button>
            <button
              onClick={() => setRoleFilter('member')}
              className={`px-4 py-2 rounded-lg font-medium transition-all ${
                roleFilter === 'member'
                  ? 'bg-gray-600 text-white shadow-lg shadow-gray-500/30'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Employees
            </button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
          <div className="flex items-center space-x-3 mb-2">
            <CheckCircle className="w-8 h-8 text-green-600" />
            <div>
              <div className="text-2xl font-bold text-green-700">{getTotalCompleted()}</div>
              <div className="text-sm text-green-600">Completed</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-red-50 to-rose-50 rounded-xl p-6 border border-red-100">
          <div className="flex items-center space-x-3 mb-2">
            <XCircle className="w-8 h-8 text-red-600" />
            <div>
              <div className="text-2xl font-bold text-red-700">{getTotalFailed()}</div>
              <div className="text-sm text-red-600">Failed</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-yellow-50 to-amber-50 rounded-xl p-6 border border-yellow-100">
          <div className="flex items-center space-x-3 mb-2">
            <Clock className="w-8 h-8 text-yellow-600" />
            <div>
              <div className="text-2xl font-bold text-yellow-700">{getTotalPending()}</div>
              <div className="text-sm text-yellow-600">Pending</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
          <div className="flex items-center space-x-3 mb-2">
            <FileText className="w-8 h-8 text-indigo-600" />
            <div>
              <div className="text-2xl font-bold text-indigo-700">{getTotalHours().toFixed(1)}h</div>
              <div className="text-sm text-indigo-600">Total Hours</div>
            </div>
          </div>
        </div>
      </div>

      {/* Employee Reports */}
      {filteredReports.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-12 text-center">
          <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No reports available for this date</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredReports.map((report) => {
            const role = getMemberRole(report.user_id);
            const roleStyle = getRoleBadgeStyle(role);
            
            return (
              <div key={report.user_id} className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-full flex items-center justify-center">
                      <User className="w-5 h-5 text-indigo-600" />
                    </div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <h3 className="font-semibold text-gray-900">{report.user_name}</h3>
                        <span className={`px-2 py-0.5 ${roleStyle.bg} ${roleStyle.text} rounded text-xs font-medium`}>
                          {roleStyle.label}
                        </span>
                      </div>
                      <p className="text-sm text-gray-500">{report.total_hours.toFixed(1)} hours tracked</p>
                    </div>
                  </div>
                  {report.form_submitted && (
                    <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                      Form Submitted
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <div className="text-xl font-bold text-green-700">{report.tasks_completed}</div>
                    <div className="text-xs text-green-600">Completed</div>
                  </div>
                  <div className="text-center p-3 bg-red-50 rounded-lg">
                    <div className="text-xl font-bold text-red-700">{report.tasks_failed}</div>
                    <div className="text-xs text-red-600">Failed</div>
                  </div>
                  <div className="text-center p-3 bg-yellow-50 rounded-lg">
                    <div className="text-xl font-bold text-yellow-700">{report.tasks_pending}</div>
                    <div className="text-xs text-yellow-600">Pending</div>
                  </div>
                </div>

                {report.additional_tasks_count > 0 && (
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <FileText className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium text-blue-700">
                        {report.additional_tasks_count} additional task{report.additional_tasks_count !== 1 ? 's' : ''} reported
                      </span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
