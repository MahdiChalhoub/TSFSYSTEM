import { Task, TimeEntry } from '@/shared/types';
import TimeTracker from './TimeTracker';
import TimeHistory from './TimeHistory';

interface TimeManagementProps {
  tasks: Task[];
  timeEntries: TimeEntry[];
  onUpdate: () => void;
}

export default function TimeManagement({ tasks, onUpdate }: TimeManagementProps) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Left Column - Time Tracker */}
      <div className="space-y-6">
        <TimeTracker tasks={tasks} onUpdate={onUpdate} />
      </div>

      {/* Right Column - Time History */}
      <div className="space-y-6">
        <TimeHistory tasks={tasks} />
      </div>
    </div>
  );
}
