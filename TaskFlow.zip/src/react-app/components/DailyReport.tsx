import { useState, useEffect } from 'react';
import { Calendar, Clock, FileText, ChevronLeft, ChevronRight, CheckCircle, XCircle, CheckCircle2 } from 'lucide-react';

interface ManualEntry {
  id: number;
  task_id: number;
  task_title: string;
  description: string | null;
  hours: number;
  entry_date: string;
  status: string | null;
}

interface DayEntry {
  id: number;
  clock_in_time: string;
  clock_out_time: string | null;
  total_hours: number | null;
  notes: string | null;
  status: string;
}

interface TaskEntry {
  id: number;
  task_id: number;
  task_title: string;
  start_time: string;
  end_time: string | null;
  duration_hours: number | null;
  description: string | null;
  status: string;
}

interface CompletedTask {
  id: number;
  title: string;
  description: string | null;
  priority: string;
  assigned_to_name: string | null;
  category_name: string | null;
  updated_at: string;
  total_hours: number;
}

interface DailyReportData {
  date: string;
  manualEntries: ManualEntry[];
  dayEntries: DayEntry[];
  taskEntries: TaskEntry[];
  completedTasks: CompletedTask[];
  totalHours: number;
}

export default function DailyReport() {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [report, setReport] = useState<DailyReportData | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    loadReport();
  }, [selectedDate]);

  const loadReport = async () => {
    setIsLoading(true);
    try {
      const response = await fetch(`/api/reports/daily?date=${selectedDate}`);
      if (response.ok) {
        const data = await response.json();
        setReport(data);
      }
    } catch (error) {
      console.error('Failed to load report:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const changeDate = (days: number) => {
    const date = new Date(selectedDate);
    date.setDate(date.getDate() + days);
    setSelectedDate(date.toISOString().split('T')[0]);
  };

  const goToToday = () => {
    setSelectedDate(new Date().toISOString().split('T')[0]);
  };

  const isToday = selectedDate === new Date().toISOString().split('T')[0];
  const totalEntries = (report?.manualEntries.length || 0) + (report?.dayEntries.length || 0) + (report?.taskEntries.length || 0);
  const hasCompletedTasks = (report?.completedTasks?.length || 0) > 0;
  const hasEntries = totalEntries > 0 || hasCompletedTasks;

  const getStatusBadge = (status: string | null) => {
    if (status === 'approved') {
      return (
        <span className="inline-flex items-center space-x-1 px-2 py-0.5 bg-green-100 text-green-700 rounded-full text-xs font-medium">
          <CheckCircle className="w-3 h-3" />
          <span>Approved</span>
        </span>
      );
    }
    if (status === 'rejected') {
      return (
        <span className="inline-flex items-center space-x-1 px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs font-medium">
          <XCircle className="w-3 h-3" />
          <span>Rejected</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center space-x-1 px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">
        <Clock className="w-3 h-3" />
        <span>Pending</span>
      </span>
    );
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Date Selector */}
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-4 sm:p-6 mb-4 sm:mb-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-4 space-y-3 sm:space-y-0">
          <h2 className="text-xl sm:text-2xl font-bold text-gray-900">Daily Report</h2>
          {!isToday && (
            <button
              onClick={goToToday}
              className="px-4 py-2 text-sm font-medium text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors w-full sm:w-auto"
            >
              Today
            </button>
          )}
        </div>

        <div className="flex items-center justify-between">
          <button
            onClick={() => changeDate(-1)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-gray-600" />
          </button>

          <div className="flex items-center space-x-2 sm:space-x-3">
            <Calendar className="w-5 h-5 sm:w-6 sm:h-6 text-indigo-600 flex-shrink-0" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="text-base sm:text-xl font-semibold text-gray-900 border-none focus:ring-0 cursor-pointer text-center sm:text-left"
            />
          </div>

          <button
            onClick={() => changeDate(1)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-gray-600" />
          </button>
        </div>
      </div>

      {/* Report Content */}
      {isLoading ? (
        <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-12 text-center">
          <div className="animate-pulse">
            <div className="w-16 h-16 bg-indigo-100 rounded-2xl mx-auto mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-32 mx-auto"></div>
          </div>
        </div>
      ) : report && hasEntries ? (
        <>
          {/* Summary */}
          <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl shadow-lg shadow-indigo-500/30 p-6 sm:p-8 mb-4 sm:mb-6 text-white">
            <div className="flex flex-col sm:flex-row items-center sm:justify-between space-y-4 sm:space-y-0">
              <div className="text-center sm:text-left">
                <p className="text-indigo-100 mb-1">Total Hours (Approved)</p>
                <p className="text-3xl sm:text-4xl font-bold">{report.totalHours.toFixed(1)}h</p>
              </div>
              <div className="text-center sm:text-right">
                <p className="text-indigo-100 mb-1">Tasks Completed</p>
                <p className="text-3xl sm:text-4xl font-bold">{report.completedTasks?.length || 0}</p>
              </div>
            </div>
          </div>

          {/* Completed Tasks */}
          {report.completedTasks && report.completedTasks.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-indigo-50 overflow-hidden mb-4">
              <div className="px-4 sm:px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-green-50 to-emerald-50">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900 flex items-center space-x-2">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                  <span>Completed Tasks</span>
                </h3>
              </div>
              <div className="divide-y divide-gray-100">
                {report.completedTasks.map((task) => (
                  <div key={task.id} className="px-4 sm:px-6 py-3 sm:py-4 hover:bg-gray-50 transition-colors">
                    <div className="flex flex-col space-y-2">
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-gray-900 break-words mb-1">
                            {task.title}
                          </h4>
                          {task.description && (
                            <p className="text-sm text-gray-600 break-words mb-2">{task.description}</p>
                          )}
                          <div className="flex flex-wrap items-center gap-2 text-xs text-gray-500">
                            {task.assigned_to_name && (
                              <span className="inline-flex items-center px-2 py-0.5 bg-blue-50 text-blue-700 rounded">
                                {task.assigned_to_name}
                              </span>
                            )}
                            {task.category_name && (
                              <span className="inline-flex items-center px-2 py-0.5 bg-purple-50 text-purple-700 rounded">
                                {task.category_name}
                              </span>
                            )}
                            <span className={`inline-flex items-center px-2 py-0.5 rounded ${
                              task.priority === 'urgent' ? 'bg-red-50 text-red-700' :
                              task.priority === 'high' ? 'bg-orange-50 text-orange-700' :
                              task.priority === 'medium' ? 'bg-yellow-50 text-yellow-700' :
                              'bg-gray-50 text-gray-700'
                            }`}>
                              {task.priority}
                            </span>
                          </div>
                        </div>
                        <div className="ml-4 flex-shrink-0 text-right">
                          <div className="flex items-center space-x-2 text-indigo-600 font-semibold mb-1">
                            <Clock className="w-4 h-4" />
                            <span>{task.total_hours.toFixed(2)}h</span>
                          </div>
                          <CheckCircle2 className="w-6 h-6 text-green-600" />
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Daily Clock In/Out Entries */}
          {report.dayEntries.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-indigo-50 overflow-hidden mb-4">
              <div className="px-4 sm:px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-green-50 to-emerald-50">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">Daily Clock In/Out</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {report.dayEntries.map((entry) => (
                  <div key={entry.id} className="px-4 sm:px-6 py-3 sm:py-4 hover:bg-gray-50 transition-colors">
                    <div className="flex flex-col space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="grid grid-cols-2 gap-4 flex-1">
                          <div>
                            <p className="text-xs text-gray-500 mb-1">Clock In</p>
                            <p className="text-sm font-medium text-gray-900">
                              {new Date(entry.clock_in_time).toLocaleTimeString()}
                            </p>
                          </div>
                          <div>
                            <p className="text-xs text-gray-500 mb-1">Clock Out</p>
                            <p className="text-sm font-medium text-gray-900">
                              {entry.clock_out_time ? new Date(entry.clock_out_time).toLocaleTimeString() : '-'}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3 ml-4">
                          {getStatusBadge(entry.status)}
                          <div className="flex items-center space-x-2 text-indigo-600 font-semibold">
                            <Clock className="w-4 h-4" />
                            <span>{entry.total_hours?.toFixed(2) || 0}h</span>
                          </div>
                        </div>
                      </div>
                      {entry.notes && (
                        <p className="text-sm text-gray-600 italic">{entry.notes}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Task Timer Entries */}
          {report.taskEntries.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-indigo-50 overflow-hidden mb-4">
              <div className="px-4 sm:px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-blue-50 to-indigo-50">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">Task Timers</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {report.taskEntries.map((entry) => (
                  <div key={entry.id} className="px-4 sm:px-6 py-3 sm:py-4 hover:bg-gray-50 transition-colors">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between space-y-2 sm:space-y-0">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-medium text-gray-900 break-words">
                            {entry.task_title}
                          </h4>
                          {getStatusBadge(entry.status)}
                        </div>
                        {entry.description && (
                          <div className="flex items-start space-x-2 text-sm text-gray-600 mb-2">
                            <FileText className="w-4 h-4 mt-0.5 flex-shrink-0" />
                            <p className="break-words">{entry.description}</p>
                          </div>
                        )}
                        <p className="text-xs text-gray-500">
                          {new Date(entry.start_time).toLocaleTimeString()} - {entry.end_time ? new Date(entry.end_time).toLocaleTimeString() : 'ongoing'}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2 text-indigo-600 font-semibold flex-shrink-0">
                        <Clock className="w-4 h-4" />
                        <span>{entry.duration_hours?.toFixed(2) || 0}h</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Manual Entries */}
          {report.manualEntries.length > 0 && (
            <div className="bg-white rounded-xl shadow-sm border border-indigo-50 overflow-hidden">
              <div className="px-4 sm:px-6 py-4 border-b border-gray-100 bg-gradient-to-r from-purple-50 to-pink-50">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">Manual Time Entries</h3>
              </div>
              <div className="divide-y divide-gray-100">
                {report.manualEntries.map((entry) => (
                  <div key={entry.id} className="px-4 sm:px-6 py-3 sm:py-4 hover:bg-gray-50 transition-colors">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between space-y-2 sm:space-y-0">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-medium text-gray-900 break-words">
                            {entry.task_title}
                          </h4>
                          {getStatusBadge(entry.status)}
                        </div>
                        {entry.description && (
                          <div className="flex items-start space-x-2 text-sm text-gray-600">
                            <FileText className="w-4 h-4 mt-0.5 flex-shrink-0" />
                            <p className="break-words">{entry.description}</p>
                          </div>
                        )}
                      </div>
                      <div className="flex items-center space-x-2 text-indigo-600 font-semibold flex-shrink-0">
                        <Clock className="w-4 h-4" />
                        <span>{entry.hours}h</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      ) : (
        <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-8 sm:p-12 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Clock className="w-8 h-8 text-indigo-600" />
          </div>
          <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2">No entries for this day</h3>
          <p className="text-gray-600">
            {isToday ? 'Start logging time to see it here' : 'No time was logged on this date'}
          </p>
        </div>
      )}
    </div>
  );
}
