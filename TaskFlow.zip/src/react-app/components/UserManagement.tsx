import { useState, useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { Users, Shield, ChevronDown } from 'lucide-react';
import { OrganizationMember } from '@/shared/organization-types';

export default function UserManagement() {
  const { user } = useAuth();
  const [members, setMembers] = useState<OrganizationMember[]>([]);
  const [userMembership, setUserMembership] = useState<OrganizationMember | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [editingMember, setEditingMember] = useState<number | null>(null);
  const [selectedRole, setSelectedRole] = useState<string>('');

  useEffect(() => {
    loadMembers();
  }, []);

  const loadMembers = async () => {
    try {
      const orgRes = await fetch('/api/organizations/current');
      if (orgRes.ok) {
        const org = await orgRes.json();
        if (org) {
          const membersRes = await fetch(`/api/organizations/${org.id}/members`);
          if (membersRes.ok) {
            const membersData = await membersRes.json();
            setMembers(membersData);
            const myMembership = membersData.find((m: OrganizationMember) => m.user_id === user?.id);
            setUserMembership(myMembership);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load members:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateRole = async (memberId: number) => {
    if (!selectedRole) return;

    try {
      const response = await fetch(`/api/organization-members/${memberId}/role`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: selectedRole }),
      });

      if (response.ok) {
        await loadMembers();
        setEditingMember(null);
        setSelectedRole('');
      }
    } catch (error) {
      console.error('Failed to update role:', error);
    }
  };

  const getRoleBadge = (role: string) => {
    const badges: Record<string, { bg: string; text: string; label: string }> = {
      owner: { bg: 'bg-purple-100', text: 'text-purple-700', label: 'Owner' },
      admin: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'Admin' },
      leader: { bg: 'bg-green-100', text: 'text-green-700', label: 'Leader' },
      member: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'Employee' },
    };
    const badge = badges[role] || badges.member;
    return (
      <span className={`inline-flex items-center space-x-1 px-3 py-1 ${badge.bg} ${badge.text} rounded-full text-sm font-medium`}>
        <Shield className="w-4 h-4" />
        <span>{badge.label}</span>
      </span>
    );
  };

  const canEditRoles = userMembership?.role === 'owner';

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-gray-200 rounded w-32 mb-4"></div>
          <div className="space-y-3">
            <div className="h-12 bg-gray-100 rounded"></div>
            <div className="h-12 bg-gray-100 rounded"></div>
            <div className="h-12 bg-gray-100 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!canEditRoles) {
    return null;
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
      <div className="flex items-center space-x-3 mb-6">
        <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
          <Users className="w-5 h-5 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900">Team Members</h2>
      </div>

      <div className="space-y-3">
        {members.map((member) => (
          <div
            key={member.id}
            className="border border-gray-200 rounded-lg p-4 hover:border-indigo-200 transition-colors"
          >
            {editingMember === member.id ? (
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-900">{member.name || member.email}</p>
                    <p className="text-sm text-gray-500">{member.email}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <select
                    value={selectedRole}
                    onChange={(e) => setSelectedRole(e.target.value)}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent text-sm"
                  >
                    <option value="">Select role...</option>
                    <option value="owner">Owner</option>
                    <option value="admin">Admin</option>
                    <option value="leader">Leader</option>
                    <option value="member">Employee</option>
                  </select>
                  <button
                    onClick={() => handleUpdateRole(member.id)}
                    disabled={!selectedRole}
                    className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:shadow-lg hover:shadow-indigo-500/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed text-sm font-medium"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => {
                      setEditingMember(null);
                      setSelectedRole('');
                    }}
                    className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors text-sm font-medium"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-3 mb-1">
                    <p className="font-medium text-gray-900 truncate">{member.name || member.email}</p>
                    {member.user_id === user?.id && (
                      <span className="text-xs text-indigo-600 font-medium">(You)</span>
                    )}
                  </div>
                  <p className="text-sm text-gray-500 truncate">{member.email}</p>
                </div>
                <div className="flex items-center space-x-3">
                  {getRoleBadge(member.role)}
                  {member.user_id !== user?.id && (
                    <button
                      onClick={() => {
                        setEditingMember(member.id);
                        setSelectedRole(member.role);
                      }}
                      className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                      title="Edit role"
                    >
                      <ChevronDown className="w-5 h-5" />
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="text-sm font-semibold text-blue-900 mb-2">Role Descriptions</h3>
        <ul className="text-sm text-blue-800 space-y-1">
          <li><strong>Owner:</strong> Full access to all features and settings</li>
          <li><strong>Admin:</strong> Can approve time entries and manage users</li>
          <li><strong>Leader:</strong> Can see tasks and reports of assigned team members</li>
          <li><strong>Employee:</strong> Can manage own tasks and time entries</li>
        </ul>
      </div>
    </div>
  );
}
