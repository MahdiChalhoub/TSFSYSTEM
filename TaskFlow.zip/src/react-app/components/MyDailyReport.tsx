import { useState, useEffect } from 'react';
import { useAuth } from '@getmocha/users-service/react';
import { 
  Calendar, 
  Clock, 
  CheckCircle2, 
  XCircle,
  Circle,
  FileText,
  ChevronLeft,
  ChevronRight,
  Award,
  TrendingUp,
  AlertCircle,
  Plus,
  Trash2,
  Send,
  Save,
  AlertTriangle,
  Sparkles,
  X
} from 'lucide-react';
import { Task } from '@/shared/types';
import ReportQuestionsModal from './ReportQuestionsModal';

interface ManualEntry {
  id: number;
  task_id: number;
  task_title: string;
  description: string | null;
  hours: number;
  entry_date: string;
  status: string | null;
}

interface DayEntry {
  id: number;
  clock_in_time: string;
  clock_out_time: string | null;
  total_hours: number | null;
  notes: string | null;
  status: string;
}

interface TaskEntry {
  id: number;
  task_id: number;
  task_title: string;
  start_time: string;
  end_time: string | null;
  duration_hours: number | null;
  description: string | null;
  status: string;
}

interface CompletedTask {
  id: number;
  title: string;
  description: string | null;
  priority: string;
  assigned_to_name: string | null;
  category_name: string | null;
  updated_at: string;
  total_hours: number;
}

interface DailyReportData {
  date: string;
  manualEntries: ManualEntry[];
  dayEntries: DayEntry[];
  taskEntries: TaskEntry[];
  completedTasks: CompletedTask[];
  totalHours: number;
}

interface ReportForm {
  id: number;
  title: string;
  description: string | null;
  is_active: boolean;
}

interface ReportSubmission {
  id: number;
  report_date: string;
  status: string;
  submitted_at: string | null;
  form_id: number | null;
  is_holiday: boolean;
}

interface AdditionalTask {
  id?: number;
  task_description: string;
  hours_spent: number;
}

export default function MyDailyReport() {
  const { user } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [report, setReport] = useState<DailyReportData | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [forms, setForms] = useState<ReportForm[]>([]);
  const [submission, setSubmission] = useState<ReportSubmission | null>(null);
  const [additionalTasks, setAdditionalTasks] = useState<AdditionalTask[]>([]);
  const [showQuestionsModal, setShowQuestionsModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [hasAnsweredQuestions, setHasAnsweredQuestions] = useState(false);
  const [pendingReports, setPendingReports] = useState<string[]>([]);
  const [isHoliday, setIsHoliday] = useState(false);
  const [aiSummary, setAiSummary] = useState<string | null>(null);
  const [isGeneratingSummary, setIsGeneratingSummary] = useState(false);
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [summaryError, setSummaryError] = useState<string | null>(null);

  useEffect(() => {
    loadData();
    loadPendingReports();
  }, [selectedDate]);

  const loadPendingReports = async () => {
    try {
      const res = await fetch('/api/my-pending-reports');
      if (res.ok) {
        const dates = await res.json();
        setPendingReports(dates);
      }
    } catch (error) {
      console.error('Failed to load pending reports:', error);
    }
  };

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [reportRes, tasksRes, formsRes, submissionRes] = await Promise.all([
        fetch(`/api/reports/daily?date=${selectedDate}`),
        fetch('/api/tasks'),
        fetch('/api/my-assigned-forms'),
        fetch(`/api/my-report-submission?date=${selectedDate}`)
      ]);

      if (reportRes.ok) {
        const data = await reportRes.json();
        setReport(data);
      }

      if (tasksRes.ok) {
        const tasksData = await tasksRes.json();
        setTasks(tasksData.filter((t: Task) => t.assigned_to_user_id === user?.id));
      }

      if (formsRes.ok) {
        const formsData = await formsRes.json();
        setForms(formsData.filter((f: ReportForm) => f.is_active));
      }

      if (submissionRes.ok) {
        const subData = await submissionRes.json();
        if (subData) {
          setSubmission(subData);
          setIsHoliday(subData.is_holiday || false);
          
          const additionalRes = await fetch(`/api/report-submissions/${subData.id}/additional-tasks`);
          if (additionalRes.ok) {
            const additionalData = await additionalRes.json();
            setAdditionalTasks(additionalData);
          }

          // Check if questions have been answered
          const answersRes = await fetch(`/api/report-submissions/${subData.id}/answers`);
          if (answersRes.ok) {
            const answersData = await answersRes.json();
            setHasAnsweredQuestions(answersData.length > 0);
          }
        } else {
          // Clear all submission-related state when no submission exists for this date
          setSubmission(null);
          setAdditionalTasks([]);
          setHasAnsweredQuestions(false);
          setIsHoliday(false);
        }
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const changeDate = (days: number) => {
    const date = new Date(selectedDate);
    date.setDate(date.getDate() + days);
    setSelectedDate(date.toISOString().split('T')[0]);
  };

  const goToToday = () => {
    setSelectedDate(new Date().toISOString().split('T')[0]);
  };

  const addAdditionalTask = () => {
    setAdditionalTasks([...additionalTasks, { task_description: '', hours_spent: 0 }]);
  };

  const removeAdditionalTask = (index: number) => {
    setAdditionalTasks(additionalTasks.filter((_, i) => i !== index));
  };

  const updateAdditionalTask = (index: number, field: keyof AdditionalTask, value: any) => {
    const updated = [...additionalTasks];
    updated[index] = { ...updated[index], [field]: value };
    setAdditionalTasks(updated);
  };

  const handleSaveAnswers = async (answers: Record<number, string>) => {
    let submissionId = submission?.id;

    if (!submissionId) {
      const response = await fetch('/api/my-report-submission', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          report_date: selectedDate,
          form_id: forms[0]?.id || null,
          status: 'draft',
          is_holiday: isHoliday
        })
      });

      if (response.ok) {
        const newSub = await response.json();
        submissionId = newSub.id;
        setSubmission(newSub);
      }
    }

    if (submissionId) {
      await fetch(`/api/report-submissions/${submissionId}/answers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answers: Object.entries(answers).map(([qId, text]) => ({
          question_id: parseInt(qId),
          answer_text: text
        }))})
      });
    }

    await loadData();
  };

  const handleSaveDraft = async () => {
    setIsSaving(true);
    try {
      let submissionId = submission?.id;

      if (!submissionId) {
        const response = await fetch('/api/my-report-submission', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            report_date: selectedDate,
            form_id: forms[0]?.id || null,
            status: 'draft',
            is_holiday: isHoliday
          })
        });

        if (response.ok) {
          const newSub = await response.json();
          submissionId = newSub.id;
          setSubmission(newSub);
        }
      }

      if (submissionId) {
        await fetch(`/api/report-submissions/${submissionId}/additional-tasks`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tasks: additionalTasks })
        });
      }

      await loadData();
    } catch (error) {
      console.error('Failed to save:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSubmit = async () => {
    await handleSaveDraft();
    
    if (submission?.id) {
      try {
        await fetch(`/api/report-submissions/${submission.id}/submit`, {
          method: 'POST'
        });
        await loadData();
        await loadPendingReports(); // Refresh pending reports list
      } catch (error) {
        console.error('Failed to submit:', error);
      }
    }
  };

  const generateAISummary = async () => {
    setIsGeneratingSummary(true);
    setSummaryError(null);
    try {
      const response = await fetch('/api/reports/ai-summary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date: selectedDate })
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.error || 'Failed to generate summary');
      }

      const data = await response.json();
      setAiSummary(data.summary);
      setShowSummaryModal(true);
    } catch (error: any) {
      console.error('Failed to generate AI summary:', error);
      setSummaryError(error.message || 'Failed to generate AI summary');
    } finally {
      setIsGeneratingSummary(false);
    }
  };

  const isToday = selectedDate === new Date().toISOString().split('T')[0];
  const completedTasks = tasks.filter(t => t.status === 'completed' && t.updated_at?.startsWith(selectedDate));
  const failedTasks = tasks.filter(t => t.status === 'cancelled' && t.updated_at?.startsWith(selectedDate));
  const pendingTasks = tasks.filter(t => t.status === 'pending' || t.status === 'in_progress');
  const isSubmitted = submission?.status === 'submitted';

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="animate-spin">
          <Circle className="w-10 h-10 text-indigo-600" />
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Pending Reports Alert */}
      {pendingReports.length > 0 && (
        <div className="bg-gradient-to-r from-orange-50 to-red-50 border-2 border-orange-200 rounded-xl p-6 shadow-lg">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-orange-600" />
              </div>
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-bold text-gray-900 mb-2">
                {pendingReports.length} Unsubmitted Report{pendingReports.length !== 1 ? 's' : ''}
              </h3>
              <p className="text-sm text-gray-700 mb-3">
                You have reports from previous days that need to be submitted:
              </p>
              <div className="flex flex-wrap gap-2">
                {pendingReports.slice(0, 5).map((date) => (
                  <button
                    key={date}
                    onClick={() => setSelectedDate(date)}
                    className="px-3 py-1.5 bg-white border-2 border-orange-300 text-orange-700 rounded-lg hover:bg-orange-50 transition-all font-medium text-sm"
                  >
                    {new Date(date + 'T00:00:00').toLocaleDateString('en-US', { 
                      month: 'short', 
                      day: 'numeric',
                      year: 'numeric'
                    })}
                  </button>
                ))}
                {pendingReports.length > 5 && (
                  <span className="px-3 py-1.5 text-orange-700 text-sm font-medium">
                    +{pendingReports.length - 5} more
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Header with Date Navigation */}
      <div className="bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 rounded-2xl shadow-xl shadow-indigo-500/20 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6 space-y-4 sm:space-y-0">
          <div>
            <h1 className="text-2xl sm:text-3xl font-bold text-white mb-2">Daily Report</h1>
            <p className="text-indigo-100">Track your daily progress and accomplishments</p>
          </div>
          <div className="flex space-x-3">
            {report && report.totalHours > 0 && (
              <button
                onClick={generateAISummary}
                disabled={isGeneratingSummary}
                className="flex items-center space-x-2 px-4 py-2 bg-white/20 backdrop-blur-sm text-white font-medium rounded-xl hover:bg-white/30 transition-all disabled:opacity-50"
              >
                <Sparkles className={`w-5 h-5 ${isGeneratingSummary ? 'animate-spin' : ''}`} />
                <span>{isGeneratingSummary ? 'Generating...' : 'AI Summary'}</span>
              </button>
            )}
            {!isToday && (
              <button
                onClick={goToToday}
                className="px-4 py-2 bg-white/20 backdrop-blur-sm text-white font-medium rounded-xl hover:bg-white/30 transition-all"
              >
                Jump to Today
              </button>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between bg-white/10 backdrop-blur-sm rounded-xl p-4">
          <button
            onClick={() => changeDate(-1)}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>

          <div className="flex items-center space-x-3">
            <Calendar className="w-6 h-6 text-white" />
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="text-xl font-semibold bg-transparent text-white border-none focus:ring-0 cursor-pointer"
            />
          </div>

          <button
            onClick={() => changeDate(1)}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <ChevronRight className="w-6 h-6 text-white" />
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <Clock className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Total Hours</span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{report?.totalHours.toFixed(1) || 0}h</div>
          <div className="text-sm text-gray-500 mt-1">Approved time</div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/30">
              <CheckCircle2 className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Completed</span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{completedTasks.length}</div>
          <div className="text-sm text-gray-500 mt-1">Tasks finished</div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-rose-600 rounded-xl flex items-center justify-center shadow-lg shadow-red-500/30">
              <XCircle className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">Failed</span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{failedTasks.length}</div>
          <div className="text-sm text-gray-500 mt-1">Cancelled tasks</div>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 hover:shadow-md transition-shadow">
          <div className="flex items-center justify-between mb-3">
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg shadow-yellow-500/30">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <span className="text-xs font-medium text-gray-500 uppercase tracking-wide">In Progress</span>
          </div>
          <div className="text-3xl font-bold text-gray-900">{pendingTasks.length}</div>
          <div className="text-sm text-gray-500 mt-1">Active tasks</div>
        </div>
      </div>

      {/* Timeline View */}
      {report && (report.completedTasks.length > 0 || report.dayEntries.length > 0 || report.taskEntries.length > 0 || report.manualEntries.length > 0) ? (
        <div className="space-y-6">
          {/* Completed Tasks */}
          {report.completedTasks.length > 0 && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="bg-gradient-to-r from-green-50 to-emerald-50 px-6 py-4 border-b border-gray-100">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg shadow-green-500/30">
                    <Award className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">Completed Tasks</h3>
                    <p className="text-sm text-gray-600">{report.completedTasks.length} task{report.completedTasks.length !== 1 ? 's' : ''} accomplished today</p>
                  </div>
                </div>
              </div>
              <div className="divide-y divide-gray-100">
                {report.completedTasks.map((task) => (
                  <div key={task.id} className="px-6 py-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-3 mb-2">
                          <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
                          <h4 className="font-semibold text-gray-900 break-words">{task.title}</h4>
                        </div>
                        {task.description && (
                          <p className="text-sm text-gray-600 ml-8 mb-2">{task.description}</p>
                        )}
                        <div className="flex flex-wrap items-center gap-2 ml-8">
                          {task.category_name && (
                            <span className="inline-flex items-center px-2.5 py-1 bg-purple-50 text-purple-700 rounded-lg text-xs font-medium">
                              {task.category_name}
                            </span>
                          )}
                          {task.assigned_to_name && (
                            <span className="inline-flex items-center px-2.5 py-1 bg-blue-50 text-blue-700 rounded-lg text-xs font-medium">
                              {task.assigned_to_name}
                            </span>
                          )}
                          <span className={`inline-flex items-center px-2.5 py-1 rounded-lg text-xs font-medium ${
                            task.priority === 'urgent' ? 'bg-red-50 text-red-700' :
                            task.priority === 'high' ? 'bg-orange-50 text-orange-700' :
                            task.priority === 'medium' ? 'bg-yellow-50 text-yellow-700' :
                            'bg-gray-50 text-gray-700'
                          }`}>
                            {task.priority}
                          </span>
                        </div>
                      </div>
                      <div className="ml-4 flex-shrink-0">
                        <div className="flex items-center space-x-2 px-3 py-2 bg-indigo-50 rounded-xl">
                          <Clock className="w-4 h-4 text-indigo-600" />
                          <span className="text-sm font-bold text-indigo-700">{task.total_hours.toFixed(2)}h</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Time Entries */}
          {(report.dayEntries.length > 0 || report.taskEntries.length > 0 || report.manualEntries.length > 0) && (
            <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 px-6 py-4 border-b border-gray-100">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/30">
                    <Clock className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-900">Time Tracking</h3>
                    <p className="text-sm text-gray-600">All time entries for this day</p>
                  </div>
                </div>
              </div>
              <div className="divide-y divide-gray-100">
                {report.dayEntries.map((entry) => (
                  <div key={`day-${entry.id}`} className="px-6 py-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 flex-1">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <div>
                          <p className="font-medium text-gray-900">Daily Clock In/Out</p>
                          <p className="text-sm text-gray-600">
                            {new Date(entry.clock_in_time).toLocaleTimeString()} - {entry.clock_out_time ? new Date(entry.clock_out_time).toLocaleTimeString() : 'ongoing'}
                          </p>
                          {entry.notes && <p className="text-sm text-gray-500 mt-1">{entry.notes}</p>}
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className={`px-3 py-1 rounded-lg text-xs font-medium ${
                          entry.status === 'approved' ? 'bg-green-50 text-green-700' :
                          entry.status === 'rejected' ? 'bg-red-50 text-red-700' :
                          'bg-yellow-50 text-yellow-700'
                        }`}>
                          {entry.status}
                        </span>
                        <div className="px-3 py-2 bg-gray-50 rounded-xl">
                          <span className="text-sm font-bold text-gray-900">{entry.total_hours?.toFixed(2) || 0}h</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {report.taskEntries.map((entry) => (
                  <div key={`task-${entry.id}`} className="px-6 py-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 flex-1">
                        <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                        <div>
                          <p className="font-medium text-gray-900">{entry.task_title}</p>
                          <p className="text-sm text-gray-600">
                            {new Date(entry.start_time).toLocaleTimeString()} - {entry.end_time ? new Date(entry.end_time).toLocaleTimeString() : 'ongoing'}
                          </p>
                          {entry.description && <p className="text-sm text-gray-500 mt-1">{entry.description}</p>}
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className={`px-3 py-1 rounded-lg text-xs font-medium ${
                          entry.status === 'approved' ? 'bg-green-50 text-green-700' :
                          entry.status === 'rejected' ? 'bg-red-50 text-red-700' :
                          'bg-yellow-50 text-yellow-700'
                        }`}>
                          {entry.status}
                        </span>
                        <div className="px-3 py-2 bg-gray-50 rounded-xl">
                          <span className="text-sm font-bold text-gray-900">{entry.duration_hours?.toFixed(2) || 0}h</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {report.manualEntries.map((entry) => (
                  <div key={`manual-${entry.id}`} className="px-6 py-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 flex-1">
                        <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                        <div>
                          <p className="font-medium text-gray-900">{entry.task_title}</p>
                          {entry.description && <p className="text-sm text-gray-600 mt-1">{entry.description}</p>}
                          <p className="text-xs text-gray-500 mt-1">Manual Entry</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span className={`px-3 py-1 rounded-lg text-xs font-medium ${
                          entry.status === 'approved' ? 'bg-green-50 text-green-700' :
                          entry.status === 'rejected' ? 'bg-red-50 text-red-700' :
                          'bg-yellow-50 text-yellow-700'
                        }`}>
                          {entry.status || 'pending'}
                        </span>
                        <div className="px-3 py-2 bg-gray-50 rounded-xl">
                          <span className="text-sm font-bold text-gray-900">{entry.hours}h</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      ) : (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-12 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No Activity Yet</h3>
          <p className="text-gray-600">
            {isToday ? 'Start your day by logging time or completing tasks' : 'No activity was recorded on this date'}
          </p>
        </div>
      )}

      {/* Report Submission Section */}
      {!isSubmitted && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-gray-900">Submit Daily Report</h2>
          </div>

          {/* Holiday Toggle */}
          <div className="bg-gradient-to-br from-blue-50 to-cyan-50 border-2 border-blue-200 rounded-xl p-6">
            <label className="flex items-center space-x-4 cursor-pointer">
              <input
                type="checkbox"
                checked={isHoliday}
                onChange={(e) => setIsHoliday(e.target.checked)}
                className="w-5 h-5 text-blue-600 border-blue-300 rounded focus:ring-blue-500"
              />
              <div className="flex-1">
                <div className="flex items-center space-x-2">
                  <span className="text-lg font-bold text-gray-900">I was on holiday this day</span>
                  {isHoliday && (
                    <span className="px-2.5 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                      Holiday
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  Mark this day as holiday to skip task tracking requirements
                </p>
              </div>
            </label>
          </div>

          {/* Answer Questions Button */}
          {!isHoliday && forms.length > 0 && (
            <div className={`rounded-xl p-6 border transition-all ${
            hasAnsweredQuestions 
              ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-200' 
              : 'bg-gradient-to-br from-purple-50 to-pink-50 border-purple-100'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center shadow-lg ${
                  hasAnsweredQuestions
                    ? 'bg-gradient-to-br from-green-600 to-emerald-600 shadow-green-500/30'
                    : 'bg-gradient-to-br from-purple-600 to-pink-600 shadow-purple-500/30'
                }`}>
                  {hasAnsweredQuestions ? (
                    <CheckCircle2 className="w-6 h-6 text-white" />
                  ) : (
                    <FileText className="w-6 h-6 text-white" />
                  )}
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h3 className="text-lg font-bold text-gray-900">Report Questions</h3>
                    {hasAnsweredQuestions && (
                      <span className="px-2.5 py-0.5 bg-green-100 text-green-700 rounded-full text-xs font-semibold">
                        Answered
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">
                    {hasAnsweredQuestions 
                      ? 'Questions completed - you can edit your answers before submitting' 
                      : 'Answer the daily report questions'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowQuestionsModal(true)}
                className={`px-6 py-3 font-semibold rounded-xl transition-all ${
                  hasAnsweredQuestions
                    ? 'bg-gradient-to-r from-green-600 to-emerald-600 text-white hover:shadow-xl hover:shadow-green-500/30'
                    : 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:shadow-xl hover:shadow-purple-500/30'
                }`}
              >
                {hasAnsweredQuestions ? 'Edit Answers' : 'Answer Questions'}
              </button>
            </div>
          </div>
          )}

          {/* Additional Tasks */}
          {!isHoliday && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Additional Tasks (Not in System)</h3>
              <button
                onClick={addAdditionalTask}
                className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-lg hover:shadow-lg hover:shadow-indigo-500/30 transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>Add Task</span>
              </button>
            </div>
            <div className="space-y-3">
              {additionalTasks.map((task, index) => (
                <div key={index} className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl border border-gray-200">
                  <div className="flex-1">
                    <input
                      type="text"
                      value={task.task_description}
                      onChange={(e) => updateAdditionalTask(index, 'task_description', e.target.value)}
                      placeholder="Task description"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                  <div className="w-32">
                    <input
                      type="number"
                      value={task.hours_spent}
                      onChange={(e) => updateAdditionalTask(index, 'hours_spent', parseFloat(e.target.value))}
                      step="0.25"
                      min="0"
                      placeholder="Hours"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                  <button
                    onClick={() => removeAdditionalTask(index)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
              {additionalTasks.length === 0 && (
                <p className="text-sm text-gray-500 text-center py-8">No additional tasks added yet</p>
              )}
            </div>
          </div>
          )}

          {/* Submit Actions */}
          {!isHoliday && forms.length === 0 && (
            <div className="rounded-xl p-6 bg-amber-50 border border-amber-200 text-center">
              <AlertCircle className="w-12 h-12 text-amber-600 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-gray-900 mb-2">No Report Form Assigned</h3>
              <p className="text-sm text-gray-600 mb-4">
                Contact your administrator to get a report form assigned. You can still submit additional tasks below.
              </p>
            </div>
          )}
          
          <div className="flex space-x-3 pt-4 border-t border-gray-200">
            <button
              onClick={handleSaveDraft}
              disabled={isSaving}
              className="flex-1 flex items-center justify-center space-x-2 px-6 py-4 border-2 border-indigo-300 text-indigo-700 font-semibold rounded-xl hover:bg-indigo-50 transition-all disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              <span>{isSaving ? 'Saving...' : 'Save Draft'}</span>
            </button>
            <button
              onClick={handleSubmit}
              disabled={isSaving}
              className="flex-1 flex items-center justify-center space-x-2 px-6 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold rounded-xl hover:shadow-xl hover:shadow-indigo-500/30 transition-all disabled:opacity-50"
            >
              <Send className="w-5 h-5" />
              <span>Submit Report</span>
            </button>
          </div>
        </div>
      )}

      {isSubmitted && (
        <div className={`border-2 rounded-xl p-6 text-center ${
          submission?.is_holiday 
            ? 'bg-blue-50 border-blue-200' 
            : 'bg-green-50 border-green-200'
        }`}>
          <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
            submission?.is_holiday 
              ? 'bg-blue-100' 
              : 'bg-green-100'
          }`}>
            <CheckCircle2 className={`w-8 h-8 ${
              submission?.is_holiday 
                ? 'text-blue-600' 
                : 'text-green-600'
            }`} />
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">
            {submission?.is_holiday ? 'Holiday Marked' : 'Report Submitted'}
          </h3>
          <p className="text-gray-600">
            {submission?.is_holiday 
              ? `Marked as holiday on ${new Date(submission.submitted_at!).toLocaleString()}`
              : `Submitted on ${new Date(submission.submitted_at!).toLocaleString()}`
            }
          </p>
        </div>
      )}

      {/* AI Summary Modal */}
      {showSummaryModal && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-4 flex items-center justify-between rounded-t-2xl">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">AI Report Summary</h2>
                  <p className="text-sm text-indigo-100">{new Date(selectedDate).toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                </div>
              </div>
              <button
                onClick={() => setShowSummaryModal(false)}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-white" />
              </button>
            </div>
            
            <div className="p-6">
              {aiSummary && (
                <div className="prose prose-indigo max-w-none">
                  <div className="whitespace-pre-wrap text-gray-700 leading-relaxed">
                    {aiSummary}
                  </div>
                </div>
              )}
            </div>

            <div className="sticky bottom-0 bg-gray-50 px-6 py-4 flex justify-end rounded-b-2xl border-t border-gray-200">
              <button
                onClick={() => setShowSummaryModal(false)}
                className="px-6 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-indigo-500/30 transition-all"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Summary Error Message */}
      {summaryError && (
        <div className="fixed bottom-4 right-4 bg-red-50 border-2 border-red-200 rounded-xl p-4 shadow-lg max-w-md z-50">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold text-red-900">Failed to Generate Summary</h3>
              <p className="text-sm text-red-700 mt-1">{summaryError}</p>
            </div>
            <button
              onClick={() => setSummaryError(null)}
              className="p-1 hover:bg-red-100 rounded-lg transition-colors"
            >
              <X className="w-4 h-4 text-red-600" />
            </button>
          </div>
        </div>
      )}

      {/* Questions Modal */}
      {showQuestionsModal && forms[0] && (
        <ReportQuestionsModal
          formId={forms[0].id}
          submissionId={submission?.id || null}
          onClose={() => setShowQuestionsModal(false)}
          onSave={handleSaveAnswers}
        />
      )}
    </div>
  );
}
