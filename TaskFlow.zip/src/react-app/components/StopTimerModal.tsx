import { useState } from 'react';
import { X, CheckCircle2, Clock } from 'lucide-react';

interface StopTimerModalProps {
  taskTitle: string;
  timerId: number;
  taskId: number;
  description: string;
  onClose: () => void;
  onComplete: (isTaskComplete: boolean) => void;
}

export default function StopTimerModal({ 
  taskTitle, 
  timerId, 
  taskId, 
  description, 
  onClose, 
  onComplete 
}: StopTimerModalProps) {
  const [isStopping, setIsStopping] = useState(false);

  const handleStop = async (markComplete: boolean) => {
    setIsStopping(true);
    
    try {
      // Stop the timer
      const stopResponse = await fetch(`/api/task-time-entries/${timerId}/stop`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ description }),
      });

      if (!stopResponse.ok) {
        throw new Error('Failed to stop timer');
      }

      // Update task status
      const newStatus = markComplete ? 'completed' : 'in_progress';
      const taskResponse = await fetch(`/api/tasks/${taskId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });

      if (!taskResponse.ok) {
        throw new Error('Failed to update task status');
      }

      onComplete(markComplete);
    } catch (error) {
      console.error('Error stopping timer:', error);
      alert('Failed to stop timer. Please try again.');
      setIsStopping(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-[60]">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full">
        <div className="border-b border-gray-100 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Stop Timer</h2>
          <button
            onClick={onClose}
            disabled={isStopping}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors disabled:opacity-50"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <p className="text-gray-700 font-medium mb-2">Task: {taskTitle}</p>
            <p className="text-sm text-gray-600">
              Is this task complete, or do you still need to work on it?
            </p>
          </div>

          <div className="space-y-3">
            <button
              onClick={() => handleStop(true)}
              disabled={isStopping}
              className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-green-500/30 transition-all disabled:opacity-50"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>{isStopping ? 'Stopping...' : 'Task Complete'}</span>
            </button>

            <button
              onClick={() => handleStop(false)}
              disabled={isStopping}
              className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl hover:shadow-lg hover:shadow-blue-500/30 transition-all disabled:opacity-50"
            >
              <Clock className="w-5 h-5" />
              <span>{isStopping ? 'Stopping...' : 'Still In Progress'}</span>
            </button>

            <button
              onClick={onClose}
              disabled={isStopping}
              className="w-full px-6 py-3 border border-gray-300 text-gray-700 font-medium rounded-xl hover:bg-gray-50 transition-colors disabled:opacity-50"
            >
              Cancel
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
