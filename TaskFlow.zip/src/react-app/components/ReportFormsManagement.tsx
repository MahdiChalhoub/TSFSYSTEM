import { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Save, X, Users, UserPlus, ChevronDown, ChevronUp, FileText } from 'lucide-react';
import { OrganizationMember } from '@/shared/organization-types';

interface ReportForm {
  id: number;
  title: string;
  description: string | null;
  is_active: boolean;
}

interface ReportQuestion {
  id: number;
  form_id: number;
  question_text: string;
  question_type: string;
  is_required: boolean;
  sort_order: number;
}

interface QuestionChoice {
  id: number;
  question_id: number;
  choice_text: string;
  sort_order: number;
}

interface FormAssignment {
  id: number;
  form_id: number;
  user_id: string | null;
  group_id: number | null;
  user_name: string | null;
  user_email: string | null;
  group_name: string | null;
}

interface UserGroup {
  id: number;
  name: string;
  description: string | null;
}

const QUESTION_TYPES = [
  { value: 'text', label: 'Text Response' },
  { value: 'single_choice', label: 'Single Choice (Radio)' },
  { value: 'multiple_choice', label: 'Multiple Choice (Checkboxes)' }
];

export default function ReportFormsManagement() {
  const [forms, setForms] = useState<ReportForm[]>([]);
  const [selectedForm, setSelectedForm] = useState<ReportForm | null>(null);
  const [questions, setQuestions] = useState<ReportQuestion[]>([]);
  const [assignments, setAssignments] = useState<FormAssignment[]>([]);
  const [members, setMembers] = useState<OrganizationMember[]>([]);
  const [groups, setGroups] = useState<UserGroup[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Partial<ReportQuestion> | null>(null);
  const [questionChoices, setQuestionChoices] = useState<Record<number, QuestionChoice[]>>({});
  const [editingChoices, setEditingChoices] = useState<string[]>([]);
  const [expandedQuestions, setExpandedQuestions] = useState<Set<number>>(new Set());
  const [showAssignments, setShowAssignments] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [selectedGroupId, setSelectedGroupId] = useState<string>('');
  const [assignmentType, setAssignmentType] = useState<'user' | 'group'>('user');
  const [editingForm, setEditingForm] = useState<Partial<ReportForm> | null>(null);
  const [isEditingForm, setIsEditingForm] = useState(false);

  useEffect(() => {
    loadForms();
    loadMembers();
    loadGroups();
  }, []);

  useEffect(() => {
    if (selectedForm) {
      loadQuestions(selectedForm.id);
      loadAssignments(selectedForm.id);
    }
  }, [selectedForm]);

  const loadForms = async () => {
    try {
      const response = await fetch('/api/report-forms');
      if (response.ok) {
        const data = await response.json();
        setForms(data);
        if (data.length > 0 && !selectedForm) {
          setSelectedForm(data[0]);
        }
      }
    } catch (error) {
      console.error('Failed to load forms:', error);
    }
  };

  const loadMembers = async () => {
    try {
      const orgRes = await fetch('/api/organizations/current');
      if (orgRes.ok) {
        const org = await orgRes.json();
        if (org) {
          const membersRes = await fetch(`/api/organizations/${org.id}/members`);
          if (membersRes.ok) {
            const data = await membersRes.json();
            console.log('Loaded members:', data);
            setMembers(data);
          } else {
            console.error('Failed to load members:', await membersRes.text());
          }
        }
      } else {
        console.error('Failed to load org:', await orgRes.text());
      }
    } catch (error) {
      console.error('Failed to load members:', error);
    }
  };

  const loadGroups = async () => {
    try {
      const response = await fetch('/api/user-groups');
      if (response.ok) {
        const data = await response.json();
        console.log('Loaded groups:', data);
        setGroups(data);
      } else {
        console.error('Failed to load groups:', await response.text());
      }
    } catch (error) {
      console.error('Failed to load groups:', error);
    }
  };

  const loadQuestions = async (formId: number) => {
    try {
      const response = await fetch(`/api/report-forms/${formId}/questions`);
      if (response.ok) {
        const data = await response.json();
        setQuestions(data);
        
        // Load choices for single/multiple choice questions
        for (const question of data) {
          if (question.question_type === 'single_choice' || question.question_type === 'multiple_choice') {
            await loadChoices(question.id);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load questions:', error);
    }
  };

  const loadChoices = async (questionId: number) => {
    try {
      const response = await fetch(`/api/questions/${questionId}/choices`);
      if (response.ok) {
        const data = await response.json();
        setQuestionChoices(prev => ({ ...prev, [questionId]: data }));
      }
    } catch (error) {
      console.error('Failed to load choices:', error);
    }
  };

  const loadAssignments = async (formId: number) => {
    try {
      const response = await fetch(`/api/report-forms/${formId}/assignments`);
      if (response.ok) {
        const data = await response.json();
        setAssignments(data);
      }
    } catch (error) {
      console.error('Failed to load assignments:', error);
    }
  };

  const handleCreateForm = async () => {
    try {
      const response = await fetch('/api/report-forms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: 'New Report Form',
          description: 'Daily report form for employees',
          is_active: true
        })
      });

      if (response.ok) {
        await loadForms();
      }
    } catch (error) {
      console.error('Failed to create form:', error);
    }
  };

  const handleEditFormClick = () => {
    if (selectedForm) {
      setEditingForm(selectedForm);
      setIsEditingForm(true);
    }
  };

  const handleSaveForm = async () => {
    if (!editingForm || !editingForm.id || !editingForm.title) return;

    try {
      const response = await fetch(`/api/report-forms/${editingForm.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: editingForm.title,
          description: editingForm.description || null,
          is_active: editingForm.is_active
        })
      });

      if (response.ok) {
        setIsEditingForm(false);
        setEditingForm(null);
        await loadForms();
        const updated = await response.json();
        setSelectedForm(updated);
      }
    } catch (error) {
      console.error('Failed to update form:', error);
    }
  };

  const handleDeleteForm = async () => {
    if (!selectedForm || !confirm('Delete this form? This will also delete all questions and assignments.')) return;

    try {
      const response = await fetch(`/api/report-forms/${selectedForm.id}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        setSelectedForm(null);
        await loadForms();
      }
    } catch (error) {
      console.error('Failed to delete form:', error);
    }
  };

  const handleSaveQuestion = async () => {
    if (!editingQuestion || !selectedForm) return;

    try {
      const url = editingQuestion.id 
        ? `/api/report-forms/${selectedForm.id}/questions/${editingQuestion.id}`
        : `/api/report-forms/${selectedForm.id}/questions`;
      
      const method = editingQuestion.id ? 'PATCH' : 'POST';

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question_text: editingQuestion.question_text,
          question_type: editingQuestion.question_type || 'text',
          is_required: editingQuestion.is_required || false
        })
      });

      if (response.ok) {
        const savedQuestion = await response.json();
        
        // Save choices for single/multiple choice questions
        if (savedQuestion.question_type === 'single_choice' || savedQuestion.question_type === 'multiple_choice') {
          // Delete existing choices
          const existingChoices = questionChoices[savedQuestion.id] || [];
          for (const choice of existingChoices) {
            await fetch(`/api/questions/${savedQuestion.id}/choices/${choice.id}`, {
              method: 'DELETE'
            });
          }
          
          // Create new choices
          for (const choiceText of editingChoices) {
            if (choiceText.trim()) {
              await fetch(`/api/questions/${savedQuestion.id}/choices`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ choice_text: choiceText.trim() })
              });
            }
          }
        }
        
        setEditingQuestion(null);
        setEditingChoices([]);
        setIsEditing(false);
        await loadQuestions(selectedForm.id);
      }
    } catch (error) {
      console.error('Failed to save question:', error);
    }
  };

  const handleDeleteQuestion = async (questionId: number) => {
    if (!selectedForm || !confirm('Delete this question?')) return;

    try {
      const response = await fetch(`/api/report-forms/${selectedForm.id}/questions/${questionId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        await loadQuestions(selectedForm.id);
      }
    } catch (error) {
      console.error('Failed to delete question:', error);
    }
  };

  const handleAssign = async () => {
    if (!selectedForm) {
      alert('No form selected');
      return;
    }
    
    if (assignmentType === 'user' && !selectedUserId) {
      alert('Please select a user to assign');
      return;
    }
    if (assignmentType === 'group' && !selectedGroupId) {
      if (groups.length === 0) {
        alert('No user groups available. Please create a user group in Settings first.');
      } else {
        alert('Please select a group to assign');
      }
      return;
    }

    try {
      const body = assignmentType === 'user' 
        ? { user_id: selectedUserId }
        : { group_id: parseInt(selectedGroupId) };

      console.log('Assigning form:', selectedForm.id, 'with body:', body);

      const response = await fetch(`/api/report-forms/${selectedForm.id}/assignments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      if (response.ok) {
        setSelectedUserId('');
        setSelectedGroupId('');
        await loadAssignments(selectedForm.id);
        alert('Assignment successful!');
      } else {
        let errorMessage = 'Unknown error';
        try {
          const errorData = await response.json();
          console.error('Assignment failed with status', response.status, ':', errorData);
          errorMessage = errorData.error || errorMessage;
        } catch (e) {
          console.error('Could not parse error response:', e);
          errorMessage = `Server error (${response.status})`;
        }
        
        alert(`Failed to assign: ${errorMessage}`);
      }
    } catch (error) {
      console.error('Failed to assign:', error);
      alert('Failed to assign. Please check your internet connection and try again.');
    }
  };

  const handleRemoveAssignment = async (assignmentId: number) => {
    if (!selectedForm || !confirm('Remove this assignment?')) return;

    try {
      const response = await fetch(`/api/report-forms/${selectedForm.id}/assignments/${assignmentId}`, {
        method: 'DELETE'
      });

      if (response.ok) {
        await loadAssignments(selectedForm.id);
      }
    } catch (error) {
      console.error('Failed to remove assignment:', error);
    }
  };

  const handleEditQuestion = (question: ReportQuestion) => {
    setEditingQuestion(question);
    
    // Load choices if it's a choice question
    if (question.question_type === 'single_choice' || question.question_type === 'multiple_choice') {
      const choices = questionChoices[question.id] || [];
      setEditingChoices(choices.map(c => c.choice_text));
    } else {
      setEditingChoices([]);
    }
    
    setIsEditing(true);
  };

  const addChoice = () => {
    setEditingChoices([...editingChoices, '']);
  };

  const updateChoice = (index: number, value: string) => {
    const updated = [...editingChoices];
    updated[index] = value;
    setEditingChoices(updated);
  };

  const removeChoice = (index: number) => {
    setEditingChoices(editingChoices.filter((_, i) => i !== index));
  };

  const toggleQuestionExpand = (questionId: number) => {
    const newExpanded = new Set(expandedQuestions);
    if (newExpanded.has(questionId)) {
      newExpanded.delete(questionId);
    } else {
      newExpanded.add(questionId);
    }
    setExpandedQuestions(newExpanded);
  };

  const getQuestionTypeLabel = (type: string) => {
    return QUESTION_TYPES.find(t => t.value === type)?.label || type;
  };

  const getUnassignedMembers = () => {
    const assignedUserIds = assignments.filter(a => a.user_id).map(a => a.user_id);
    return members.filter(m => !assignedUserIds.includes(m.user_id));
  };

  const getUnassignedGroups = () => {
    const assignedGroupIds = assignments.filter(a => a.group_id).map(a => a.group_id);
    return groups.filter(g => !assignedGroupIds.includes(g.id));
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900">Report Forms Management</h2>
          </div>
          <button
            onClick={handleCreateForm}
            className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-indigo-500/30 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>New Form</span>
          </button>
        </div>

        {isEditingForm && editingForm && (
          <div className="mb-4 p-4 bg-indigo-50 rounded-lg border border-indigo-200">
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-indigo-900 mb-2">Form Name</label>
                <input
                  type="text"
                  value={editingForm.title}
                  onChange={(e) => setEditingForm({ ...editingForm, title: e.target.value })}
                  className="w-full px-4 py-2.5 border border-indigo-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                  placeholder="Enter form name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-indigo-900 mb-2">Description (Optional)</label>
                <textarea
                  value={editingForm.description || ''}
                  onChange={(e) => setEditingForm({ ...editingForm, description: e.target.value })}
                  className="w-full px-4 py-2.5 border border-indigo-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                  placeholder="Enter description"
                  rows={3}
                />
              </div>

              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={editingForm.is_active}
                  onChange={(e) => setEditingForm({ ...editingForm, is_active: e.target.checked })}
                  className="rounded border-indigo-300 text-indigo-600 focus:ring-indigo-500"
                />
                <label className="text-sm text-indigo-900">Active (employees can submit this form)</label>
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={handleSaveForm}
                  className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                >
                  <Save className="w-4 h-4" />
                  <span>Save</span>
                </button>
                <button
                  onClick={() => {
                    setEditingForm(null);
                    setIsEditingForm(false);
                  }}
                  className="flex items-center space-x-2 px-4 py-2 border border-indigo-300 text-indigo-700 rounded-lg hover:bg-indigo-50 transition-colors"
                >
                  <X className="w-4 h-4" />
                  <span>Cancel</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {forms.length > 0 && !isEditingForm && (
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Form</label>
            <div className="flex space-x-2">
              <select
                value={selectedForm?.id || ''}
                onChange={(e) => {
                  const form = forms.find(f => f.id === parseInt(e.target.value));
                  setSelectedForm(form || null);
                }}
                className="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
              >
                {forms.map(form => (
                  <option key={form.id} value={form.id}>
                    {form.title} {form.is_active ? '(Active)' : '(Inactive)'}
                  </option>
                ))}
              </select>
              <button
                onClick={handleEditFormClick}
                className="px-4 py-2.5 bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 transition-colors flex items-center space-x-2"
              >
                <Edit2 className="w-4 h-4" />
                <span>Edit Name</span>
              </button>
              <button
                onClick={handleDeleteForm}
                className="px-4 py-2.5 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors flex items-center space-x-2"
              >
                <Trash2 className="w-4 h-4" />
                <span>Delete</span>
              </button>
            </div>
            {selectedForm && selectedForm.description && (
              <p className="mt-2 text-sm text-gray-600">{selectedForm.description}</p>
            )}
          </div>
        )}

        {forms.length === 0 && (
          <div className="text-center py-8 border-2 border-dashed border-gray-200 rounded-lg">
            <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-sm text-gray-500 mb-1">No forms created yet</p>
            <p className="text-xs text-gray-400">Click "New Form" to create your first report form</p>
          </div>
        )}
      </div>

      {selectedForm && !isEditingForm && (
        <>
          {/* Tab Navigation */}
          <div className="flex space-x-1 bg-white rounded-xl p-1 shadow-sm border border-indigo-100">
            <button
              onClick={() => setShowAssignments(false)}
              className={`flex-1 flex items-center justify-center space-x-2 px-6 py-2.5 rounded-lg font-medium transition-all duration-200 ${
                !showAssignments
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <Edit2 className="w-4 h-4" />
              <span>Questions ({questions.length})</span>
            </button>
            <button
              onClick={() => setShowAssignments(true)}
              className={`flex-1 flex items-center justify-center space-x-2 px-6 py-2.5 rounded-lg font-medium transition-all duration-200 ${
                showAssignments
                  ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
                  : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>Assigned To ({assignments.length})</span>
            </button>
          </div>

          {!showAssignments ? (
            // Questions Tab
            <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Questions</h3>
                <button
                  onClick={() => {
                    setEditingQuestion({ 
                      form_id: selectedForm.id, 
                      question_text: '', 
                      question_type: 'text', 
                      is_required: false 
                    });
                    setEditingChoices([]);
                    setIsEditing(true);
                  }}
                  className="flex items-center space-x-2 px-3 py-2 text-sm bg-indigo-100 text-indigo-700 rounded-lg hover:bg-indigo-200 transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Question</span>
                </button>
              </div>

              {isEditing && editingQuestion && (
                <div className="mb-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Question Type</label>
                      <select
                        value={editingQuestion.question_type || 'text'}
                        onChange={(e) => {
                          setEditingQuestion({ ...editingQuestion, question_type: e.target.value });
                          if (e.target.value === 'text') {
                            setEditingChoices([]);
                          } else if (editingChoices.length === 0) {
                            setEditingChoices(['', '']);
                          }
                        }}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                      >
                        {QUESTION_TYPES.map(type => (
                          <option key={type.value} value={type.value}>{type.label}</option>
                        ))}
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Question</label>
                      <input
                        type="text"
                        value={editingQuestion.question_text}
                        onChange={(e) => setEditingQuestion({ ...editingQuestion, question_text: e.target.value })}
                        className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                        placeholder="Enter question text"
                      />
                    </div>

                    {(editingQuestion.question_type === 'single_choice' || editingQuestion.question_type === 'multiple_choice') && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Choices</label>
                        <div className="space-y-2">
                          {editingChoices.map((choice, index) => (
                            <div key={index} className="flex items-center space-x-2">
                              <input
                                type="text"
                                value={choice}
                                onChange={(e) => updateChoice(index, e.target.value)}
                                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500"
                                placeholder={`Choice ${index + 1}`}
                              />
                              <button
                                onClick={() => removeChoice(index)}
                                className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          ))}
                          <button
                            onClick={addChoice}
                            className="flex items-center space-x-2 px-3 py-2 text-sm bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                          >
                            <Plus className="w-4 h-4" />
                            <span>Add Choice</span>
                          </button>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={editingQuestion.is_required || false}
                        onChange={(e) => setEditingQuestion({ ...editingQuestion, is_required: e.target.checked })}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <label className="text-sm text-gray-700">Required</label>
                    </div>
                    
                    <div className="flex space-x-2">
                      <button
                        onClick={handleSaveQuestion}
                        className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
                      >
                        <Save className="w-4 h-4" />
                        <span>Save</span>
                      </button>
                      <button
                        onClick={() => {
                          setEditingQuestion(null);
                          setEditingChoices([]);
                          setIsEditing(false);
                        }}
                        className="flex items-center space-x-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                      >
                        <X className="w-4 h-4" />
                        <span>Cancel</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                {questions.length === 0 ? (
                  <p className="text-sm text-gray-500 text-center py-8">No questions added yet</p>
                ) : (
                  questions.map((question) => {
                    const isExpanded = expandedQuestions.has(question.id);
                    const choices = questionChoices[question.id] || [];
                    const hasChoices = question.question_type === 'single_choice' || question.question_type === 'multiple_choice';
                    
                    return (
                      <div key={question.id} className="border border-gray-200 rounded-lg overflow-hidden">
                        <div className="flex items-center justify-between p-3 bg-gray-50">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2">
                              <p className="font-medium text-gray-900">
                                {question.question_text}
                                {question.is_required && <span className="text-red-500 ml-1">*</span>}
                              </p>
                              <span className="px-2 py-0.5 bg-indigo-100 text-indigo-700 text-xs font-medium rounded">
                                {getQuestionTypeLabel(question.question_type)}
                              </span>
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 ml-4">
                            {hasChoices && (
                              <button
                                onClick={() => toggleQuestionExpand(question.id)}
                                className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                              >
                                {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                              </button>
                            )}
                            <button
                              onClick={() => handleEditQuestion(question)}
                              className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                            >
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => handleDeleteQuestion(question.id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                        
                        {hasChoices && isExpanded && (
                          <div className="p-3 bg-white border-t border-gray-200">
                            <p className="text-xs font-medium text-gray-500 mb-2">Choices:</p>
                            <ul className="space-y-1">
                              {choices.map((choice, index) => (
                                <li key={choice.id} className="text-sm text-gray-700 flex items-center space-x-2">
                                  <span className="text-gray-400">{index + 1}.</span>
                                  <span>{choice.choice_text}</span>
                                </li>
                              ))}
                              {choices.length === 0 && (
                                <li className="text-sm text-gray-400 italic">No choices defined</li>
                              )}
                            </ul>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          ) : (
            // Assignments Tab
            <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Assign Form to Users</h3>
              </div>

              {/* No Groups Available Message */}
              {assignmentType === 'group' && groups.length === 0 && (
                <div className="mb-6 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0">
                      <Users className="w-5 h-5 text-yellow-600" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-sm font-medium text-yellow-900 mb-1">No User Groups Found</h4>
                      <p className="text-sm text-yellow-800 mb-3">
                        You need to create user groups before you can assign forms to them. User groups let you assign forms to multiple users at once.
                      </p>
                      <button
                        onClick={() => window.location.hash = '#create-group'}
                        className="text-sm font-medium text-yellow-900 hover:text-yellow-700 underline"
                      >
                        Go to Settings → User Groups to create a group
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Assign Form */}
              {(getUnassignedMembers().length > 0 || getUnassignedGroups().length > 0) && (
                <div className="mb-6 p-4 bg-indigo-50 rounded-lg border border-indigo-200">
                  <label className="block text-sm font-medium text-indigo-900 mb-2">Assign "{selectedForm.title}" to</label>
                  
                  {/* Assignment Type Selector */}
                  <div className="flex space-x-1 bg-white rounded-lg p-1 mb-3">
                    <button
                      onClick={() => setAssignmentType('user')}
                      className={`flex-1 px-3 py-2 rounded-lg font-medium text-sm transition-all ${
                        assignmentType === 'user'
                          ? 'bg-indigo-600 text-white'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      Individual User
                    </button>
                    <button
                      onClick={() => setAssignmentType('group')}
                      className={`flex-1 px-3 py-2 rounded-lg font-medium text-sm transition-all ${
                        assignmentType === 'group'
                          ? 'bg-indigo-600 text-white'
                          : 'text-gray-600 hover:bg-gray-50'
                      }`}
                    >
                      User Group {groups.length === 0 && '(None Created)'}
                    </button>
                  </div>

                  <div className="flex space-x-2">
                    {assignmentType === 'user' ? (
                      <select
                        value={selectedUserId}
                        onChange={(e) => setSelectedUserId(e.target.value)}
                        className="flex-1 px-4 py-2.5 border border-indigo-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                        disabled={getUnassignedMembers().length === 0}
                      >
                        <option value="">Select an employee...</option>
                        {getUnassignedMembers().map(member => (
                          <option key={member.user_id} value={member.user_id}>
                            {member.name || member.email}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <select
                        value={selectedGroupId}
                        onChange={(e) => setSelectedGroupId(e.target.value)}
                        className="flex-1 px-4 py-2.5 border border-indigo-300 rounded-lg focus:ring-2 focus:ring-indigo-500 bg-white"
                        disabled={getUnassignedGroups().length === 0}
                      >
                        <option value="">
                          {groups.length === 0 
                            ? 'No groups available - create one in Settings' 
                            : getUnassignedGroups().length === 0 
                              ? 'All groups already assigned'
                              : 'Select a group...'}
                        </option>
                        {getUnassignedGroups().map(group => (
                          <option key={group.id} value={group.id}>
                            {group.name}
                          </option>
                        ))}
                      </select>
                    )}
                    <button
                      onClick={handleAssign}
                      disabled={
                        (assignmentType === 'user' && !selectedUserId) ||
                        (assignmentType === 'group' && !selectedGroupId)
                      }
                      className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <UserPlus className="w-4 h-4" />
                      <span>Assign</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Assignments List */}
              <div className="space-y-2">
                {assignments.length === 0 ? (
                  <div className="text-center py-8">
                    <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-sm text-gray-500">No assignments yet</p>
                    <p className="text-xs text-gray-400 mt-1">Assign individual users or groups to allow them to submit this report</p>
                  </div>
                ) : (
                  assignments.map((assignment) => (
                    <div key={assignment.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 bg-gradient-to-br rounded-full flex items-center justify-center ${
                          assignment.group_id 
                            ? 'from-purple-100 to-pink-100' 
                            : 'from-indigo-100 to-purple-100'
                        }`}>
                          <Users className={`w-5 h-5 ${
                            assignment.group_id ? 'text-purple-600' : 'text-indigo-600'
                          }`} />
                        </div>
                        <div>
                          <div className="flex items-center space-x-2">
                            <p className="font-medium text-gray-900">
                              {assignment.group_id ? assignment.group_name : assignment.user_name}
                            </p>
                            {assignment.group_id && (
                              <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs font-medium rounded">
                                Group
                              </span>
                            )}
                          </div>
                          {assignment.user_email && (
                            <p className="text-sm text-gray-500">{assignment.user_email}</p>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => handleRemoveAssignment(assignment.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>

              {assignments.length > 0 && (
                <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>{assignments.filter(a => a.user_id).length}</strong> individual user{assignments.filter(a => a.user_id).length !== 1 ? 's' : ''} and{' '}
                    <strong>{assignments.filter(a => a.group_id).length}</strong> group{assignments.filter(a => a.group_id).length !== 1 ? 's' : ''} assigned
                  </p>
                </div>
              )}
            </div>
          )}
        </>
      )}
    </div>
  );
}
