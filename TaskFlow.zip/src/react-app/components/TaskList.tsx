import { useState, useEffect } from 'react';
import { Task, TaskCategory } from '@/shared/types';
import { OrganizationMember } from '@/shared/organization-types';
import { Clock, User, Calendar, CheckCircle2, Circle, XCircle, FolderKanban } from 'lucide-react';
import EditTaskModal from './EditTaskModal';

interface TaskListProps {
  tasks: Task[];
  onUpdate: () => void;
}

export default function TaskList({ tasks, onUpdate }: TaskListProps) {
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [categories, setCategories] = useState<TaskCategory[]>([]);
  const [members, setMembers] = useState<OrganizationMember[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [categoriesRes, orgRes] = await Promise.all([
        fetch('/api/task-categories'),
        fetch('/api/organizations/current')
      ]);

      if (categoriesRes.ok) {
        const categoriesData = await categoriesRes.json();
        setCategories(categoriesData);
      }

      if (orgRes.ok) {
        const orgData = await orgRes.json();
        if (orgData) {
          const membersRes = await fetch(`/api/organizations/${orgData.id}/members`);
          if (membersRes.ok) {
            const membersData = await membersRes.json();
            setMembers(membersData);
          }
        }
      }
    } catch (error) {
      console.error('Failed to load data:', error);
    }
  };

  const getCategoryName = (categoryId: number | null) => {
    if (!categoryId) return null;
    const category = categories.find(c => c.id === categoryId);
    return category?.name;
  };

  const getAssignedUserName = (userId: string | null) => {
    if (!userId) return null;
    const member = members.find(m => m.user_id === userId);
    return member ? (member.name || member.email || 'Unknown') : 'Unknown';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle2 className="w-5 h-5 text-green-600" />;
      case 'in_progress':
        return <Clock className="w-5 h-5 text-blue-600" />;
      case 'cancelled':
        return <XCircle className="w-5 h-5 text-gray-400" />;
      default:
        return <Circle className="w-5 h-5 text-gray-400" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-200';
      case 'in_progress':
        return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'cancelled':
        return 'bg-gray-100 text-gray-500 border-gray-200';
      default:
        return 'bg-purple-100 text-purple-700 border-purple-200';
    }
  };

  if (tasks.length === 0) {
    return (
      <div className="text-center py-20">
        <div className="w-16 h-16 bg-gradient-to-br from-indigo-100 to-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <CheckCircle2 className="w-8 h-8 text-indigo-600" />
        </div>
        <h3 className="text-xl font-semibold text-gray-900 mb-2">No tasks yet</h3>
        <p className="text-gray-600">Create your first task to get started</p>
      </div>
    );
  }

  return (
    <>
      <div className="grid gap-4">
        {tasks.map((task) => (
          <div
            key={task.id}
            onClick={() => setEditingTask(task)}
            className="bg-white rounded-xl p-6 shadow-sm border border-indigo-50 hover:shadow-lg hover:border-indigo-200 transition-all duration-200 cursor-pointer"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-start space-x-3 flex-1">
                <div className="mt-0.5">
                  {getStatusIcon(task.status)}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-lg font-semibold text-gray-900 mb-1">
                    {task.title}
                  </h3>
                  {task.description && (
                    <p className="text-gray-600 text-sm line-clamp-2">
                      {task.description}
                    </p>
                  )}
                </div>
              </div>
              <div className="flex items-center space-x-2 ml-4">
                <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getPriorityColor(task.priority)}`}>
                  {task.priority}
                </span>
                <span className={`px-3 py-1 rounded-lg text-xs font-medium border ${getStatusColor(task.status)}`}>
                  {task.status.replace('_', ' ')}
                </span>
              </div>
            </div>

            <div className="flex items-center space-x-4 text-sm text-gray-500">
              {getCategoryName(task.category_id) && (
                <div className="flex items-center space-x-1.5">
                  <FolderKanban className="w-4 h-4" />
                  <span>{getCategoryName(task.category_id)}</span>
                </div>
              )}
              {task.due_date && (
                <div className="flex items-center space-x-1.5">
                  <Calendar className="w-4 h-4" />
                  <span>Due {new Date(task.due_date).toLocaleDateString()}</span>
                </div>
              )}
              {task.assigned_to_user_id && (
                <div className="flex items-center space-x-1.5">
                  <User className="w-4 h-4" />
                  <span>{getAssignedUserName(task.assigned_to_user_id)}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {editingTask && (
        <EditTaskModal
          task={editingTask}
          onClose={() => setEditingTask(null)}
          onSuccess={() => {
            setEditingTask(null);
            onUpdate();
          }}
        />
      )}
    </>
  );
}
