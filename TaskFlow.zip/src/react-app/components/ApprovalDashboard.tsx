import { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Clock, Calendar, User } from 'lucide-react';
import { DayTimeEntry, TaskTimeEntry, TimeEntry } from '@/shared/types';

interface ApprovalData {
  manualEntries: (TimeEntry & { task_title?: string; user_name?: string })[];
  dayEntries: (DayTimeEntry & { user_name?: string })[];
  taskEntries: (TaskTimeEntry & { task_title?: string; user_name?: string })[];
}

interface ApprovalDashboardProps {
  onUpdate: () => void;
}

export default function ApprovalDashboard({ onUpdate }: ApprovalDashboardProps) {
  const [approvalData, setApprovalData] = useState<ApprovalData>({
    manualEntries: [],
    dayEntries: [],
    taskEntries: []
  });
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'manual' | 'day' | 'task'>('manual');

  useEffect(() => {
    loadApprovals();
  }, []);

  const loadApprovals = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/approvals/pending');
      if (response.ok) {
        const data = await response.json();
        setApprovalData(data);
      }
    } catch (error) {
      console.error('Failed to load approvals:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleApproveManual = async (id: number) => {
    try {
      const response = await fetch(`/api/time-entries/${id}/approve`, {
        method: 'POST',
      });

      if (response.ok) {
        await loadApprovals();
        onUpdate();
      }
    } catch (error) {
      console.error('Failed to approve:', error);
    }
  };

  const handleRejectManual = async (id: number) => {
    try {
      const response = await fetch(`/api/time-entries/${id}/reject`, {
        method: 'POST',
      });

      if (response.ok) {
        await loadApprovals();
        onUpdate();
      }
    } catch (error) {
      console.error('Failed to reject:', error);
    }
  };

  const handleApproveDay = async (id: number) => {
    try {
      const response = await fetch(`/api/day-time-entries/${id}/approve`, {
        method: 'POST',
      });

      if (response.ok) {
        await loadApprovals();
        onUpdate();
      }
    } catch (error) {
      console.error('Failed to approve:', error);
    }
  };

  const handleRejectDay = async (id: number) => {
    try {
      const response = await fetch(`/api/day-time-entries/${id}/reject`, {
        method: 'POST',
      });

      if (response.ok) {
        await loadApprovals();
        onUpdate();
      }
    } catch (error) {
      console.error('Failed to reject:', error);
    }
  };

  const handleApproveTask = async (id: number) => {
    try {
      const response = await fetch(`/api/task-time-entries/${id}/approve`, {
        method: 'POST',
      });

      if (response.ok) {
        await loadApprovals();
        onUpdate();
      }
    } catch (error) {
      console.error('Failed to approve:', error);
    }
  };

  const handleRejectTask = async (id: number) => {
    try {
      const response = await fetch(`/api/task-time-entries/${id}/reject`, {
        method: 'POST',
      });

      if (response.ok) {
        await loadApprovals();
        onUpdate();
      }
    } catch (error) {
      console.error('Failed to reject:', error);
    }
  };

  const totalPending = approvalData.manualEntries.length + approvalData.dayEntries.length + approvalData.taskEntries.length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-pulse text-gray-400">Loading approvals...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl shadow-lg shadow-indigo-500/30 p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">Time Approval Dashboard</h2>
        <p className="text-indigo-100">
          {totalPending > 0 ? `${totalPending} entries pending approval` : 'No entries pending approval'}
        </p>
      </div>

      {/* Tabs */}
      <div className="flex space-x-1 bg-white rounded-xl p-1 shadow-sm border border-indigo-100">
        <button
          onClick={() => setActiveTab('manual')}
          className={`flex-1 px-4 py-2.5 rounded-lg font-medium transition-all duration-200 ${
            activeTab === 'manual'
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
          }`}
        >
          Manual Entries ({approvalData.manualEntries.length})
        </button>
        <button
          onClick={() => setActiveTab('day')}
          className={`flex-1 px-4 py-2.5 rounded-lg font-medium transition-all duration-200 ${
            activeTab === 'day'
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
          }`}
        >
          Daily Time ({approvalData.dayEntries.length})
        </button>
        <button
          onClick={() => setActiveTab('task')}
          className={`flex-1 px-4 py-2.5 rounded-lg font-medium transition-all duration-200 ${
            activeTab === 'task'
              ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30'
              : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
          }`}
        >
          Task Timers ({approvalData.taskEntries.length})
        </button>
      </div>

      {/* Manual Entries */}
      {activeTab === 'manual' && (
        <div className="space-y-3">
          {approvalData.manualEntries.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-12 text-center">
              <CheckCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No manual entries pending approval</p>
            </div>
          ) : (
            approvalData.manualEntries.map((entry) => (
              <div key={entry.id} className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <User className="w-4 h-4 text-gray-500" />
                      <span className="font-semibold text-gray-900">{entry.user_name || 'Unknown User'}</span>
                    </div>
                    <h4 className="font-medium text-gray-900 mb-1">{entry.task_title}</h4>
                    {entry.description && (
                      <p className="text-sm text-gray-600 mb-2">{entry.description}</p>
                    )}
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{new Date(entry.entry_date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4" />
                        <span className="font-semibold text-indigo-600">{entry.hours}h</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleApproveManual(entry.id)}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-green-500/30 transition-all"
                  >
                    <CheckCircle className="w-5 h-5" />
                    <span>Approve</span>
                  </button>
                  <button
                    onClick={() => handleRejectManual(entry.id)}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-red-600 to-rose-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-red-500/30 transition-all"
                  >
                    <XCircle className="w-5 h-5" />
                    <span>Reject</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Day Entries */}
      {activeTab === 'day' && (
        <div className="space-y-3">
          {approvalData.dayEntries.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-12 text-center">
              <CheckCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No daily time entries pending approval</p>
            </div>
          ) : (
            approvalData.dayEntries.map((entry) => (
              <div key={entry.id} className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <User className="w-4 h-4 text-gray-500" />
                      <span className="font-semibold text-gray-900">{entry.user_name || 'Unknown User'}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mb-2">
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Clock In</p>
                        <p className="text-sm font-medium text-gray-900">
                          {new Date(entry.clock_in_time).toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Clock Out</p>
                        <p className="text-sm font-medium text-gray-900">
                          {entry.clock_out_time ? new Date(entry.clock_out_time).toLocaleString() : 'Not clocked out'}
                        </p>
                      </div>
                    </div>
                    {entry.notes && (
                      <p className="text-sm text-gray-600 mb-2 italic">{entry.notes}</p>
                    )}
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4 text-indigo-600" />
                      <span className="text-lg font-semibold text-indigo-600">
                        {entry.total_hours?.toFixed(2)}h
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleApproveDay(entry.id)}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-green-500/30 transition-all"
                  >
                    <CheckCircle className="w-5 h-5" />
                    <span>Approve</span>
                  </button>
                  <button
                    onClick={() => handleRejectDay(entry.id)}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-red-600 to-rose-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-red-500/30 transition-all"
                  >
                    <XCircle className="w-5 h-5" />
                    <span>Reject</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Task Entries */}
      {activeTab === 'task' && (
        <div className="space-y-3">
          {approvalData.taskEntries.length === 0 ? (
            <div className="bg-white rounded-xl shadow-sm border border-indigo-50 p-12 text-center">
              <CheckCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">No task timer entries pending approval</p>
            </div>
          ) : (
            approvalData.taskEntries.map((entry) => (
              <div key={entry.id} className="bg-white rounded-xl shadow-sm border border-indigo-50 p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <User className="w-4 h-4 text-gray-500" />
                      <span className="font-semibold text-gray-900">{entry.user_name || 'Unknown User'}</span>
                    </div>
                    <h4 className="font-medium text-gray-900 mb-1">{entry.task_title}</h4>
                    {entry.description && (
                      <p className="text-sm text-gray-600 mb-2">{entry.description}</p>
                    )}
                    <div className="grid grid-cols-2 gap-4 mb-2">
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Started</p>
                        <p className="text-sm font-medium text-gray-900">
                          {new Date(entry.start_time).toLocaleString()}
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500 mb-1">Ended</p>
                        <p className="text-sm font-medium text-gray-900">
                          {entry.end_time ? new Date(entry.end_time).toLocaleString() : 'Not ended'}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4 text-indigo-600" />
                      <span className="text-lg font-semibold text-indigo-600">
                        {entry.duration_hours?.toFixed(2)}h
                      </span>
                    </div>
                  </div>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => handleApproveTask(entry.id)}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-green-600 to-emerald-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-green-500/30 transition-all"
                  >
                    <CheckCircle className="w-5 h-5" />
                    <span>Approve</span>
                  </button>
                  <button
                    onClick={() => handleRejectTask(entry.id)}
                    className="flex-1 flex items-center justify-center space-x-2 px-4 py-2.5 bg-gradient-to-r from-red-600 to-rose-600 text-white font-medium rounded-lg hover:shadow-lg hover:shadow-red-500/30 transition-all"
                  >
                    <XCircle className="w-5 h-5" />
                    <span>Reject</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
