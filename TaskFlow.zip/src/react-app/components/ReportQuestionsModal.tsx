import { useState, useEffect } from 'react';
import { X, FileText, Save } from 'lucide-react';

interface ReportQuestion {
  id: number;
  question_text: string;
  question_type: string;
  is_required: boolean;
}

interface QuestionChoice {
  id: number;
  question_id: number;
  choice_text: string;
  sort_order: number;
}

interface ReportQuestionsModalProps {
  formId: number;
  submissionId: number | null;
  onClose: () => void;
  onSave: (answers: Record<number, string>) => Promise<void>;
}

export default function ReportQuestionsModal({ formId, submissionId, onClose, onSave }: ReportQuestionsModalProps) {
  const [questions, setQuestions] = useState<ReportQuestion[]>([]);
  const [questionChoices, setQuestionChoices] = useState<Record<number, QuestionChoice[]>>({});
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadQuestions();
  }, [formId, submissionId]);

  const loadQuestions = async () => {
    setIsLoading(true);
    try {
      const questionsRes = await fetch(`/api/report-forms/${formId}/questions`);
      if (questionsRes.ok) {
        const questionsData = await questionsRes.json();
        setQuestions(questionsData);
        
        for (const question of questionsData) {
          if (question.question_type === 'single_choice' || question.question_type === 'multiple_choice') {
            const choicesRes = await fetch(`/api/questions/${question.id}/choices`);
            if (choicesRes.ok) {
              const choicesData = await choicesRes.json();
              setQuestionChoices(prev => ({ ...prev, [question.id]: choicesData }));
            }
          }
        }
      }

      if (submissionId) {
        const answersRes = await fetch(`/api/report-submissions/${submissionId}/answers`);
        if (answersRes.ok) {
          const answersData = await answersRes.json();
          const answersMap: Record<number, string> = {};
          answersData.forEach((a: any) => {
            answersMap[a.question_id] = a.answer_text || '';
          });
          setAnswers(answersMap);
        }
      }
    } catch (error) {
      console.error('Failed to load questions:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    const validation = validateForm();
    if (!validation.valid) {
      alert(`Please answer all required questions:\n\n${validation.errors.map(q => `• ${q}`).join('\n')}`);
      return;
    }

    setIsSaving(true);
    try {
      await onSave(answers);
      onClose();
    } catch (error) {
      console.error('Failed to save answers:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const validateForm = (): { valid: boolean; errors: string[] } => {
    const errors: string[] = [];
    
    questions.forEach((question) => {
      if (question.is_required) {
        const answer = answers[question.id];
        if (!answer || answer.trim() === '') {
          errors.push(question.question_text);
        }
      }
    });
    
    return { valid: errors.length === 0, errors };
  };

  const handleSingleChoiceChange = (questionId: number, value: string) => {
    setAnswers({ ...answers, [questionId]: value });
  };

  const handleMultipleChoiceChange = (questionId: number, choiceText: string, checked: boolean) => {
    const currentAnswers = answers[questionId] ? answers[questionId].split(',').filter(a => a.trim()) : [];
    let newAnswers: string[];
    
    if (checked) {
      newAnswers = [...currentAnswers, choiceText];
    } else {
      newAnswers = currentAnswers.filter(a => a !== choiceText);
    }
    
    setAnswers({ ...answers, [questionId]: newAnswers.join(',') });
  };

  const isChoiceSelected = (questionId: number, choiceText: string) => {
    const currentAnswers = answers[questionId] ? answers[questionId].split(',').filter(a => a.trim()) : [];
    return currentAnswers.includes(choiceText);
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="sticky top-0 bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-5 rounded-t-2xl flex items-center justify-between flex-shrink-0">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center">
              <FileText className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-white">Report Questions</h2>
              <p className="text-purple-100 text-sm">Answer the questions below</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-20">
              <div className="animate-spin">
                <FileText className="w-10 h-10 text-indigo-600" />
              </div>
            </div>
          ) : questions.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No questions in this form</p>
            </div>
          ) : (
            <div className="space-y-6">
              {questions.map((question) => {
                const choices = questionChoices[question.id] || [];
                
                return (
                  <div key={question.id}>
                    <label className="block text-sm font-semibold text-gray-900 mb-3">
                      {question.question_text}
                      {question.is_required && (
                        <span className="text-red-500 ml-1" title="This question is required">*</span>
                      )}
                    </label>
                    
                    {question.question_type === 'text' && (
                      <textarea
                        value={answers[question.id] || ''}
                        onChange={(e) => setAnswers({ ...answers, [question.id]: e.target.value })}
                        rows={3}
                        className={`w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all ${
                          question.is_required && (!answers[question.id] || answers[question.id].trim() === '')
                            ? 'border-red-300 bg-red-50/30'
                            : 'border-gray-300'
                        }`}
                        placeholder={question.is_required ? "This field is required..." : "Type your answer..."}
                      />
                    )}
                    
                    {question.question_type === 'single_choice' && (
                      <div className="space-y-2">
                        {choices.map((choice) => (
                          <label key={choice.id} className="flex items-center space-x-3 p-4 border-2 border-gray-200 rounded-xl hover:bg-purple-50 hover:border-purple-300 cursor-pointer transition-all">
                            <input
                              type="radio"
                              name={`question_${question.id}`}
                              value={choice.choice_text}
                              checked={answers[question.id] === choice.choice_text}
                              onChange={(e) => handleSingleChoiceChange(question.id, e.target.value)}
                              className="text-purple-600 focus:ring-purple-500 w-5 h-5"
                            />
                            <span className="text-gray-700 font-medium">{choice.choice_text}</span>
                          </label>
                        ))}
                      </div>
                    )}
                    
                    {question.question_type === 'multiple_choice' && (
                      <div className="space-y-2">
                        {choices.map((choice) => (
                          <label key={choice.id} className="flex items-center space-x-3 p-4 border-2 border-gray-200 rounded-xl hover:bg-purple-50 hover:border-purple-300 cursor-pointer transition-all">
                            <input
                              type="checkbox"
                              checked={isChoiceSelected(question.id, choice.choice_text)}
                              onChange={(e) => handleMultipleChoiceChange(question.id, choice.choice_text, e.target.checked)}
                              className="rounded text-purple-600 focus:ring-purple-500 w-5 h-5"
                            />
                            <span className="text-gray-700 font-medium">{choice.choice_text}</span>
                          </label>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-white border-t border-gray-200 px-6 py-4 rounded-b-2xl flex-shrink-0">
          <div className="flex space-x-3">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 font-semibold rounded-xl hover:bg-gray-50 transition-all"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving}
              className="flex-1 flex items-center justify-center space-x-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl hover:shadow-xl hover:shadow-purple-500/30 transition-all disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              <span>{isSaving ? 'Saving...' : 'Save Answers'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
