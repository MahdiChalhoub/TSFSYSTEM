import { Hono } from "hono";
import { getCookie, setCookie } from "hono/cookie";
import {
  exchangeCodeForSessionToken,
  getOAuthRedirectUrl,
  authMiddleware,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import {
  CreateTaskSchema,
  UpdateTaskSchema,
  CreateTimeEntrySchema,
  UpdateTimeEntrySchema,
  CreateTaskCategorySchema,
  UpdateTaskCategorySchema,
} from "@/shared/types";
import {
  CreateOrganizationSchema,
  CreateInvitationSchema,
  CreateMessageSchema,
} from "@/shared/organization-types";
import OpenAI from "openai";

const app = new Hono<{ Bindings: Env }>();

// Auth routes
app.get("/api/oauth/google/redirect_url", async (c) => {
  const redirectUrl = await getOAuthRedirectUrl("google", {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  return c.json({ redirectUrl }, 200);
});

app.post("/api/sessions", async (c) => {
  const body = await c.req.json();

  if (!body.code) {
    return c.json({ error: "No authorization code provided" }, 400);
  }

  const sessionToken = await exchangeCodeForSessionToken(body.code, {
    apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
    apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
  });

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 60 * 24 * 60 * 60, // 60 days
  });

  return c.json({ success: true }, 200);
});

app.get("/api/users/me", authMiddleware, async (c) => {
  return c.json(c.get("user"));
});

app.get("/api/logout", async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === "string") {
    await deleteSession(sessionToken, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, "", {
    httpOnly: true,
    path: "/",
    sameSite: "none",
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Helper function to generate random token
function generateToken(): string {
  return Math.random().toString(36).substring(2) + Math.random().toString(36).substring(2);
}

// Helper function to generate join code
function generateJoinCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    if (i === 4) code += '-';
    code += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return code;
}

// Helper to get user's organization
async function getUserOrganization(db: D1Database, userId: string) {
  return await db.prepare(
    `SELECT o.* FROM organizations o
     JOIN organization_members om ON o.id = om.organization_id
     WHERE om.user_id = ?
     LIMIT 1`
  ).bind(userId).first();
}

// AI Summary endpoint
app.post("/api/reports/ai-summary", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const date = body.date || new Date().toISOString().split('T')[0];

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  try {
    // Fetch report data
    const [manual, day, taskTime, completedTasks] = await Promise.all([
      c.env.DB.prepare(
        `SELECT te.*, t.title as task_title
         FROM time_entries te 
         JOIN tasks t ON te.task_id = t.id 
         WHERE te.user_id = ? AND te.organization_id = ? AND te.entry_date = ? AND te.status = 'approved'
         ORDER BY te.created_at DESC`
      ).bind(user.id, org.id, date).all(),
      c.env.DB.prepare(
        `SELECT * FROM day_time_entries 
         WHERE user_id = ? AND organization_id = ? AND date(clock_in_time) = ? AND status = 'approved'
         ORDER BY clock_in_time DESC`
      ).bind(user.id, org.id, date).all(),
      c.env.DB.prepare(
        `SELECT tte.*, t.title as task_title
         FROM task_time_entries tte
         JOIN tasks t ON tte.task_id = t.id 
         WHERE tte.user_id = ? AND tte.organization_id = ? AND date(tte.start_time) = ? AND tte.status = 'approved'
         ORDER BY tte.start_time DESC`
      ).bind(user.id, org.id, date).all(),
      c.env.DB.prepare(
        `SELECT t.*, tc.name as category_name
         FROM tasks t
         LEFT JOIN task_categories tc ON t.category_id = tc.id
         WHERE t.assigned_to_user_id = ? AND t.organization_id = ? AND t.status = 'completed' AND date(t.updated_at) = ?
         ORDER BY t.updated_at DESC`
      ).bind(user.id, org.id, date).all()
    ]);

    // Get submission and answers if exists
    const submission = await c.env.DB.prepare(
      "SELECT * FROM report_submissions WHERE user_id = ? AND organization_id = ? AND report_date = ?"
    ).bind(user.id, org.id, date).first();

    let answers: any[] = [];
    let additionalTasks: any[] = [];
    if (submission) {
      const answersRes = await c.env.DB.prepare(
        `SELECT ra.*, rfq.question_text 
         FROM report_answers ra
         JOIN report_form_questions rfq ON ra.question_id = rfq.id
         WHERE ra.submission_id = ?`
      ).bind(submission.id).all();
      answers = answersRes.results;

      const tasksRes = await c.env.DB.prepare(
        "SELECT * FROM report_additional_tasks WHERE submission_id = ?"
      ).bind(submission.id).all();
      additionalTasks = tasksRes.results;
    }

    const manualHours = manual.results.reduce((sum: number, entry: any) => sum + (entry.hours || 0), 0);
    const dayHours = day.results.reduce((sum: number, entry: any) => sum + (entry.total_hours || 0), 0);
    const taskHours = taskTime.results.reduce((sum: number, entry: any) => sum + (entry.duration_hours || 0), 0);
    const totalHours = manualHours + dayHours + taskHours;

    // Build prompt for OpenAI
    const prompt = `Generate a professional and insightful summary of this employee's daily work report for ${date}.

Work Data:
- Total Hours Worked: ${totalHours.toFixed(2)} hours
- Tasks Completed: ${completedTasks.results.length}

Completed Tasks:
${completedTasks.results.map((t: any) => `- ${t.title} (${t.category_name || 'Uncategorized'})`).join('\n') || 'None'}

Time Entries:
${manual.results.map((e: any) => `- ${e.task_title}: ${e.hours}h ${e.description ? `- ${e.description}` : ''}`).join('\n') || ''}
${taskTime.results.map((e: any) => `- ${e.task_title}: ${e.duration_hours?.toFixed(2)}h ${e.description ? `- ${e.description}` : ''}`).join('\n') || ''}

${additionalTasks.length > 0 ? `Additional Tasks (not in system):
${additionalTasks.map((t: any) => `- ${t.task_description}: ${t.hours_spent}h`).join('\n')}` : ''}

${answers.length > 0 ? `Report Responses:
${answers.map((a: any) => `Q: ${a.question_text}\nA: ${a.answer_text}`).join('\n\n')}` : ''}

Please provide:
1. A brief executive summary (2-3 sentences)
2. Key accomplishments and highlights
3. Productivity insights or patterns
4. Any notable observations

Keep the tone professional, positive, and constructive. Focus on tangible achievements and time utilization.`;

    if (!c.env.OPENAI_API_KEY) {
      return c.json({ 
        error: "OpenAI API key not configured. Please add your OPENAI_API_KEY in the app secrets." 
      }, 500);
    }

    const openai = new OpenAI({
      apiKey: c.env.OPENAI_API_KEY,
    });

    const response = await openai.responses.create({
      model: "gpt-5-mini",
      input: [
        {
          role: "user",
          content: prompt
        }
      ]
    });

    const summary = response.output_text;

    return c.json({ summary });
  } catch (error: any) {
    console.error('AI Summary Error:', error);
    return c.json({ 
      error: error.message || "Failed to generate AI summary" 
    }, 500);
  }
});

// Organization routes
app.get("/api/organizations/current", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);
  
  if (!org) {
    return c.json(null);
  }
  
  return c.json(org);
});

app.post("/api/organizations", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  
  const parsed = CreateOrganizationSchema.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "Invalid input", details: parsed.error }, 400);
  }

  // Check if user already belongs to an organization
  const existingOrg = await getUserOrganization(c.env.DB, user.id);
  if (existingOrg) {
    return c.json({ error: "User already belongs to an organization" }, 400);
  }

  const now = new Date().toISOString();
  const joinCode = generateJoinCode();
  
  const result = await c.env.DB.prepare(
    `INSERT INTO organizations (name, created_by_user_id, join_code, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?)`
  ).bind(parsed.data.name, user.id, joinCode, now, now).run();

  const orgId = result.meta.last_row_id;

  await c.env.DB.prepare(
    `INSERT INTO organization_members (organization_id, user_id, role, name, email, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).bind(orgId, user.id, 'owner', user.google_user_data?.name || user.email, user.email, now, now).run();

  const org = await c.env.DB.prepare("SELECT * FROM organizations WHERE id = ?")
    .bind(orgId).first();

  return c.json(org, 201);
});

app.get("/api/organizations/:id/members", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const orgId = c.req.param("id");

  // Verify user is member of this org
  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE organization_id = ? AND user_id = ?"
  ).bind(orgId, user.id).first();

  if (!membership) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE organization_id = ?"
  ).bind(orgId).all();

  return c.json(results);
});

app.patch("/api/organization-members/:id/role", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const memberId = c.req.param("id");
  const body = await c.req.json();

  if (!body.role || !['owner', 'admin', 'leader', 'member'].includes(body.role)) {
    return c.json({ error: "Invalid role" }, 400);
  }

  // Get the member being updated
  const targetMember = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE id = ?"
  ).bind(memberId).first();

  if (!targetMember) {
    return c.json({ error: "Member not found" }, 404);
  }

  // Check if current user is owner of the organization
  const userMembership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE organization_id = ? AND user_id = ?"
  ).bind(targetMember.organization_id, user.id).first();

  if (!userMembership || userMembership.role !== 'owner') {
    return c.json({ error: "Only owners can change roles" }, 403);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    "UPDATE organization_members SET role = ?, updated_at = ? WHERE id = ?"
  ).bind(body.role, now, memberId).run();

  const updated = await c.env.DB.prepare("SELECT * FROM organization_members WHERE id = ?")
    .bind(memberId).first();

  return c.json(updated);
});

// Invitation routes
app.get("/api/invitations", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM invitations WHERE organization_id = ? ORDER BY created_at DESC"
  ).bind(org.id).all();

  return c.json(results);
});

app.post("/api/invitations", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();

  const parsed = CreateInvitationSchema.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "Invalid input", details: parsed.error }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  // Check if invitation already exists for this email
  const existing = await c.env.DB.prepare(
    "SELECT * FROM invitations WHERE organization_id = ? AND email = ? AND status = 'pending'"
  ).bind(org.id, parsed.data.email).first();

  if (existing) {
    return c.json({ error: "Invitation already sent to this email" }, 400);
  }

  const now = new Date().toISOString();
  const token = generateToken();

  const result = await c.env.DB.prepare(
    `INSERT INTO invitations (organization_id, email, invited_by_user_id, token, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).bind(org.id, parsed.data.email, user.id, token, 'pending', now, now).run();

  const invitation = await c.env.DB.prepare("SELECT * FROM invitations WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(invitation, 201);
});

app.get("/api/organizations/join-code", authMiddleware, async (c) => {
  const user = c.get("user")!;
  let org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 404);
  }

  // If organization doesn't have a join code, generate one
  if (!org.join_code) {
    const joinCode = generateJoinCode();
    const now = new Date().toISOString();
    const orgId = org.id;
    
    await c.env.DB.prepare(
      "UPDATE organizations SET join_code = ?, updated_at = ? WHERE id = ?"
    ).bind(joinCode, now, orgId).run();
    
    // Refresh organization data
    const updatedOrg = await c.env.DB.prepare("SELECT * FROM organizations WHERE id = ?")
      .bind(orgId).first();
    
    if (updatedOrg) {
      org = updatedOrg;
    }
  }

  return c.json({ join_code: org.join_code });
});

app.post("/api/organizations/join", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();

  if (!body.join_code) {
    return c.json({ error: "Join code is required" }, 400);
  }

  // Check if user already in an org
  const existingOrg = await getUserOrganization(c.env.DB, user.id);
  if (existingOrg) {
    return c.json({ error: "User already belongs to an organization" }, 400);
  }

  // Find organization by join code
  const org = await c.env.DB.prepare(
    "SELECT * FROM organizations WHERE join_code = ?"
  ).bind(body.join_code).first();

  if (!org) {
    return c.json({ error: "Invalid join code" }, 404);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    `INSERT INTO organization_members (organization_id, user_id, role, name, email, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).bind(org.id, user.id, 'member', user.google_user_data?.name || user.email, user.email, now, now).run();

  return c.json({ success: true });
});

app.post("/api/invitations/:token/accept", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const token = c.req.param("token");

  const invitation = await c.env.DB.prepare(
    "SELECT * FROM invitations WHERE token = ? AND email = ? AND status = 'pending'"
  ).bind(token, user.email).first();

  if (!invitation) {
    return c.json({ error: "Invalid or expired invitation" }, 404);
  }

  // Check if user already in an org
  const existingOrg = await getUserOrganization(c.env.DB, user.id);
  if (existingOrg) {
    return c.json({ error: "User already belongs to an organization" }, 400);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    `INSERT INTO organization_members (organization_id, user_id, role, name, email, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).bind(invitation.organization_id, user.id, 'member', user.google_user_data?.name || user.email, user.email, now, now).run();

  await c.env.DB.prepare(
    "UPDATE invitations SET status = ?, updated_at = ? WHERE id = ?"
  ).bind('accepted', now, invitation.id).run();

  return c.json({ success: true });
});

// Message routes
app.get("/api/messages", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM messages WHERE organization_id = ? ORDER BY created_at ASC"
  ).bind(org.id).all();

  return c.json(results);
});

app.post("/api/messages", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();

  const parsed = CreateMessageSchema.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "Invalid input", details: parsed.error }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  const now = new Date().toISOString();

  const result = await c.env.DB.prepare(
    `INSERT INTO messages (organization_id, user_id, content, is_system_message, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).bind(org.id, user.id, parsed.data.content, 0, now, now).run();

  const message = await c.env.DB.prepare("SELECT * FROM messages WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(message, 201);
});

// Task category routes
app.get("/api/task-categories", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM task_categories WHERE organization_id = ? ORDER BY sort_order ASC, name ASC"
  ).bind(org.id).all();

  return c.json(results);
});

app.post("/api/task-categories", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();

  const parsed = CreateTaskCategorySchema.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "Invalid input", details: parsed.error }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  const data = parsed.data;
  const now = new Date().toISOString();

  // Get max sort_order
  const maxOrder = await c.env.DB.prepare(
    "SELECT MAX(sort_order) as max_order FROM task_categories WHERE organization_id = ?"
  ).bind(org.id).first();

  const sortOrder = ((maxOrder?.max_order as number) || 0) + 1;

  const result = await c.env.DB.prepare(
    `INSERT INTO task_categories (name, organization_id, leader_user_id, sort_order, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).bind(
    data.name,
    org.id,
    data.leader_user_id || null,
    sortOrder,
    now,
    now
  ).run();

  const category = await c.env.DB.prepare("SELECT * FROM task_categories WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(category, 201);
});

app.patch("/api/task-categories/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();

  const parsed = UpdateTaskCategorySchema.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "Invalid input", details: parsed.error }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const category = await c.env.DB.prepare(
    "SELECT * FROM task_categories WHERE id = ? AND organization_id = ?"
  ).bind(id, org.id).first();

  if (!category) {
    return c.json({ error: "Category not found" }, 404);
  }

  const data = parsed.data;
  const updates: string[] = [];
  const values: any[] = [];

  if (data.name !== undefined) {
    updates.push("name = ?");
    values.push(data.name);
  }
  if (data.leader_user_id !== undefined) {
    updates.push("leader_user_id = ?");
    values.push(data.leader_user_id || null);
  }

  if (updates.length === 0) {
    return c.json(category);
  }

  updates.push("updated_at = ?");
  values.push(new Date().toISOString());
  values.push(id);

  await c.env.DB.prepare(
    `UPDATE task_categories SET ${updates.join(", ")} WHERE id = ?`
  ).bind(...values).run();

  const updated = await c.env.DB.prepare("SELECT * FROM task_categories WHERE id = ?")
    .bind(id).first();

  return c.json(updated);
});

app.delete("/api/task-categories/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const category = await c.env.DB.prepare(
    "SELECT * FROM task_categories WHERE id = ? AND organization_id = ?"
  ).bind(id, org.id).first();

  if (!category) {
    return c.json({ error: "Category not found" }, 404);
  }

  // Remove category from all tasks
  await c.env.DB.prepare("UPDATE tasks SET category_id = NULL WHERE category_id = ?")
    .bind(id).run();

  await c.env.DB.prepare("DELETE FROM task_categories WHERE id = ?")
    .bind(id).run();

  return c.json({ success: true });
});

app.post("/api/task-categories/reorder", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  if (!Array.isArray(body.category_ids)) {
    return c.json({ error: "category_ids must be an array" }, 400);
  }

  // Update sort order for each category
  const now = new Date().toISOString();
  for (let i = 0; i < body.category_ids.length; i++) {
    await c.env.DB.prepare(
      "UPDATE task_categories SET sort_order = ?, updated_at = ? WHERE id = ? AND organization_id = ?"
    ).bind(i, now, body.category_ids[i], org.id).run();
  }

  return c.json({ success: true });
});

// Task routes
app.get("/api/tasks", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);
  
  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM tasks WHERE organization_id = ? ORDER BY created_at DESC"
  )
    .bind(org.id)
    .all();

  return c.json(results);
});

app.post("/api/tasks", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  
  const parsed = CreateTaskSchema.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "Invalid input", details: parsed.error }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  const data = parsed.data;
  const now = new Date().toISOString();

  const result = await c.env.DB.prepare(
    `INSERT INTO tasks (title, description, status, priority, due_date, created_by_user_id, assigned_to_user_id, category_id, organization_id, is_recurring, recurrence_days, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      data.title,
      data.description || null,
      data.status,
      data.priority,
      data.due_date || null,
      user.id,
      data.assigned_to_user_id || null,
      data.category_id || null,
      org.id,
      data.is_recurring ? 1 : 0,
      data.recurrence_days || null,
      now,
      now
    )
    .run();

  const task = await c.env.DB.prepare("SELECT * FROM tasks WHERE id = ?")
    .bind(result.meta.last_row_id)
    .first();

  return c.json(task, 201);
});

app.get("/api/tasks/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const task = await c.env.DB.prepare(
    "SELECT * FROM tasks WHERE id = ? AND organization_id = ?"
  )
    .bind(id, org.id)
    .first();

  if (!task) {
    return c.json({ error: "Task not found" }, 404);
  }

  return c.json(task);
});

app.patch("/api/tasks/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();

  const parsed = UpdateTaskSchema.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "Invalid input", details: parsed.error }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const task = await c.env.DB.prepare(
    "SELECT * FROM tasks WHERE id = ? AND organization_id = ?"
  )
    .bind(id, org.id)
    .first();

  if (!task) {
    return c.json({ error: "Task not found" }, 404);
  }

  const data = parsed.data;
  const updates: string[] = [];
  const values: any[] = [];
  
  // Track if status is changing to completed
  const wasCompleted = task.status === 'completed';
  const nowCompleted = data.status === 'completed';

  if (data.title !== undefined) {
    updates.push("title = ?");
    values.push(data.title);
  }
  if (data.description !== undefined) {
    updates.push("description = ?");
    values.push(data.description || null);
  }
  if (data.status !== undefined) {
    updates.push("status = ?");
    values.push(data.status);
  }
  if (data.priority !== undefined) {
    updates.push("priority = ?");
    values.push(data.priority);
  }
  if (data.due_date !== undefined) {
    updates.push("due_date = ?");
    values.push(data.due_date || null);
  }
  if (data.assigned_to_user_id !== undefined) {
    updates.push("assigned_to_user_id = ?");
    values.push(data.assigned_to_user_id || null);
  }
  if (data.category_id !== undefined) {
    updates.push("category_id = ?");
    values.push(data.category_id || null);
  }
  if (data.is_recurring !== undefined) {
    updates.push("is_recurring = ?");
    values.push(data.is_recurring ? 1 : 0);
  }
  if (data.recurrence_days !== undefined) {
    updates.push("recurrence_days = ?");
    values.push(data.recurrence_days || null);
  }

  if (updates.length === 0) {
    return c.json(task);
  }

  updates.push("updated_at = ?");
  values.push(new Date().toISOString());
  values.push(id);

  await c.env.DB.prepare(
    `UPDATE tasks SET ${updates.join(", ")} WHERE id = ?`
  )
    .bind(...values)
    .run();

  const updated = await c.env.DB.prepare("SELECT * FROM tasks WHERE id = ?")
    .bind(id)
    .first();

  // Handle recurring task creation when task is completed
  if (!wasCompleted && nowCompleted && task.is_recurring && task.recurrence_days) {
    const currentDueDate = task.due_date ? new Date(task.due_date as string) : new Date();
    const nextDueDate = new Date(currentDueDate.getTime() + (task.recurrence_days as number) * 24 * 60 * 60 * 1000);
    
    await c.env.DB.prepare(
      `INSERT INTO tasks (title, description, status, priority, due_date, created_by_user_id, assigned_to_user_id, category_id, organization_id, is_recurring, recurrence_days, parent_recurring_task_id, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      task.title,
      task.description,
      'pending',
      task.priority,
      nextDueDate.toISOString().split('T')[0],
      task.created_by_user_id,
      task.assigned_to_user_id,
      task.category_id,
      task.organization_id,
      1,
      task.recurrence_days,
      task.id,
      new Date().toISOString(),
      new Date().toISOString()
    ).run();
  }

  // Smart linking: If task just became completed and has an assigned user, check if they need a time entry prompt
  if (!wasCompleted && nowCompleted && task.assigned_to_user_id) {
    // Check if there are any time entries for this task
    const existingEntries = await c.env.DB.prepare(
      `SELECT COUNT(*) as count FROM (
        SELECT id FROM time_entries WHERE task_id = ? 
        UNION ALL 
        SELECT id FROM task_time_entries WHERE task_id = ?
      )`
    ).bind(id, id).first();

    // Store completion without time entry for tracking
    if (!existingEntries || existingEntries.count === 0) {
      await c.env.DB.prepare(
        `INSERT INTO messages (organization_id, user_id, content, is_system_message, created_at, updated_at)
         VALUES (?, ?, ?, 1, ?, ?)`
      ).bind(
        org.id,
        'system',
        `Task "${task.title}" was completed by ${task.assigned_to_user_id} but no time was tracked.`,
        new Date().toISOString(),
        new Date().toISOString()
      ).run();
    }
  }

  return c.json(updated);
});

app.delete("/api/tasks/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const task = await c.env.DB.prepare(
    "SELECT * FROM tasks WHERE id = ? AND organization_id = ?"
  )
    .bind(id, org.id)
    .first();

  if (!task) {
    return c.json({ error: "Task not found or unauthorized" }, 404);
  }

  await c.env.DB.prepare("DELETE FROM time_entries WHERE task_id = ?")
    .bind(id)
    .run();

  await c.env.DB.prepare("DELETE FROM tasks WHERE id = ?")
    .bind(id)
    .run();

  return c.json({ success: true });
});

// Time entry routes
app.get("/api/time-entries", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const startDate = c.req.query("start_date");
  const endDate = c.req.query("end_date");
  const taskId = c.req.query("task_id");

  let query = "SELECT * FROM time_entries WHERE organization_id = ?";
  const bindings: any[] = [org.id];

  if (startDate) {
    query += " AND entry_date >= ?";
    bindings.push(startDate);
  }
  if (endDate) {
    query += " AND entry_date <= ?";
    bindings.push(endDate);
  }
  if (taskId) {
    query += " AND task_id = ?";
    bindings.push(parseInt(taskId));
  }

  query += " ORDER BY entry_date DESC, created_at DESC";

  const { results } = await c.env.DB.prepare(query)
    .bind(...bindings)
    .all();

  return c.json(results);
});

app.post("/api/time-entries", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();

  const parsed = CreateTimeEntrySchema.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "Invalid input", details: parsed.error }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  const data = parsed.data;

  // Verify task exists in organization
  const task = await c.env.DB.prepare(
    "SELECT * FROM tasks WHERE id = ? AND organization_id = ?"
  )
    .bind(data.task_id, org.id)
    .first();

  if (!task) {
    return c.json({ error: "Task not found or unauthorized" }, 404);
  }

  const now = new Date().toISOString();

  const result = await c.env.DB.prepare(
    `INSERT INTO time_entries (task_id, user_id, description, hours, entry_date, organization_id, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  )
    .bind(
      data.task_id,
      user.id,
      data.description || null,
      data.hours,
      data.entry_date,
      org.id,
      now,
      now
    )
    .run();

  const entry = await c.env.DB.prepare("SELECT * FROM time_entries WHERE id = ?")
    .bind(result.meta.last_row_id)
    .first();

  return c.json(entry, 201);
});

app.patch("/api/time-entries/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();

  const parsed = UpdateTimeEntrySchema.safeParse(body);
  if (!parsed.success) {
    return c.json({ error: "Invalid input", details: parsed.error }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const entry = await c.env.DB.prepare(
    "SELECT * FROM time_entries WHERE id = ? AND organization_id = ?"
  )
    .bind(id, org.id)
    .first();

  if (!entry) {
    return c.json({ error: "Time entry not found" }, 404);
  }

  const data = parsed.data;
  const updates: string[] = [];
  const values: any[] = [];

  if (data.description !== undefined) {
    updates.push("description = ?");
    values.push(data.description || null);
  }
  if (data.hours !== undefined) {
    updates.push("hours = ?");
    values.push(data.hours);
  }
  if (data.entry_date !== undefined) {
    updates.push("entry_date = ?");
    values.push(data.entry_date);
  }

  if (updates.length === 0) {
    return c.json(entry);
  }

  updates.push("updated_at = ?");
  values.push(new Date().toISOString());
  values.push(id);

  await c.env.DB.prepare(
    `UPDATE time_entries SET ${updates.join(", ")} WHERE id = ?`
  )
    .bind(...values)
    .run();

  const updated = await c.env.DB.prepare("SELECT * FROM time_entries WHERE id = ?")
    .bind(id)
    .first();

  return c.json(updated);
});

app.delete("/api/time-entries/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const entry = await c.env.DB.prepare(
    "SELECT * FROM time_entries WHERE id = ? AND organization_id = ?"
  )
    .bind(id, org.id)
    .first();

  if (!entry) {
    return c.json({ error: "Time entry not found" }, 404);
  }

  await c.env.DB.prepare("DELETE FROM time_entries WHERE id = ?")
    .bind(id)
    .run();

  return c.json({ success: true });
});

// Day time entries (clock in/out)
app.get("/api/day-time-entries", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM day_time_entries WHERE organization_id = ? ORDER BY clock_in_time DESC"
  ).bind(org.id).all();

  return c.json(results);
});

app.post("/api/day-time-entries/clock-in", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  // Check if user already clocked in today
  const today = new Date().toISOString().split('T')[0];
  const existing = await c.env.DB.prepare(
    `SELECT * FROM day_time_entries 
     WHERE user_id = ? AND organization_id = ? 
     AND date(clock_in_time) = ? AND clock_out_time IS NULL`
  ).bind(user.id, org.id, today).first();

  if (existing) {
    return c.json({ error: "Already clocked in for today" }, 400);
  }

  const now = new Date().toISOString();

  const result = await c.env.DB.prepare(
    `INSERT INTO day_time_entries (user_id, organization_id, clock_in_time, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).bind(user.id, org.id, now, 'pending', now, now).run();

  const entry = await c.env.DB.prepare("SELECT * FROM day_time_entries WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(entry, 201);
});

app.post("/api/day-time-entries/:id/clock-out", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();

  const entry = await c.env.DB.prepare(
    "SELECT * FROM day_time_entries WHERE id = ? AND user_id = ?"
  ).bind(id, user.id).first();

  if (!entry) {
    return c.json({ error: "Entry not found" }, 404);
  }

  if (entry.clock_out_time) {
    return c.json({ error: "Already clocked out" }, 400);
  }

  const now = new Date().toISOString();
  const clockIn = new Date(entry.clock_in_time as string);
  const clockOut = new Date(now);
  const totalHours = (clockOut.getTime() - clockIn.getTime()) / (1000 * 60 * 60);

  await c.env.DB.prepare(
    `UPDATE day_time_entries 
     SET clock_out_time = ?, total_hours = ?, notes = ?, updated_at = ?
     WHERE id = ?`
  ).bind(now, totalHours, body.notes || null, now, id).run();

  const updated = await c.env.DB.prepare("SELECT * FROM day_time_entries WHERE id = ?")
    .bind(id).first();

  return c.json(updated);
});

// Task time entries (start/stop timer)
app.get("/api/task-time-entries", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM task_time_entries WHERE organization_id = ? ORDER BY start_time DESC"
  ).bind(org.id).all();

  return c.json(results);
});

app.post("/api/task-time-entries/start", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();

  if (!body.task_id) {
    return c.json({ error: "Task ID required" }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  // Check if user has an active daily timer
  const today = new Date().toISOString().split('T')[0];
  const activeDayTimer = await c.env.DB.prepare(
    `SELECT * FROM day_time_entries 
     WHERE user_id = ? AND organization_id = ? 
     AND date(clock_in_time) = ? AND clock_out_time IS NULL`
  ).bind(user.id, org.id, today).first();

  if (!activeDayTimer) {
    return c.json({ error: "You must clock in for the day before starting a task timer" }, 400);
  }

  // Verify task exists
  const task = await c.env.DB.prepare(
    "SELECT * FROM tasks WHERE id = ? AND organization_id = ?"
  ).bind(body.task_id, org.id).first();

  if (!task) {
    return c.json({ error: "Task not found" }, 404);
  }

  // Check if timer already running for this task
  const running = await c.env.DB.prepare(
    `SELECT * FROM task_time_entries 
     WHERE user_id = ? AND task_id = ? AND end_time IS NULL`
  ).bind(user.id, body.task_id).first();

  if (running) {
    return c.json({ error: "Timer already running for this task" }, 400);
  }

  const now = new Date().toISOString();

  const result = await c.env.DB.prepare(
    `INSERT INTO task_time_entries (task_id, user_id, organization_id, start_time, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).bind(body.task_id, user.id, org.id, now, 'pending', now, now).run();

  const entry = await c.env.DB.prepare("SELECT * FROM task_time_entries WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(entry, 201);
});

app.post("/api/task-time-entries/:id/stop", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();

  const entry = await c.env.DB.prepare(
    "SELECT * FROM task_time_entries WHERE id = ? AND user_id = ?"
  ).bind(id, user.id).first();

  if (!entry) {
    return c.json({ error: "Entry not found" }, 404);
  }

  if (entry.end_time) {
    return c.json({ error: "Timer already stopped" }, 400);
  }

  const now = new Date().toISOString();
  const startTime = new Date(entry.start_time as string);
  const endTime = new Date(now);
  const durationHours = (endTime.getTime() - startTime.getTime()) / (1000 * 60 * 60);

  await c.env.DB.prepare(
    `UPDATE task_time_entries 
     SET end_time = ?, duration_hours = ?, description = ?, updated_at = ?
     WHERE id = ?`
  ).bind(now, durationHours, body.description || null, now, id).run();

  const updated = await c.env.DB.prepare("SELECT * FROM task_time_entries WHERE id = ?")
    .bind(id).first();

  return c.json(updated);
});

// Approval routes
app.get("/api/approvals/pending", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ manualEntries: [], dayEntries: [], taskEntries: [] });
  }

  // Check if user is owner or admin
  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).first();

  if (!membership || (membership.role !== 'owner' && membership.role !== 'admin')) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const [manual, day, taskTime] = await Promise.all([
    c.env.DB.prepare(
      `SELECT te.*, t.title as task_title, om.name as user_name 
       FROM time_entries te 
       JOIN tasks t ON te.task_id = t.id
       LEFT JOIN organization_members om ON te.user_id = om.user_id AND te.organization_id = om.organization_id
       WHERE te.organization_id = ? AND te.status = 'pending'
       ORDER BY te.created_at DESC`
    ).bind(org.id).all(),
    c.env.DB.prepare(
      `SELECT dte.*, om.name as user_name 
       FROM day_time_entries dte
       LEFT JOIN organization_members om ON dte.user_id = om.user_id AND dte.organization_id = om.organization_id
       WHERE dte.organization_id = ? AND dte.status = 'pending'
       ORDER BY dte.clock_in_time DESC`
    ).bind(org.id).all(),
    c.env.DB.prepare(
      `SELECT tte.*, t.title as task_title, om.name as user_name 
       FROM task_time_entries tte
       JOIN tasks t ON tte.task_id = t.id
       LEFT JOIN organization_members om ON tte.user_id = om.user_id AND tte.organization_id = om.organization_id
       WHERE tte.organization_id = ? AND tte.status = 'pending'
       ORDER BY tte.start_time DESC`
    ).bind(org.id).all()
  ]);

  return c.json({
    manualEntries: manual.results,
    dayEntries: day.results,
    taskEntries: taskTime.results
  });
});

app.post("/api/time-entries/:id/approve", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).first();

  if (!membership || (membership.role !== 'owner' && membership.role !== 'admin')) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    "UPDATE time_entries SET status = ?, approved_by_user_id = ?, approved_at = ?, updated_at = ? WHERE id = ?"
  ).bind('approved', user.id, now, now, id).run();

  return c.json({ success: true });
});

app.post("/api/time-entries/:id/reject", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).first();

  if (!membership || (membership.role !== 'owner' && membership.role !== 'admin')) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    "UPDATE time_entries SET status = ?, approved_by_user_id = ?, approved_at = ?, updated_at = ? WHERE id = ?"
  ).bind('rejected', user.id, now, now, id).run();

  return c.json({ success: true });
});

app.post("/api/day-time-entries/:id/approve", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).first();

  if (!membership || (membership.role !== 'owner' && membership.role !== 'admin')) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    "UPDATE day_time_entries SET status = ?, approved_by_user_id = ?, approved_at = ?, updated_at = ? WHERE id = ?"
  ).bind('approved', user.id, now, now, id).run();

  return c.json({ success: true });
});

app.post("/api/day-time-entries/:id/reject", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).first();

  if (!membership || (membership.role !== 'owner' && membership.role !== 'admin')) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    "UPDATE day_time_entries SET status = ?, approved_by_user_id = ?, approved_at = ?, updated_at = ? WHERE id = ?"
  ).bind('rejected', user.id, now, now, id).run();

  return c.json({ success: true });
});

app.post("/api/task-time-entries/:id/approve", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).first();

  if (!membership || (membership.role !== 'owner' && membership.role !== 'admin')) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    "UPDATE task_time_entries SET status = ?, approved_by_user_id = ?, approved_at = ?, updated_at = ? WHERE id = ?"
  ).bind('approved', user.id, now, now, id).run();

  return c.json({ success: true });
});

app.post("/api/task-time-entries/:id/reject", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).first();

  if (!membership || (membership.role !== 'owner' && membership.role !== 'admin')) {
    return c.json({ error: "Unauthorized" }, 403);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    "UPDATE task_time_entries SET status = ?, approved_by_user_id = ?, approved_at = ?, updated_at = ? WHERE id = ?"
  ).bind('rejected', user.id, now, now, id).run();

  return c.json({ success: true });
});

// Role Permissions routes
app.get("/api/role-permissions", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM role_permissions WHERE organization_id = ?"
  ).bind(org.id).all();

  return c.json(results);
});

app.post("/api/role-permissions", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();

  if (!body.role || !body.permission_key) {
    return c.json({ error: "Role and permission_key required" }, 400);
  }

  const org = await getUserOrganization(c.env.DB, user.id);
  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  // Check if user is owner
  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).first();

  if (!membership || membership.role !== 'owner') {
    return c.json({ error: "Only owners can manage permissions" }, 403);
  }

  // Cannot edit owner permissions
  if (body.role === 'owner') {
    return c.json({ error: "Cannot edit owner permissions" }, 400);
  }

  const now = new Date().toISOString();

  // Check if permission already exists
  const existing = await c.env.DB.prepare(
    "SELECT * FROM role_permissions WHERE organization_id = ? AND role = ? AND permission_key = ?"
  ).bind(org.id, body.role, body.permission_key).first();

  if (existing) {
    // Update existing permission
    await c.env.DB.prepare(
      "UPDATE role_permissions SET is_enabled = ?, updated_at = ? WHERE id = ?"
    ).bind(body.is_enabled ? 1 : 0, now, existing.id).run();

    const updated = await c.env.DB.prepare("SELECT * FROM role_permissions WHERE id = ?")
      .bind(existing.id).first();

    return c.json(updated);
  } else {
    // Create new permission
    const result = await c.env.DB.prepare(
      `INSERT INTO role_permissions (organization_id, role, permission_key, is_enabled, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)`
    ).bind(org.id, body.role, body.permission_key, body.is_enabled ? 1 : 0, now, now).run();

    const created = await c.env.DB.prepare("SELECT * FROM role_permissions WHERE id = ?")
      .bind(result.meta.last_row_id).first();

    return c.json(created, 201);
  }
});

// Reports
app.get("/api/reports/daily", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ 
      date: new Date().toISOString().split('T')[0], 
      manualEntries: [], 
      dayEntries: [],
      taskEntries: [],
      completedTasks: [],
      totalHours: 0 
    });
  }

  const date = c.req.query("date") || new Date().toISOString().split('T')[0];

  // Get user's role and categories they lead
  const membership = await c.env.DB.prepare(
    "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).first();

  const isAdminOrOwner = membership && (membership.role === 'owner' || membership.role === 'admin');

  // Get categories this user leads
  const { results: ledCategories } = await c.env.DB.prepare(
    "SELECT id FROM task_categories WHERE leader_user_id = ? AND organization_id = ?"
  ).bind(user.id, org.id).all();
  
  const categoryIds = ledCategories.map((c: any) => c.id);

  // Build the filter condition based on user role
  let userFilter = '';
  let taskFilter = '';
  if (!isAdminOrOwner) {
    // For non-admin/owner users, show entries where:
    // - They are the assigned user, OR
    // - The task is in a category they lead
    if (categoryIds.length > 0) {
      userFilter = `AND (te.user_id = '${user.id}' OR t.category_id IN (${categoryIds.join(',')}))`;
      taskFilter = `AND (t.assigned_to_user_id = '${user.id}' OR t.category_id IN (${categoryIds.join(',')}))`;
    } else {
      userFilter = `AND te.user_id = '${user.id}'`;
      taskFilter = `AND t.assigned_to_user_id = '${user.id}'`;
    }
  }

  const [manual, day, taskTime, completedTasks] = await Promise.all([
    c.env.DB.prepare(
      `SELECT te.*, t.title as task_title, t.category_id
       FROM time_entries te 
       JOIN tasks t ON te.task_id = t.id 
       WHERE te.organization_id = ? AND te.entry_date = ? AND te.status = 'approved' ${userFilter}
       ORDER BY te.created_at DESC`
    ).bind(org.id, date).all(),
    c.env.DB.prepare(
      `SELECT * FROM day_time_entries 
       WHERE organization_id = ? AND date(clock_in_time) = ? AND status = 'approved'
       ${!isAdminOrOwner ? `AND user_id = '${user.id}'` : ''}
       ORDER BY clock_in_time DESC`
    ).bind(org.id, date).all(),
    c.env.DB.prepare(
      `SELECT tte.*, t.title as task_title, t.category_id
       FROM task_time_entries tte
       JOIN tasks t ON tte.task_id = t.id 
       WHERE tte.organization_id = ? AND date(tte.start_time) = ? AND tte.status = 'approved'
       ${userFilter}
       ORDER BY tte.start_time DESC`
    ).bind(org.id, date).all(),
    c.env.DB.prepare(
      `SELECT t.*, om.name as assigned_to_name, tc.name as category_name,
       COALESCE(
         (SELECT SUM(hours) FROM time_entries WHERE task_id = t.id AND entry_date = ? AND status = 'approved'), 0
       ) + COALESCE(
         (SELECT SUM(duration_hours) FROM task_time_entries WHERE task_id = t.id AND date(start_time) = ? AND status = 'approved'), 0
       ) as total_hours
       FROM tasks t
       LEFT JOIN organization_members om ON t.assigned_to_user_id = om.user_id AND t.organization_id = om.organization_id
       LEFT JOIN task_categories tc ON t.category_id = tc.id
       WHERE t.organization_id = ? AND t.status = 'completed' AND date(t.updated_at) = ?
       ${taskFilter}
       ORDER BY t.updated_at DESC`
    ).bind(org.id, date, date, date).all()
  ]);

  const manualHours = manual.results.reduce((sum: number, entry: any) => sum + (entry.hours || 0), 0);
  const dayHours = day.results.reduce((sum: number, entry: any) => sum + (entry.total_hours || 0), 0);
  const taskHours = taskTime.results.reduce((sum: number, entry: any) => sum + (entry.duration_hours || 0), 0);

  return c.json({
    date,
    manualEntries: manual.results,
    dayEntries: day.results,
    taskEntries: taskTime.results,
    completedTasks: completedTasks.results,
    totalHours: manualHours + dayHours + taskHours,
  });
});

// Employee time tracking dashboard
app.get("/api/reports/employee-time", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const startDate = c.req.query("start_date") || new Date().toISOString().split('T')[0];
  const endDate = c.req.query("end_date") || new Date().toISOString().split('T')[0];

  // Get all time entries grouped by user
  const { results } = await c.env.DB.prepare(
    `SELECT 
      COALESCE(te.user_id, dte.user_id, tte.user_id) as user_id,
      om.name as user_name,
      COALESCE(SUM(CASE WHEN te.id IS NOT NULL THEN te.hours ELSE 0 END), 0) as total_manual_hours,
      COALESCE(SUM(CASE WHEN dte.id IS NOT NULL THEN dte.total_hours ELSE 0 END), 0) as total_day_hours,
      COALESCE(SUM(CASE WHEN tte.id IS NOT NULL THEN tte.duration_hours ELSE 0 END), 0) as total_task_hours,
      COUNT(DISTINCT te.id) + COUNT(DISTINCT dte.id) + COUNT(DISTINCT tte.id) as entries_count
    FROM organization_members om
    LEFT JOIN time_entries te ON te.user_id = om.user_id AND te.organization_id = om.organization_id 
      AND te.entry_date BETWEEN ? AND ? AND te.status = 'approved'
    LEFT JOIN day_time_entries dte ON dte.user_id = om.user_id AND dte.organization_id = om.organization_id
      AND date(dte.clock_in_time) BETWEEN ? AND ? AND dte.status = 'approved'
    LEFT JOIN task_time_entries tte ON tte.user_id = om.user_id AND tte.organization_id = om.organization_id
      AND date(tte.start_time) BETWEEN ? AND ? AND tte.status = 'approved'
    WHERE om.organization_id = ?
    GROUP BY om.user_id, om.name
    HAVING entries_count > 0
    ORDER BY om.name`
  ).bind(startDate, endDate, startDate, endDate, startDate, endDate, org.id).all();

  return c.json(results.map((r: any) => ({
    ...r,
    total_hours: (r.total_manual_hours || 0) + (r.total_day_hours || 0) + (r.total_task_hours || 0)
  })));
});

// Employee time details
app.get("/api/reports/employee-time-details", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const userId = c.req.query("user_id");
  const startDate = c.req.query("start_date") || new Date().toISOString().split('T')[0];
  const endDate = c.req.query("end_date") || new Date().toISOString().split('T')[0];

  if (!userId) {
    return c.json({ error: "user_id required" }, 400);
  }

  const [manual, day, taskTime] = await Promise.all([
    c.env.DB.prepare(
      `SELECT te.id, te.user_id, te.hours, te.entry_date as date, te.description, te.status,
        t.title as task_title, om.name as user_name
       FROM time_entries te
       JOIN tasks t ON te.task_id = t.id
       LEFT JOIN organization_members om ON te.user_id = om.user_id AND te.organization_id = om.organization_id
       WHERE te.user_id = ? AND te.organization_id = ? 
         AND te.entry_date BETWEEN ? AND ?
       ORDER BY te.entry_date DESC`
    ).bind(userId, org.id, startDate, endDate).all(),
    c.env.DB.prepare(
      `SELECT dte.id, dte.user_id, dte.total_hours as hours, date(dte.clock_in_time) as date,
        dte.notes as description, dte.status, om.name as user_name
       FROM day_time_entries dte
       LEFT JOIN organization_members om ON dte.user_id = om.user_id AND dte.organization_id = om.organization_id
       WHERE dte.user_id = ? AND dte.organization_id = ?
         AND date(dte.clock_in_time) BETWEEN ? AND ?
       ORDER BY dte.clock_in_time DESC`
    ).bind(userId, org.id, startDate, endDate).all(),
    c.env.DB.prepare(
      `SELECT tte.id, tte.user_id, tte.duration_hours as hours, date(tte.start_time) as date,
        tte.description, tte.status, t.title as task_title, om.name as user_name
       FROM task_time_entries tte
       JOIN tasks t ON tte.task_id = t.id
       LEFT JOIN organization_members om ON tte.user_id = om.user_id AND tte.organization_id = om.organization_id
       WHERE tte.user_id = ? AND tte.organization_id = ?
         AND date(tte.start_time) BETWEEN ? AND ?
       ORDER BY tte.start_time DESC`
    ).bind(userId, org.id, startDate, endDate).all()
  ]);

  const allEntries = [
    ...manual.results.map((e: any) => ({ ...e, type: 'manual' })),
    ...day.results.map((e: any) => ({ ...e, type: 'day' })),
    ...taskTime.results.map((e: any) => ({ ...e, type: 'task' }))
  ].sort((a, b) => b.date.localeCompare(a.date));

  return c.json(allEntries);
});

// Employee reports dashboard
app.get("/api/reports/employee-reports", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const date = c.req.query("date") || new Date().toISOString().split('T')[0];

  // Get task statistics per user
  const { results } = await c.env.DB.prepare(
    `SELECT 
      om.user_id,
      om.name as user_name,
      SUM(CASE WHEN t.status = 'completed' AND t.updated_at LIKE ? THEN 1 ELSE 0 END) as tasks_completed,
      SUM(CASE WHEN t.status = 'cancelled' AND t.updated_at LIKE ? THEN 1 ELSE 0 END) as tasks_failed,
      SUM(CASE WHEN t.status IN ('pending', 'in_progress') THEN 1 ELSE 0 END) as tasks_pending,
      COALESCE(
        (SELECT SUM(hours) FROM time_entries WHERE user_id = om.user_id AND entry_date = ? AND status = 'approved'),
        0
      ) +
      COALESCE(
        (SELECT SUM(total_hours) FROM day_time_entries WHERE user_id = om.user_id AND date(clock_in_time) = ? AND status = 'approved'),
        0
      ) +
      COALESCE(
        (SELECT SUM(duration_hours) FROM task_time_entries WHERE user_id = om.user_id AND date(start_time) = ? AND status = 'approved'),
        0
      ) as total_hours,
      EXISTS(SELECT 1 FROM report_submissions WHERE user_id = om.user_id AND report_date = ? AND status = 'submitted') as form_submitted,
      COALESCE(
        (SELECT COUNT(*) FROM report_additional_tasks rat 
         JOIN report_submissions rs ON rat.submission_id = rs.id 
         WHERE rs.user_id = om.user_id AND rs.report_date = ?),
        0
      ) as additional_tasks_count
    FROM organization_members om
    LEFT JOIN tasks t ON t.assigned_to_user_id = om.user_id AND t.organization_id = om.organization_id
    WHERE om.organization_id = ?
    GROUP BY om.user_id, om.name
    ORDER BY om.name`
  ).bind(
    `${date}%`, `${date}%`, 
    date, date, date, date, date, 
    org.id
  ).all();

  return c.json(results);
});

// Report Forms routes
app.get("/api/report-forms", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM report_forms WHERE organization_id = ? ORDER BY created_at DESC"
  ).bind(org.id).all();

  return c.json(results);
});

app.post("/api/report-forms", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  const now = new Date().toISOString();

  const result = await c.env.DB.prepare(
    `INSERT INTO report_forms (organization_id, title, description, is_active, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).bind(org.id, body.title, body.description || null, body.is_active ? 1 : 0, now, now).run();

  const form = await c.env.DB.prepare("SELECT * FROM report_forms WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(form, 201);
});

app.patch("/api/report-forms/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  // Verify form belongs to org
  const form = await c.env.DB.prepare(
    "SELECT * FROM report_forms WHERE id = ? AND organization_id = ?"
  ).bind(id, org.id).first();

  if (!form) {
    return c.json({ error: "Form not found" }, 404);
  }

  const updates: string[] = [];
  const values: any[] = [];

  if (body.title !== undefined) {
    updates.push("title = ?");
    values.push(body.title);
  }
  if (body.description !== undefined) {
    updates.push("description = ?");
    values.push(body.description || null);
  }
  if (body.is_active !== undefined) {
    updates.push("is_active = ?");
    values.push(body.is_active ? 1 : 0);
  }

  if (updates.length === 0) {
    return c.json(form);
  }

  updates.push("updated_at = ?");
  values.push(new Date().toISOString());
  values.push(id);

  await c.env.DB.prepare(
    `UPDATE report_forms SET ${updates.join(", ")} WHERE id = ?`
  ).bind(...values).run();

  const updated = await c.env.DB.prepare("SELECT * FROM report_forms WHERE id = ?")
    .bind(id).first();

  return c.json(updated);
});

app.delete("/api/report-forms/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const form = await c.env.DB.prepare(
    "SELECT * FROM report_forms WHERE id = ? AND organization_id = ?"
  ).bind(id, org.id).first();

  if (!form) {
    return c.json({ error: "Form not found" }, 404);
  }

  // Delete related data
  await c.env.DB.prepare("DELETE FROM report_form_assignments WHERE form_id = ?").bind(id).run();
  
  const { results: questions } = await c.env.DB.prepare(
    "SELECT id FROM report_form_questions WHERE form_id = ?"
  ).bind(id).all();
  
  for (const question of questions) {
    await c.env.DB.prepare("DELETE FROM report_form_question_choices WHERE question_id = ?")
      .bind((question as any).id).run();
  }
  
  await c.env.DB.prepare("DELETE FROM report_form_questions WHERE form_id = ?").bind(id).run();
  await c.env.DB.prepare("DELETE FROM report_forms WHERE id = ?").bind(id).run();

  return c.json({ success: true });
});

app.get("/api/report-forms/:id/questions", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const formId = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    `SELECT q.* FROM report_form_questions q
     JOIN report_forms f ON q.form_id = f.id
     WHERE f.id = ? AND f.organization_id = ?
     ORDER BY q.sort_order ASC, q.created_at ASC`
  ).bind(formId, org.id).all();

  return c.json(results);
});

app.post("/api/report-forms/:id/questions", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const formId = c.req.param("id");
  const body = await c.req.json();
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  // Verify form belongs to org
  const form = await c.env.DB.prepare(
    "SELECT * FROM report_forms WHERE id = ? AND organization_id = ?"
  ).bind(formId, org.id).first();

  if (!form) {
    return c.json({ error: "Form not found" }, 404);
  }

  const now = new Date().toISOString();

  // Get max sort order
  const maxOrder = await c.env.DB.prepare(
    "SELECT MAX(sort_order) as max_order FROM report_form_questions WHERE form_id = ?"
  ).bind(formId).first();

  const sortOrder = ((maxOrder?.max_order as number) || 0) + 1;

  const result = await c.env.DB.prepare(
    `INSERT INTO report_form_questions (form_id, question_text, question_type, is_required, sort_order, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`
  ).bind(
    formId,
    body.question_text,
    body.question_type || 'text',
    body.is_required ? 1 : 0,
    sortOrder,
    now,
    now
  ).run();

  const question = await c.env.DB.prepare("SELECT * FROM report_form_questions WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(question, 201);
});

app.patch("/api/report-forms/:formId/questions/:id", authMiddleware, async (c) => {
  const formId = c.req.param("formId");
  const id = c.req.param("id");
  const body = await c.req.json();

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    `UPDATE report_form_questions 
     SET question_text = ?, is_required = ?, updated_at = ?
     WHERE id = ? AND form_id = ?`
  ).bind(body.question_text, body.is_required ? 1 : 0, now, id, formId).run();

  const question = await c.env.DB.prepare("SELECT * FROM report_form_questions WHERE id = ?")
    .bind(id).first();

  return c.json(question);
});

app.delete("/api/report-forms/:formId/questions/:id", authMiddleware, async (c) => {
  const formId = c.req.param("formId");
  const id = c.req.param("id");

  // Delete associated choices first
  await c.env.DB.prepare("DELETE FROM report_form_question_choices WHERE question_id = ?")
    .bind(id).run();

  await c.env.DB.prepare("DELETE FROM report_form_questions WHERE id = ? AND form_id = ?")
    .bind(id, formId).run();

  return c.json({ success: true });
});

// Question choices routes
app.get("/api/questions/:id/choices", authMiddleware, async (c) => {
  const questionId = c.req.param("id");

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM report_form_question_choices WHERE question_id = ? ORDER BY sort_order ASC, created_at ASC"
  ).bind(questionId).all();

  return c.json(results);
});

app.post("/api/questions/:id/choices", authMiddleware, async (c) => {
  const questionId = c.req.param("id");
  const body = await c.req.json();

  if (!body.choice_text) {
    return c.json({ error: "choice_text required" }, 400);
  }

  const now = new Date().toISOString();

  // Get max sort order
  const maxOrder = await c.env.DB.prepare(
    "SELECT MAX(sort_order) as max_order FROM report_form_question_choices WHERE question_id = ?"
  ).bind(questionId).first();

  const sortOrder = ((maxOrder?.max_order as number) || 0) + 1;

  const result = await c.env.DB.prepare(
    `INSERT INTO report_form_question_choices (question_id, choice_text, sort_order, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?)`
  ).bind(questionId, body.choice_text, sortOrder, now, now).run();

  const choice = await c.env.DB.prepare("SELECT * FROM report_form_question_choices WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(choice, 201);
});

app.patch("/api/questions/:questionId/choices/:id", authMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();

  if (!body.choice_text) {
    return c.json({ error: "choice_text required" }, 400);
  }

  const now = new Date().toISOString();

  await c.env.DB.prepare(
    "UPDATE report_form_question_choices SET choice_text = ?, updated_at = ? WHERE id = ?"
  ).bind(body.choice_text, now, id).run();

  const choice = await c.env.DB.prepare("SELECT * FROM report_form_question_choices WHERE id = ?")
    .bind(id).first();

  return c.json(choice);
});

app.delete("/api/questions/:questionId/choices/:id", authMiddleware, async (c) => {
  const id = c.req.param("id");

  await c.env.DB.prepare("DELETE FROM report_form_question_choices WHERE id = ?")
    .bind(id).run();

  return c.json({ success: true });
});

// Check for unsubmitted reports
app.get("/api/my-pending-reports", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  // Get forms assigned to this user
  const { results: forms } = await c.env.DB.prepare(
    `SELECT DISTINCT rf.id
     FROM report_forms rf
     LEFT JOIN report_form_assignments rfa ON rf.id = rfa.form_id
     LEFT JOIN user_group_members ugm ON rfa.group_id = ugm.group_id
     WHERE rf.organization_id = ? AND rf.is_active = 1
       AND ((rfa.user_id = ? AND rfa.user_id != '') OR ugm.user_id = ?)
     LIMIT 1`
  ).bind(org.id, user.id, user.id).all();

  // If no forms assigned, no pending reports
  if (forms.length === 0) {
    return c.json([]);
  }

  // Check last 30 days for missing submissions
  const today = new Date().toISOString().split('T')[0];
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  const startDate = thirtyDaysAgo.toISOString().split('T')[0];

  // Find dates with activity but no submitted report using a more efficient query
  const { results: pendingDates } = await c.env.DB.prepare(
    `SELECT DISTINCT activity_date 
     FROM (
       SELECT DISTINCT date(clock_in_time) as activity_date
       FROM day_time_entries
       WHERE user_id = ? AND organization_id = ?
         AND date(clock_in_time) BETWEEN ? AND ?
         AND date(clock_in_time) < ?
       UNION
       SELECT DISTINCT date(start_time) as activity_date
       FROM task_time_entries
       WHERE user_id = ? AND organization_id = ?
         AND date(start_time) BETWEEN ? AND ?
         AND date(start_time) < ?
       UNION
       SELECT DISTINCT entry_date as activity_date
       FROM time_entries
       WHERE user_id = ? AND organization_id = ?
         AND entry_date BETWEEN ? AND ?
         AND entry_date < ?
     )
     WHERE activity_date NOT IN (
       SELECT report_date 
       FROM report_submissions 
       WHERE user_id = ? AND organization_id = ? 
         AND (status = 'submitted' OR is_holiday = 1)
         AND report_date BETWEEN ? AND ?
     )
     ORDER BY activity_date DESC`
  ).bind(
    user.id, org.id, startDate, today, today,
    user.id, org.id, startDate, today, today,
    user.id, org.id, startDate, today, today,
    user.id, org.id, startDate, today
  ).all();

  return c.json(pendingDates.map((d: any) => d.activity_date));
});

// My report submission
app.get("/api/my-report-submission", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const date = c.req.query("date") || new Date().toISOString().split('T')[0];
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json(null);
  }

  const submission = await c.env.DB.prepare(
    "SELECT * FROM report_submissions WHERE user_id = ? AND organization_id = ? AND report_date = ?"
  ).bind(user.id, org.id, date).first();

  return c.json(submission);
});

app.post("/api/my-report-submission", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  const now = new Date().toISOString();

  const result = await c.env.DB.prepare(
    `INSERT INTO report_submissions (organization_id, user_id, form_id, report_date, status, is_holiday, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  ).bind(org.id, user.id, body.form_id || null, body.report_date, body.status || 'draft', body.is_holiday ? 1 : 0, now, now).run();

  const submission = await c.env.DB.prepare("SELECT * FROM report_submissions WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(submission, 201);
});

app.get("/api/report-submissions/:id/answers", authMiddleware, async (c) => {
  const id = c.req.param("id");

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM report_answers WHERE submission_id = ?"
  ).bind(id).all();

  return c.json(results);
});

app.post("/api/report-submissions/:id/answers", authMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();

  // Delete existing answers
  await c.env.DB.prepare("DELETE FROM report_answers WHERE submission_id = ?").bind(id).run();

  const now = new Date().toISOString();

  // Insert new answers
  for (const answer of body.answers) {
    await c.env.DB.prepare(
      `INSERT INTO report_answers (submission_id, question_id, answer_text, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?)`
    ).bind(id, answer.question_id, answer.answer_text, now, now).run();
  }

  return c.json({ success: true });
});

app.get("/api/report-submissions/:id/additional-tasks", authMiddleware, async (c) => {
  const id = c.req.param("id");

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM report_additional_tasks WHERE submission_id = ?"
  ).bind(id).all();

  return c.json(results);
});

app.post("/api/report-submissions/:id/additional-tasks", authMiddleware, async (c) => {
  const id = c.req.param("id");
  const body = await c.req.json();

  // Delete existing tasks
  await c.env.DB.prepare("DELETE FROM report_additional_tasks WHERE submission_id = ?").bind(id).run();

  const now = new Date().toISOString();

  // Insert new tasks
  for (const task of body.tasks) {
    if (task.task_description && task.task_description.trim()) {
      await c.env.DB.prepare(
        `INSERT INTO report_additional_tasks (submission_id, task_description, hours_spent, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?)`
      ).bind(id, task.task_description, task.hours_spent || 0, now, now).run();
    }
  }

  return c.json({ success: true });
});

app.post("/api/report-submissions/:id/submit", authMiddleware, async (c) => {
  const id = c.req.param("id");
  const now = new Date().toISOString();

  await c.env.DB.prepare(
    "UPDATE report_submissions SET status = ?, submitted_at = ?, updated_at = ? WHERE id = ?"
  ).bind('submitted', now, now, id).run();

  return c.json({ success: true });
});

// Report form assignments
app.get("/api/report-forms/:id/assignments", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const formId = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  // Verify form belongs to org
  const form = await c.env.DB.prepare(
    "SELECT * FROM report_forms WHERE id = ? AND organization_id = ?"
  ).bind(formId, org.id).first();

  if (!form) {
    return c.json({ error: "Form not found" }, 404);
  }

  const { results } = await c.env.DB.prepare(
    `SELECT rfa.*, 
            om.name as user_name, 
            om.email as user_email,
            ug.name as group_name
     FROM report_form_assignments rfa
     LEFT JOIN organization_members om ON rfa.user_id = om.user_id AND om.organization_id = ? AND rfa.user_id != ''
     LEFT JOIN user_groups ug ON rfa.group_id = ug.id
     WHERE rfa.form_id = ?
     ORDER BY COALESCE(ug.name, om.name)`
  ).bind(org.id, formId).all();

  return c.json(results);
});

app.post("/api/report-forms/:id/assignments", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const formId = c.req.param("id");
  const body = await c.req.json();
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  if (!body.user_id && !body.group_id) {
    return c.json({ error: "user_id or group_id required" }, 400);
  }

  // Verify form belongs to org
  const form = await c.env.DB.prepare(
    "SELECT * FROM report_forms WHERE id = ? AND organization_id = ?"
  ).bind(formId, org.id).first();

  if (!form) {
    return c.json({ error: "Form not found" }, 404);
  }

  // Verify user or group exists
  if (body.user_id) {
    const userExists = await c.env.DB.prepare(
      "SELECT * FROM organization_members WHERE user_id = ? AND organization_id = ?"
    ).bind(body.user_id, org.id).first();

    if (!userExists) {
      console.log(`[Assignment Error] User ${body.user_id} not found in org ${org.id}`);
      return c.json({ error: "User not found in organization" }, 404);
    }

    const existing = await c.env.DB.prepare(
      "SELECT * FROM report_form_assignments WHERE form_id = ? AND user_id = ?"
    ).bind(formId, body.user_id).first();

    if (existing) {
      return c.json({ error: "User already assigned to this form" }, 400);
    }
  } else if (body.group_id) {
    const groupExists = await c.env.DB.prepare(
      "SELECT * FROM user_groups WHERE id = ? AND organization_id = ?"
    ).bind(body.group_id, org.id).first();

    if (!groupExists) {
      console.log(`[Assignment Error] Group ${body.group_id} not found in org ${org.id}`);
      return c.json({ error: "User group not found. It may have been deleted." }, 404);
    }

    const existing = await c.env.DB.prepare(
      "SELECT * FROM report_form_assignments WHERE form_id = ? AND group_id = ?"
    ).bind(formId, body.group_id).first();

    if (existing) {
      return c.json({ error: "Group already assigned to this form" }, 400);
    }
  }

  const now = new Date().toISOString();

  console.log(`[Assignment] Creating assignment for form ${formId}, user: ${body.user_id || 'none'}, group: ${body.group_id || 'none'}`);

  // Build the INSERT query based on what's being assigned
  let insertQuery: string;
  let bindings: any[];
  
  if (body.user_id) {
    // Assigning to a user
    insertQuery = `INSERT INTO report_form_assignments (form_id, user_id, created_at, updated_at)
                   VALUES (?, ?, ?, ?)`;
    bindings = [formId, body.user_id, now, now];
  } else {
    // Assigning to a group - use a placeholder user_id
    insertQuery = `INSERT INTO report_form_assignments (form_id, user_id, group_id, created_at, updated_at)
                   VALUES (?, '', ?, ?, ?)`;
    bindings = [formId, body.group_id, now, now];
  }

  const result = await c.env.DB.prepare(insertQuery).bind(...bindings).run();

  console.log(`[Assignment] Successfully created assignment with ID ${result.meta.last_row_id}`);

  const assignment = await c.env.DB.prepare(
    `SELECT rfa.*, 
            om.name as user_name, 
            om.email as user_email,
            ug.name as group_name
     FROM report_form_assignments rfa
     LEFT JOIN organization_members om ON rfa.user_id = om.user_id AND om.organization_id = ? AND rfa.user_id != ''
     LEFT JOIN user_groups ug ON rfa.group_id = ug.id
     WHERE rfa.id = ?`
  ).bind(org.id, result.meta.last_row_id).first();

  return c.json(assignment, 201);
});

app.delete("/api/report-forms/:formId/assignments/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const formId = c.req.param("formId");
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  // Verify form belongs to org
  const form = await c.env.DB.prepare(
    "SELECT * FROM report_forms WHERE id = ? AND organization_id = ?"
  ).bind(formId, org.id).first();

  if (!form) {
    return c.json({ error: "Form not found" }, 404);
  }

  await c.env.DB.prepare("DELETE FROM report_form_assignments WHERE id = ? AND form_id = ?")
    .bind(id, formId).run();

  return c.json({ success: true });
});

app.get("/api/my-assigned-forms", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  // Get forms assigned to this user directly or via groups
  const { results } = await c.env.DB.prepare(
    `SELECT DISTINCT rf.*
     FROM report_forms rf
     LEFT JOIN report_form_assignments rfa ON rf.id = rfa.form_id
     LEFT JOIN user_group_members ugm ON rfa.group_id = ugm.group_id
     WHERE rf.organization_id = ? AND rf.is_active = 1
       AND ((rfa.user_id = ? AND rfa.user_id != '') OR ugm.user_id = ?)
     ORDER BY rf.created_at DESC`
  ).bind(org.id, user.id, user.id).all();

  return c.json(results);
});

// User Groups routes
app.get("/api/user-groups", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  const { results } = await c.env.DB.prepare(
    "SELECT * FROM user_groups WHERE organization_id = ? ORDER BY name ASC"
  ).bind(org.id).all();

  return c.json(results);
});

app.post("/api/user-groups", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  if (!body.name) {
    return c.json({ error: "Group name required" }, 400);
  }

  const now = new Date().toISOString();

  const result = await c.env.DB.prepare(
    `INSERT INTO user_groups (organization_id, name, description, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?)`
  ).bind(org.id, body.name, body.description || null, now, now).run();

  const group = await c.env.DB.prepare("SELECT * FROM user_groups WHERE id = ?")
    .bind(result.meta.last_row_id).first();

  return c.json(group, 201);
});

app.patch("/api/user-groups/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const body = await c.req.json();
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const group = await c.env.DB.prepare(
    "SELECT * FROM user_groups WHERE id = ? AND organization_id = ?"
  ).bind(id, org.id).first();

  if (!group) {
    return c.json({ error: "Group not found" }, 404);
  }

  const updates: string[] = [];
  const values: any[] = [];

  if (body.name !== undefined) {
    updates.push("name = ?");
    values.push(body.name);
  }
  if (body.description !== undefined) {
    updates.push("description = ?");
    values.push(body.description || null);
  }

  if (updates.length === 0) {
    return c.json(group);
  }

  updates.push("updated_at = ?");
  values.push(new Date().toISOString());
  values.push(id);

  await c.env.DB.prepare(
    `UPDATE user_groups SET ${updates.join(", ")} WHERE id = ?`
  ).bind(...values).run();

  const updated = await c.env.DB.prepare("SELECT * FROM user_groups WHERE id = ?")
    .bind(id).first();

  return c.json(updated);
});

app.delete("/api/user-groups/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  const group = await c.env.DB.prepare(
    "SELECT * FROM user_groups WHERE id = ? AND organization_id = ?"
  ).bind(id, org.id).first();

  if (!group) {
    return c.json({ error: "Group not found" }, 404);
  }

  // Delete group members first
  await c.env.DB.prepare("DELETE FROM user_group_members WHERE group_id = ?")
    .bind(id).run();

  // Update form assignments to remove group reference
  await c.env.DB.prepare("UPDATE report_form_assignments SET group_id = NULL WHERE group_id = ?")
    .bind(id).run();

  // Delete the group
  await c.env.DB.prepare("DELETE FROM user_groups WHERE id = ?")
    .bind(id).run();

  return c.json({ success: true });
});

app.get("/api/user-groups/:id/members", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const groupId = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json([]);
  }

  // Verify group belongs to org
  const group = await c.env.DB.prepare(
    "SELECT * FROM user_groups WHERE id = ? AND organization_id = ?"
  ).bind(groupId, org.id).first();

  if (!group) {
    return c.json({ error: "Group not found" }, 404);
  }

  const { results } = await c.env.DB.prepare(
    `SELECT ugm.*, om.name as user_name, om.email as user_email
     FROM user_group_members ugm
     JOIN organization_members om ON ugm.user_id = om.user_id
     WHERE ugm.group_id = ?
     ORDER BY om.name`
  ).bind(groupId).all();

  return c.json(results);
});

app.post("/api/user-groups/:id/members", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const groupId = c.req.param("id");
  const body = await c.req.json();
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 400);
  }

  if (!body.user_id) {
    return c.json({ error: "user_id required" }, 400);
  }

  // Verify group belongs to org
  const group = await c.env.DB.prepare(
    "SELECT * FROM user_groups WHERE id = ? AND organization_id = ?"
  ).bind(groupId, org.id).first();

  if (!group) {
    return c.json({ error: "Group not found" }, 404);
  }

  // Check if member already exists
  const existing = await c.env.DB.prepare(
    "SELECT * FROM user_group_members WHERE group_id = ? AND user_id = ?"
  ).bind(groupId, body.user_id).first();

  if (existing) {
    return c.json({ error: "User already in this group" }, 400);
  }

  const now = new Date().toISOString();

  const result = await c.env.DB.prepare(
    `INSERT INTO user_group_members (group_id, user_id, created_at, updated_at)
     VALUES (?, ?, ?, ?)`
  ).bind(groupId, body.user_id, now, now).run();

  const member = await c.env.DB.prepare(
    `SELECT ugm.*, om.name as user_name, om.email as user_email
     FROM user_group_members ugm
     JOIN organization_members om ON ugm.user_id = om.user_id
     WHERE ugm.id = ?`
  ).bind(result.meta.last_row_id).first();

  return c.json(member, 201);
});

app.delete("/api/user-groups/:groupId/members/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const groupId = c.req.param("groupId");
  const id = c.req.param("id");
  const org = await getUserOrganization(c.env.DB, user.id);

  if (!org) {
    return c.json({ error: "User not in an organization" }, 403);
  }

  // Verify group belongs to org
  const group = await c.env.DB.prepare(
    "SELECT * FROM user_groups WHERE id = ? AND organization_id = ?"
  ).bind(groupId, org.id).first();

  if (!group) {
    return c.json({ error: "Group not found" }, 404);
  }

  await c.env.DB.prepare("DELETE FROM user_group_members WHERE id = ? AND group_id = ?")
    .bind(id, groupId).run();

  return c.json({ success: true });
});

export default app;
