'use server'

import { erpFetch } from "@/lib/erp-api"
import { z } from 'zod'

const ContactSchema = z.object({
    name: z.string().min(1, 'Contact name is required'),
    type: z.enum(['PARTNER', 'SUPPLIER', 'CUSTOMER']).optional(),
    email: z.string().email().optional().or(z.literal('')),
    phone: z.string().optional(),
    address: z.string().optional(),
    company: z.string().optional(),
    tax_id: z.string().optional(),
    notes: z.string().optional(),
}).passthrough()

export async function getContacts() {
    try {
        const data = await erpFetch('contacts/')
        return Array.isArray(data) ? data : []
    } catch {
        return []
    }
}

export async function getContactsByType(type: 'PARTNER' | 'SUPPLIER' | 'CUSTOMER') {
    try {
        const all = await erpFetch('contacts/')
        return Array.isArray(all) ? all.filter((c: Record<string, any>) => c.type === type) : []
    } catch {
        return []
    }
}

export async function getContact(id: number) {
    try {
        return await erpFetch(`contacts/${id}/`)
    } catch {
        return null
    }
}

export async function getContactSummary(contactId: number) {
    return await erpFetch(`contacts/${contactId}/summary/`)
}

export async function createContact(data: unknown) {
    const parsed = ContactSchema.parse(data)
    return await erpFetch('contacts/', {
        method: 'POST',
        body: JSON.stringify(parsed)
    })
}

export async function updateContact(id: number, data: unknown) {
    const parsed = ContactSchema.partial().parse(data)
    return await erpFetch(`contacts/${id}/`, {
        method: 'PATCH',
        body: JSON.stringify(parsed)
    })
}

export async function deleteContact(id: number) {
    return await erpFetch(`contacts/${id}/`, {
        method: 'DELETE'
    })
}