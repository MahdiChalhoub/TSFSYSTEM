# Test Vantage Initialization
